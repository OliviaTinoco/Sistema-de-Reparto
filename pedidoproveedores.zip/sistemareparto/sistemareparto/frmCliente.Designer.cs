﻿namespace sistemareparto
{
    partial class cliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(cliente));
            this.dgv_cliente = new System.Windows.Forms.DataGridView();
            this.lbl_pnombre = new System.Windows.Forms.Label();
            this.txt_pnombre = new System.Windows.Forms.TextBox();
            this.lbl_snombre = new System.Windows.Forms.Label();
            this.lbl_papellido = new System.Windows.Forms.Label();
            this.lbl_nit = new System.Windows.Forms.Label();
            this.lbl_fechanac = new System.Windows.Forms.Label();
            this.lbl_sapellido = new System.Windows.Forms.Label();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.txt_snombre = new System.Windows.Forms.TextBox();
            this.txt_papellido = new System.Windows.Forms.TextBox();
            this.txt_sapellido = new System.Windows.Forms.TextBox();
            this.txt_nit = new System.Windows.Forms.TextBox();
            this.txt_fechanac = new System.Windows.Forms.TextBox();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.lbl_aceptar = new System.Windows.Forms.Label();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_actualizar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.btn_buscdir = new System.Windows.Forms.Button();
            this.btn_busctel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cliente)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_cliente
            // 
            this.dgv_cliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cliente.Location = new System.Drawing.Point(26, 354);
            this.dgv_cliente.Name = "dgv_cliente";
            this.dgv_cliente.Size = new System.Drawing.Size(800, 150);
            this.dgv_cliente.TabIndex = 1;
            // 
            // lbl_pnombre
            // 
            this.lbl_pnombre.AutoSize = true;
            this.lbl_pnombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pnombre.Location = new System.Drawing.Point(22, 166);
            this.lbl_pnombre.Name = "lbl_pnombre";
            this.lbl_pnombre.Size = new System.Drawing.Size(123, 20);
            this.lbl_pnombre.TabIndex = 2;
            this.lbl_pnombre.Text = "Primer Nombre*";
            this.lbl_pnombre.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_pnombre
            // 
            this.txt_pnombre.Location = new System.Drawing.Point(204, 169);
            this.txt_pnombre.Name = "txt_pnombre";
            this.txt_pnombre.Size = new System.Drawing.Size(150, 20);
            this.txt_pnombre.TabIndex = 3;
            // 
            // lbl_snombre
            // 
            this.lbl_snombre.AutoSize = true;
            this.lbl_snombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_snombre.Location = new System.Drawing.Point(22, 216);
            this.lbl_snombre.Name = "lbl_snombre";
            this.lbl_snombre.Size = new System.Drawing.Size(137, 20);
            this.lbl_snombre.TabIndex = 4;
            this.lbl_snombre.Text = "Segundo Nombre";
            // 
            // lbl_papellido
            // 
            this.lbl_papellido.AutoSize = true;
            this.lbl_papellido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_papellido.Location = new System.Drawing.Point(22, 262);
            this.lbl_papellido.Name = "lbl_papellido";
            this.lbl_papellido.Size = new System.Drawing.Size(124, 20);
            this.lbl_papellido.TabIndex = 5;
            this.lbl_papellido.Text = "Primer Apellido*";
            // 
            // lbl_nit
            // 
            this.lbl_nit.AutoSize = true;
            this.lbl_nit.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nit.Location = new System.Drawing.Point(433, 166);
            this.lbl_nit.Name = "lbl_nit";
            this.lbl_nit.Size = new System.Drawing.Size(30, 20);
            this.lbl_nit.TabIndex = 6;
            this.lbl_nit.Text = "NIT";
            // 
            // lbl_fechanac
            // 
            this.lbl_fechanac.AutoSize = true;
            this.lbl_fechanac.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fechanac.Location = new System.Drawing.Point(433, 216);
            this.lbl_fechanac.Name = "lbl_fechanac";
            this.lbl_fechanac.Size = new System.Drawing.Size(167, 20);
            this.lbl_fechanac.TabIndex = 7;
            this.lbl_fechanac.Text = "Fecha de Nacimiento";
            // 
            // lbl_sapellido
            // 
            this.lbl_sapellido.AutoSize = true;
            this.lbl_sapellido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sapellido.Location = new System.Drawing.Point(22, 307);
            this.lbl_sapellido.Name = "lbl_sapellido";
            this.lbl_sapellido.Size = new System.Drawing.Size(138, 20);
            this.lbl_sapellido.TabIndex = 8;
            this.lbl_sapellido.Text = "Segundo Apellido";
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_direccion.Location = new System.Drawing.Point(433, 262);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(86, 20);
            this.lbl_direccion.TabIndex = 9;
            this.lbl_direccion.Text = "Direccion*";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono.Location = new System.Drawing.Point(433, 307);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(77, 20);
            this.lbl_telefono.TabIndex = 10;
            this.lbl_telefono.Text = "Telefono*";
            // 
            // txt_snombre
            // 
            this.txt_snombre.Location = new System.Drawing.Point(204, 216);
            this.txt_snombre.Name = "txt_snombre";
            this.txt_snombre.Size = new System.Drawing.Size(150, 20);
            this.txt_snombre.TabIndex = 11;
            // 
            // txt_papellido
            // 
            this.txt_papellido.Location = new System.Drawing.Point(204, 262);
            this.txt_papellido.Name = "txt_papellido";
            this.txt_papellido.Size = new System.Drawing.Size(150, 20);
            this.txt_papellido.TabIndex = 12;
            // 
            // txt_sapellido
            // 
            this.txt_sapellido.Location = new System.Drawing.Point(204, 307);
            this.txt_sapellido.Name = "txt_sapellido";
            this.txt_sapellido.Size = new System.Drawing.Size(150, 20);
            this.txt_sapellido.TabIndex = 13;
            // 
            // txt_nit
            // 
            this.txt_nit.Location = new System.Drawing.Point(652, 167);
            this.txt_nit.Name = "txt_nit";
            this.txt_nit.Size = new System.Drawing.Size(150, 20);
            this.txt_nit.TabIndex = 14;
            // 
            // txt_fechanac
            // 
            this.txt_fechanac.Location = new System.Drawing.Point(652, 217);
            this.txt_fechanac.Name = "txt_fechanac";
            this.txt_fechanac.Size = new System.Drawing.Size(150, 20);
            this.txt_fechanac.TabIndex = 15;
            // 
            // txt_dir
            // 
            this.txt_dir.Location = new System.Drawing.Point(652, 263);
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.Size = new System.Drawing.Size(150, 20);
            this.txt_dir.TabIndex = 16;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Location = new System.Drawing.Point(652, 307);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono.TabIndex = 17;
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(361, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(115, 32);
            this.lbl_titulo.TabIndex = 20;
            this.lbl_titulo.Text = "CLIENTE";
            // 
            // lbl_aceptar
            // 
            this.lbl_aceptar.AutoSize = true;
            this.lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aceptar.Location = new System.Drawing.Point(652, 120);
            this.lbl_aceptar.Name = "lbl_aceptar";
            this.lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.lbl_aceptar.TabIndex = 81;
            this.lbl_aceptar.Text = "Aceptar";
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cancelar.Location = new System.Drawing.Point(557, 120);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 80;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscar.Location = new System.Drawing.Point(465, 120);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 79;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_eliminar.Location = new System.Drawing.Point(383, 118);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 78;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_actualizar
            // 
            this.lbl_actualizar.AutoSize = true;
            this.lbl_actualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_actualizar.Location = new System.Drawing.Point(294, 118);
            this.lbl_actualizar.Name = "lbl_actualizar";
            this.lbl_actualizar.Size = new System.Drawing.Size(81, 20);
            this.lbl_actualizar.TabIndex = 77;
            this.lbl_actualizar.Text = "Actualizar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(207, 118);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 76;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(127, 118);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 75;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(469, 50);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 73;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.btn_buscar_Click);
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_aceptar.BackgroundImage")));
            this.btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_aceptar.Location = new System.Drawing.Point(644, 50);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.btn_aceptar.TabIndex = 72;
            this.btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelar.BackgroundImage")));
            this.btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelar.Location = new System.Drawing.Point(555, 50);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelar.TabIndex = 71;
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Location = new System.Drawing.Point(379, 50);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 74;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_modificar
            // 
            this.btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_modificar.BackgroundImage")));
            this.btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_modificar.Location = new System.Drawing.Point(292, 50);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.btn_modificar.TabIndex = 70;
            this.btn_modificar.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(207, 50);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 69;
            this.btn_guardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(121, 50);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 68;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            // 
            // btn_buscdir
            // 
            this.btn_buscdir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscdir.BackgroundImage")));
            this.btn_buscdir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscdir.Location = new System.Drawing.Point(817, 257);
            this.btn_buscdir.Name = "btn_buscdir";
            this.btn_buscdir.Size = new System.Drawing.Size(28, 29);
            this.btn_buscdir.TabIndex = 82;
            this.btn_buscdir.UseVisualStyleBackColor = true;
            this.btn_buscdir.Click += new System.EventHandler(this.busc_btndir_Click);
            // 
            // btn_busctel
            // 
            this.btn_busctel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_busctel.BackgroundImage")));
            this.btn_busctel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_busctel.Location = new System.Drawing.Point(817, 302);
            this.btn_busctel.Name = "btn_busctel";
            this.btn_busctel.Size = new System.Drawing.Size(28, 29);
            this.btn_busctel.TabIndex = 82;
            this.btn_busctel.UseVisualStyleBackColor = true;
            this.btn_busctel.Click += new System.EventHandler(this.bus_btndir_Click);
            // 
            // cliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(879, 516);
            this.Controls.Add(this.btn_busctel);
            this.Controls.Add(this.btn_buscdir);
            this.Controls.Add(this.lbl_aceptar);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_actualizar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.txt_dir);
            this.Controls.Add(this.txt_fechanac);
            this.Controls.Add(this.txt_nit);
            this.Controls.Add(this.txt_sapellido);
            this.Controls.Add(this.txt_papellido);
            this.Controls.Add(this.txt_snombre);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.lbl_direccion);
            this.Controls.Add(this.lbl_sapellido);
            this.Controls.Add(this.lbl_fechanac);
            this.Controls.Add(this.lbl_nit);
            this.Controls.Add(this.lbl_papellido);
            this.Controls.Add(this.lbl_snombre);
            this.Controls.Add(this.txt_pnombre);
            this.Controls.Add(this.lbl_pnombre);
            this.Controls.Add(this.dgv_cliente);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "cliente";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cliente";
            this.Load += new System.EventHandler(this.cliente_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cliente)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dgv_cliente;
        private System.Windows.Forms.Label lbl_pnombre;
        private System.Windows.Forms.TextBox txt_pnombre;
        private System.Windows.Forms.Label lbl_snombre;
        private System.Windows.Forms.Label lbl_papellido;
        private System.Windows.Forms.Label lbl_nit;
        private System.Windows.Forms.Label lbl_fechanac;
        private System.Windows.Forms.Label lbl_sapellido;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.TextBox txt_snombre;
        private System.Windows.Forms.TextBox txt_papellido;
        private System.Windows.Forms.TextBox txt_sapellido;
        private System.Windows.Forms.TextBox txt_nit;
        private System.Windows.Forms.TextBox txt_fechanac;
        private System.Windows.Forms.TextBox txt_dir;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_actualizar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_buscdir;
        private System.Windows.Forms.Button btn_busctel;
        private System.Windows.Forms.Label lbl_aceptar;
    }
}

