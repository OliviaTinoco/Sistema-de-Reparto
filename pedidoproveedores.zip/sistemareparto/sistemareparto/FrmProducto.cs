﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class FrmProducto : Form
    {
        public FrmProducto()
        {
            InitializeComponent();
        }

        public clsProducto ProdAct { get; set; }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarProducto buscprod = new frmBuscarProducto();
            buscprod.ShowDialog();

            if (buscprod.ProdSelec != null)
            {

                
                ProdAct = buscprod.ProdSelec;
                txt_desc.Text = buscprod.ProdSelec.sdesc;
                txt_exist.Text = Convert.ToString(buscprod.ProdSelec.icodexist);
                txt_marc.Text = buscprod.ProdSelec.smarc;
                txt_proveedor.Text = Convert.ToString(buscprod.ProdSelec.icodprov);
                txt_nom.Text = buscprod.ProdSelec.snom;

              


            }


        }

        private void btn_buscubicacion_Click(object sender, EventArgs e)
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();
        }

        private void FrmProducto_Load(object sender, EventArgs e)
        {

        }

        private void btn_buscprov_Click(object sender, EventArgs e)
        {
            frmbuscar_proveedor busprov = new frmbuscar_proveedor();
            busprov.ShowDialog();
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_marc.Text) || string.IsNullOrWhiteSpace(txt_nom.Text) ||
                           string.IsNullOrWhiteSpace(txt_proveedor.Text) || string.IsNullOrWhiteSpace(txt_exist.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsProducto pProd = new clsProducto();
                    pProd.icodexist = Convert.ToInt16(txt_exist.Text.Trim());
                    pProd.icodprov = Convert.ToInt16(txt_proveedor.Text.Trim());
                    pProd.snom= txt_nom.Text.Trim();
                    pProd.smarc = txt_marc.Text.Trim();
                    pProd.sdesc= txt_desc.Text.Trim();



                    int iresultado = clsProductoOp.Agregar(pProd);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ubicacion Guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la Ubicacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_marc.Text) || string.IsNullOrWhiteSpace(txt_nom.Text) ||
                           string.IsNullOrWhiteSpace(txt_proveedor.Text) || string.IsNullOrWhiteSpace(txt_exist.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsProducto pProd = new clsProducto();
                    pProd.icodexist = Convert.ToInt16(txt_exist.Text.Trim());
                    pProd.icodprov = Convert.ToInt16(txt_proveedor.Text.Trim());
                    pProd.snom = txt_nom.Text.Trim();
                    pProd.smarc = txt_marc.Text.Trim();
                    pProd.sdesc = txt_desc.Text.Trim();
                    pProd.icod = ProdAct.icod; 



                    int iresultado = clsProductoOp.Actualizar(pProd);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Producto Actualizado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se actualizar el prodcuto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar el producto Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (clsProductoOp.Eliminar(ProdAct.icod) > 0)
                {
                    MessageBox.Show("Producto Eliminado Correctamente!", "Ruta Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Limpiar();
                    //Deshabilitar();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el producto", "Ruta No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }
    }
}
