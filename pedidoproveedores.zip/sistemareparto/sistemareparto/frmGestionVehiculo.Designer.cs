﻿namespace sistemareparto
{
    partial class frmGestionVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmGestionVehiculo));
            this.cbo_mantenimiento = new System.Windows.Forms.ComboBox();
            this.cbo_ingreso = new System.Windows.Forms.DateTimePicker();
            this.cbo_salida = new System.Windows.Forms.DateTimePicker();
            this.cbo_vehiculo = new System.Windows.Forms.ComboBox();
            this.lbl_vehiculo = new System.Windows.Forms.Label();
            this.lbl_aceptar = new System.Windows.Forms.Label();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.dgv_gestion = new System.Windows.Forms.DataGridView();
            this.txt_salida = new System.Windows.Forms.TextBox();
            this.txt_entrada = new System.Windows.Forms.TextBox();
            this.lbl_mantenimiento = new System.Windows.Forms.Label();
            this.lbl_entrada = new System.Windows.Forms.Label();
            this.lbl_esalida = new System.Windows.Forms.Label();
            this.lbl_ingreso = new System.Windows.Forms.Label();
            this.lbl_salida = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_actualizar = new System.Windows.Forms.Label();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.lbl_gestion = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_gestion)).BeginInit();
            this.SuspendLayout();
            // 
            // cbo_mantenimiento
            // 
            this.cbo_mantenimiento.FormattingEnabled = true;
            this.cbo_mantenimiento.Location = new System.Drawing.Point(585, 247);
            this.cbo_mantenimiento.Name = "cbo_mantenimiento";
            this.cbo_mantenimiento.Size = new System.Drawing.Size(150, 21);
            this.cbo_mantenimiento.TabIndex = 118;
            // 
            // cbo_ingreso
            // 
            this.cbo_ingreso.Location = new System.Drawing.Point(585, 171);
            this.cbo_ingreso.Name = "cbo_ingreso";
            this.cbo_ingreso.Size = new System.Drawing.Size(150, 20);
            this.cbo_ingreso.TabIndex = 117;
            // 
            // cbo_salida
            // 
            this.cbo_salida.Location = new System.Drawing.Point(198, 213);
            this.cbo_salida.Name = "cbo_salida";
            this.cbo_salida.Size = new System.Drawing.Size(150, 20);
            this.cbo_salida.TabIndex = 116;
            // 
            // cbo_vehiculo
            // 
            this.cbo_vehiculo.FormattingEnabled = true;
            this.cbo_vehiculo.Location = new System.Drawing.Point(197, 174);
            this.cbo_vehiculo.Name = "cbo_vehiculo";
            this.cbo_vehiculo.Size = new System.Drawing.Size(150, 21);
            this.cbo_vehiculo.TabIndex = 115;
            // 
            // lbl_vehiculo
            // 
            this.lbl_vehiculo.AutoSize = true;
            this.lbl_vehiculo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vehiculo.Location = new System.Drawing.Point(95, 171);
            this.lbl_vehiculo.Name = "lbl_vehiculo";
            this.lbl_vehiculo.Size = new System.Drawing.Size(77, 21);
            this.lbl_vehiculo.TabIndex = 114;
            this.lbl_vehiculo.Text = "Vehiculo";
            // 
            // lbl_aceptar
            // 
            this.lbl_aceptar.AutoSize = true;
            this.lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_aceptar.Location = new System.Drawing.Point(418, 125);
            this.lbl_aceptar.Name = "lbl_aceptar";
            this.lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.lbl_aceptar.TabIndex = 113;
            this.lbl_aceptar.Text = "Aceptar";
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_cancelar.Location = new System.Drawing.Point(505, 125);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 111;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // dgv_gestion
            // 
            this.dgv_gestion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_gestion.Location = new System.Drawing.Point(10, 294);
            this.dgv_gestion.Name = "dgv_gestion";
            this.dgv_gestion.Size = new System.Drawing.Size(800, 150);
            this.dgv_gestion.TabIndex = 109;
            // 
            // txt_salida
            // 
            this.txt_salida.Location = new System.Drawing.Point(197, 249);
            this.txt_salida.Name = "txt_salida";
            this.txt_salida.Size = new System.Drawing.Size(150, 20);
            this.txt_salida.TabIndex = 108;
            // 
            // txt_entrada
            // 
            this.txt_entrada.Location = new System.Drawing.Point(585, 213);
            this.txt_entrada.Name = "txt_entrada";
            this.txt_entrada.Size = new System.Drawing.Size(150, 20);
            this.txt_entrada.TabIndex = 107;
            // 
            // lbl_mantenimiento
            // 
            this.lbl_mantenimiento.AutoSize = true;
            this.lbl_mantenimiento.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mantenimiento.Location = new System.Drawing.Point(416, 246);
            this.lbl_mantenimiento.Name = "lbl_mantenimiento";
            this.lbl_mantenimiento.Size = new System.Drawing.Size(158, 21);
            this.lbl_mantenimiento.TabIndex = 106;
            this.lbl_mantenimiento.Text = "Mantentenimiento";
            // 
            // lbl_entrada
            // 
            this.lbl_entrada.AutoSize = true;
            this.lbl_entrada.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_entrada.Location = new System.Drawing.Point(418, 211);
            this.lbl_entrada.Name = "lbl_entrada";
            this.lbl_entrada.Size = new System.Drawing.Size(161, 21);
            this.lbl_entrada.TabIndex = 105;
            this.lbl_entrada.Text = "Estado de Entrada ";
            // 
            // lbl_esalida
            // 
            this.lbl_esalida.AutoSize = true;
            this.lbl_esalida.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_esalida.Location = new System.Drawing.Point(47, 249);
            this.lbl_esalida.Name = "lbl_esalida";
            this.lbl_esalida.Size = new System.Drawing.Size(144, 21);
            this.lbl_esalida.TabIndex = 104;
            this.lbl_esalida.Text = "Estado de Salida ";
            // 
            // lbl_ingreso
            // 
            this.lbl_ingreso.AutoSize = true;
            this.lbl_ingreso.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ingreso.Location = new System.Drawing.Point(418, 171);
            this.lbl_ingreso.Name = "lbl_ingreso";
            this.lbl_ingreso.Size = new System.Drawing.Size(156, 21);
            this.lbl_ingreso.TabIndex = 103;
            this.lbl_ingreso.Text = "Ingreso de Gestion";
            // 
            // lbl_salida
            // 
            this.lbl_salida.AutoSize = true;
            this.lbl_salida.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_salida.Location = new System.Drawing.Point(41, 211);
            this.lbl_salida.Name = "lbl_salida";
            this.lbl_salida.Size = new System.Drawing.Size(150, 21);
            this.lbl_salida.TabIndex = 102;
            this.lbl_salida.Text = " Salida de Gestion";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_buscar.Location = new System.Drawing.Point(610, 125);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 101;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_eliminar.Location = new System.Drawing.Point(343, 125);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 100;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_guardar.Location = new System.Drawing.Point(156, 125);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 99;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_actualizar
            // 
            this.lbl_actualizar.AutoSize = true;
            this.lbl_actualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_actualizar.Location = new System.Drawing.Point(246, 125);
            this.lbl_actualizar.Name = "lbl_actualizar";
            this.lbl_actualizar.Size = new System.Drawing.Size(81, 20);
            this.lbl_actualizar.TabIndex = 98;
            this.lbl_actualizar.Text = "Actualizar";
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(76, 125);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 97;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_aceptar.BackgroundImage")));
            this.btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_aceptar.Location = new System.Drawing.Point(422, 57);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.btn_aceptar.TabIndex = 125;
            this.btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(603, 57);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 124;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelar.BackgroundImage")));
            this.btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelar.Location = new System.Drawing.Point(509, 57);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelar.TabIndex = 123;
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(70, 57);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 122;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Location = new System.Drawing.Point(341, 57);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 121;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_modificar
            // 
            this.btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_modificar.BackgroundImage")));
            this.btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_modificar.Location = new System.Drawing.Point(250, 57);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.btn_modificar.TabIndex = 120;
            this.btn_modificar.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(160, 57);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 119;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // lbl_gestion
            // 
            this.lbl_gestion.AutoSize = true;
            this.lbl_gestion.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_gestion.Location = new System.Drawing.Point(276, 8);
            this.lbl_gestion.Name = "lbl_gestion";
            this.lbl_gestion.Size = new System.Drawing.Size(269, 32);
            this.lbl_gestion.TabIndex = 126;
            this.lbl_gestion.Text = "GESTION VEHICULO";
            // 
            // frmGestionVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(819, 456);
            this.Controls.Add(this.lbl_gestion);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.cbo_mantenimiento);
            this.Controls.Add(this.cbo_ingreso);
            this.Controls.Add(this.cbo_salida);
            this.Controls.Add(this.cbo_vehiculo);
            this.Controls.Add(this.lbl_vehiculo);
            this.Controls.Add(this.lbl_aceptar);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.dgv_gestion);
            this.Controls.Add(this.txt_salida);
            this.Controls.Add(this.txt_entrada);
            this.Controls.Add(this.lbl_mantenimiento);
            this.Controls.Add(this.lbl_entrada);
            this.Controls.Add(this.lbl_esalida);
            this.Controls.Add(this.lbl_ingreso);
            this.Controls.Add(this.lbl_salida);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_actualizar);
            this.Controls.Add(this.lbl_nuevo);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmGestionVehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmGestionVehiculo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_gestion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_mantenimiento;
        private System.Windows.Forms.DateTimePicker cbo_ingreso;
        private System.Windows.Forms.DateTimePicker cbo_salida;
        private System.Windows.Forms.ComboBox cbo_vehiculo;
        private System.Windows.Forms.Label lbl_vehiculo;
        private System.Windows.Forms.Label lbl_aceptar;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.DataGridView dgv_gestion;
        private System.Windows.Forms.TextBox txt_salida;
        private System.Windows.Forms.TextBox txt_entrada;
        private System.Windows.Forms.Label lbl_mantenimiento;
        private System.Windows.Forms.Label lbl_entrada;
        private System.Windows.Forms.Label lbl_esalida;
        private System.Windows.Forms.Label lbl_ingreso;
        private System.Windows.Forms.Label lbl_salida;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_actualizar;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Label lbl_gestion;
    }
}