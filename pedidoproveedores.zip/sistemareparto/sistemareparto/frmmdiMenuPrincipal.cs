﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmmdiMenuPrincipal : Form
    {
        private int childFormNumber = 0;

        public frmmdiMenuPrincipal()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

       
        

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void mdiMenuPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void inventarioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmInventario fin = new frmInventario();
            fin.WindowState = FormWindowState.Maximized;
            fin.MdiParent = this;
            fin.Show();
        }

        private void inventarioToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            frmInventario fin = new frmInventario();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void ubicaciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUbicacion fin = new frmUbicacion();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void productoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            FrmProducto fin = new FrmProducto();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void clienteToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            cliente fin = new cliente();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void empleadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmEmpleado fin = new frmEmpleado();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void proveedorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void proveedorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmProveedor fin = new frmProveedor();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmInicio fin = new frmInicio();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void bitacoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBitacora fin = new frmBitacora();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsuario fin = new frmUsuario();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void usuarioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            mant_usuarios fin = new mant_usuarios();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void pedidoClienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form_registro_pedido fin = new Form_registro_pedido();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void rutaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmRuta fin = new frmRuta();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void usuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
        
        }

        private void administraciónToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

       /* private void inicioToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmInicio fin = new frmInicio();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }*/

        private void administradorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmBitacora fin = new frmBitacora();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void usuarioToolStripMenuItem3_Click(object sender, EventArgs e)
        {
            mant_usuarios fin = new mant_usuarios();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void iniciarSesionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmUsuario fin = new frmUsuario();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void pedidoClienteToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form_registro_pedido fin = new Form_registro_pedido();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();

        }

        private void pedidoProveedorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmPedidoProveedores fin = new frmPedidoProveedores();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void inventarioToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            frmInventario fin = new frmInventario();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void mantenimientoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmMantenimientoVehiculo fin = new frmMantenimientoVehiculo();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void gestionDeVehiculoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmGestionVehiculo fin = new frmGestionVehiculo();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void clienteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            cliente fin = new cliente();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void proveedoresToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProveedor fin = new frmProveedor();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void empleadoToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmEmpleado fin = new frmEmpleado();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void productoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmProducto fin = new FrmProducto();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void vehiculoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            frmVehiculo fin = new frmVehiculo();
            fin.WindowState = FormWindowState.Normal;
            fin.MdiParent = this;
            fin.Show();
        }

        private void rutaToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmRuta frm = new frmRuta();
            frm.WindowState = FormWindowState.Normal;
            frm.MdiParent = this;
            frm.Show(); 
        }

        private void ubicaciónToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            frmUbicacion frm = new frmUbicacion();
            frm.WindowState = FormWindowState.Normal;
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
