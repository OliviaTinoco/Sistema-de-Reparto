﻿namespace sistemareparto
{
    partial class frmInicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInicio));
            this.lbl_login = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            this.btn_acceso = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_login
            // 
            this.lbl_login.AutoSize = true;
            this.lbl_login.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_login.Location = new System.Drawing.Point(260, 9);
            this.lbl_login.Name = "lbl_login";
            this.lbl_login.Size = new System.Drawing.Size(90, 36);
            this.lbl_login.TabIndex = 0;
            this.lbl_login.Text = "Login";
            this.lbl_login.Click += new System.EventHandler(this.label1_Click);
            // 
            // pic_login
            // 
            this.pic_login.Image = ((System.Drawing.Image)(resources.GetObject("pic_login.Image")));
            this.pic_login.Location = new System.Drawing.Point(212, 73);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(185, 187);
            this.pic_login.TabIndex = 1;
            this.pic_login.TabStop = false;
            // 
            // btn_acceso
            // 
            this.btn_acceso.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_acceso.Location = new System.Drawing.Point(212, 285);
            this.btn_acceso.Name = "btn_acceso";
            this.btn_acceso.Size = new System.Drawing.Size(185, 32);
            this.btn_acceso.TabIndex = 4;
            this.btn_acceso.Text = "Acceso";
            this.btn_acceso.UseVisualStyleBackColor = true;
            this.btn_acceso.Click += new System.EventHandler(this.Btn_administrador_Click);
            // 
            // frmInicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(590, 382);
            this.Controls.Add(this.btn_acceso);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.lbl_login);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmInicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_login;
        private System.Windows.Forms.PictureBox pic_login;
        private System.Windows.Forms.Button btn_acceso;
    }
}

