﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmEmpleado : Form
    {
        public frmEmpleado()
        {
            InitializeComponent();
        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            frmBuscar_empleado fin = new frmBuscar_empleado();
            fin.ShowDialog();
        }

        private void mdir_btn_Click(object sender, EventArgs e)
        {
            frmDireccionEmp dir = new frmDireccionEmp();
            dir.ShowDialog();
        }

        private void mtel_btn_Click(object sender, EventArgs e)
        {
            frmTelefonoEmp tel = new frmTelefonoEmp();
            tel.ShowDialog();
        }

        private void mmail_btn_Click(object sender, EventArgs e)
        {
            frmCorreoEmp corre = new frmCorreoEmp();
            corre.ShowDialog();
        }

        private void puesto_btn_Click(object sender, EventArgs e)
        {
            frmPuestEmp pues = new frmPuestEmp();
            pues.ShowDialog();
        }

        private void busc_btndir_Click(object sender, EventArgs e)
        {
            frmPuestEmp pues = new frmPuestEmp();
            pues.ShowDialog();
        }

        private void Btn_btel_Click(object sender, EventArgs e)
        {
            frmCorreoEmp tel = new frmCorreoEmp();
            tel.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmTelefonoEmp tel = new frmTelefonoEmp();
            tel.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmDireccionEmp dir = new frmDireccionEmp();
            dir.ShowDialog();
        }

        private void Empleado_Load(object sender, EventArgs e)
        {

        }
    }
}
