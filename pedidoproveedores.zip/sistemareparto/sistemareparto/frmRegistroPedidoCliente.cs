﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class Form_registro_pedido : Form
    {
        public Form_registro_pedido()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void Btn_registro_pedido_Click(object sender, EventArgs e)
        {
            Form_registro_pedido forma1 = new Form_registro_pedido();
            forma1.ShowDialog();
        }

        private void Btn_modificar_pedido_Click(object sender, EventArgs e)
        {
           
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void Btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscar_pedido bus = new frmBuscar_pedido();
            bus.ShowDialog();
        }

        private void Btn_cancelar_pedido_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_cliente_Click(object sender, EventArgs e)
        {
            frmBuscar_cliente cte = new frmBuscar_cliente();
            cte.ShowDialog(); 
        }

        private void Btn_buscar_producto_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();
            prod.ShowDialog(); 
        }

        private void txt_cantidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {

        }
    }
}
