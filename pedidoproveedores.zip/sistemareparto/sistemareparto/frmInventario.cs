﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmInventario : Form
    {
        public frmInventario()
        {
            InitializeComponent();
        }

        private void txt_preventa_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_buscproducto_Click(object sender, EventArgs e)
        {
            frmBuscarProducto bucrprod = new frmBuscarProducto();
            bucrprod.ShowDialog();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarInventario businv = new frmBuscarInventario();
            businv.ShowDialog();
        }

        private void frmInventario_Load(object sender, EventArgs e)
        {

        }

        private void btn_buscubicacion_Click(object sender, EventArgs e)
        {
            frmBuscarUbicacion ubic = new frmBuscarUbicacion();
            ubic.ShowDialog(); 
        }
    }
}
