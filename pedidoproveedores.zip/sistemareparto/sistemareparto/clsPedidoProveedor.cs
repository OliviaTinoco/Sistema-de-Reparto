﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class clsPedidoProveedor
    {

        public int icodprov { get; set; }
        public string stpago { get; set; }
        public string sfecha { get; set; }
        public string  scantidad{ get; set; }
        public int  icodpro{ get; set; }

        public clsPedidoProveedor() { }

        public clsPedidoProveedor (int pCodprov, string pTpago, string pFecha, string pCantidad, int pCodpro)

        {
            this.icodprov = pCodprov;
            this.stpago = pTpago;
            this.sfecha = pFecha;
            this.scantidad = pCantidad;
            this.icodpro = pCodpro;
            
        }
    }
}
