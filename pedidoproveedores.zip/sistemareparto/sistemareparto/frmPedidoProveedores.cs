﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmPedidoProveedores : Form
    {
        public frmPedidoProveedores()
        {
            InitializeComponent();
        }

        private void frmPedidoProveedores_Load(object sender, EventArgs e)
        {

        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            frmBuscarPedido busped = new frmBuscarPedido();
            busped.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();
            prod.ShowDialog();
        }



        private void btn_agregar_Click(object sender, EventArgs e)
        {
          
        }



        private void cbo_proveedor_SelectedIndexChanged(object sender, EventArgs e)
        {
           string proveedorselect = (string) cbo_proveedor.SelectedItem; //guarda provvedor seleccionado
            //MessageBox.Show("" + proveedorselect );

            string scadp = "select * from producto where pk_codprov ="+proveedorselect; //va a traer los productos que son del proveedor seleccionado
            MySqlCommand mcd = new MySqlCommand(scadp, clsBdComun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            while (mdr.Read())
            {
                clb_pro.Items.Add(mdr.GetString("nom_prod")); //agrega los productos al ListChekBox

            }


         String dgv_pedidos = (string)cbo_proveedor.SelectedItem;


           


        }


        //Consulta que llena el combo box
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            string scadp = "select * from proveedor"; 
            MySqlCommand mcd = new MySqlCommand(scadp,clsBdComun.ObtenerConexion());
        MySqlDataReader mdr = mcd.ExecuteReader();
           
            while (mdr.Read())
            {
               
                cbo_proveedor.Items.Add(mdr.GetString("pk_codprov"));
                cbo_proveedor.Items.Add(mdr.GetString("nombre_prov"));
            }

          
      
           
        }

        private void cbo_producto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace("1") || string.IsNullOrWhiteSpace(txt_tpago.Text) ||
                          string.IsNullOrWhiteSpace(ltp_fecha.Text) || string.IsNullOrWhiteSpace(txt_cantidad.Text) || string.IsNullOrWhiteSpace("1"))

                    MessageBox.Show("Se deben llenar todos los campos obligatorios (*)!", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {

                    clsPedidoProveedor pPedido = new clsPedidoProveedor();//objeto que lleva los parametros para insertar pedido del proveedor
                    clsPedidoProveedor pProductoPedido = new clsPedidoProveedor();//objeto que lleva los parametros para insertar producto del pedido del proveedor

                    pPedido.icodprov = 1;
                    pPedido.stpago = txt_tpago.Text.Trim();
                    pPedido.sfecha = ltp_fecha.Value.Year + "/" + ltp_fecha.Value.Month + "/" + ltp_fecha.Value.Day;

                    pProductoPedido.icodprov = 1;
                    pProductoPedido.scantidad = txt_cantidad.Text.Trim();
                    pProductoPedido.icodpro = 1;

                    int resultado = clsPedidoProveedorOp.Agregar(pPedido);
                    int resultado1 = clsPedidoProveedorOp.AgregarProducto(pProductoPedido);

                    if (resultado > 1 & resultado1 > 1)
                    {
                        MessageBox.Show("Pedido Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(" Pedido Se guardo con Exito", "Guardado!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void ltp_fecha_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void clb_pro_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
