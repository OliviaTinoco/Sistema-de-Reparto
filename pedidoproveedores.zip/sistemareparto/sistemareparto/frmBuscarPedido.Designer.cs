﻿namespace sistemareparto
{
    partial class frmBuscarPedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuscarPedido));
            this.cbo_proveedor = new System.Windows.Forms.ComboBox();
            this.lbl_proveedor = new System.Windows.Forms.Label();
            this.cbo_fecha = new System.Windows.Forms.DateTimePicker();
            this.dgv_busquedaPedidos = new System.Windows.Forms.DataGridView();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_modificarPedidoProveedor = new System.Windows.Forms.Label();
            this.btn_buscar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_busquedaPedidos)).BeginInit();
            this.SuspendLayout();
            // 
            // cbo_proveedor
            // 
            this.cbo_proveedor.FormattingEnabled = true;
            this.cbo_proveedor.Location = new System.Drawing.Point(215, 76);
            this.cbo_proveedor.Name = "cbo_proveedor";
            this.cbo_proveedor.Size = new System.Drawing.Size(150, 21);
            this.cbo_proveedor.TabIndex = 83;
            // 
            // lbl_proveedor
            // 
            this.lbl_proveedor.AutoSize = true;
            this.lbl_proveedor.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proveedor.Location = new System.Drawing.Point(115, 76);
            this.lbl_proveedor.Name = "lbl_proveedor";
            this.lbl_proveedor.Size = new System.Drawing.Size(88, 20);
            this.lbl_proveedor.TabIndex = 82;
            this.lbl_proveedor.Text = "Proveedor";
            // 
            // cbo_fecha
            // 
            this.cbo_fecha.Location = new System.Drawing.Point(215, 126);
            this.cbo_fecha.Name = "cbo_fecha";
            this.cbo_fecha.Size = new System.Drawing.Size(150, 20);
            this.cbo_fecha.TabIndex = 81;
            // 
            // dgv_busquedaPedidos
            // 
            this.dgv_busquedaPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_busquedaPedidos.Location = new System.Drawing.Point(25, 182);
            this.dgv_busquedaPedidos.Name = "dgv_busquedaPedidos";
            this.dgv_busquedaPedidos.Size = new System.Drawing.Size(800, 150);
            this.dgv_busquedaPedidos.TabIndex = 80;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(115, 125);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(55, 20);
            this.lbl_fecha.TabIndex = 79;
            this.lbl_fecha.Text = "Fecha";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscar.Location = new System.Drawing.Point(403, 142);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 78;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_modificarPedidoProveedor
            // 
            this.lbl_modificarPedidoProveedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_modificarPedidoProveedor.AutoSize = true;
            this.lbl_modificarPedidoProveedor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_modificarPedidoProveedor.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_modificarPedidoProveedor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_modificarPedidoProveedor.Location = new System.Drawing.Point(208, 14);
            this.lbl_modificarPedidoProveedor.Name = "lbl_modificarPedidoProveedor";
            this.lbl_modificarPedidoProveedor.Size = new System.Drawing.Size(393, 32);
            this.lbl_modificarPedidoProveedor.TabIndex = 76;
            this.lbl_modificarPedidoProveedor.Text = "BUSCAR PEDIDO PROVEEDOR";
            this.lbl_modificarPedidoProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(407, 74);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 84;
            this.btn_buscar.UseVisualStyleBackColor = true;
            // 
            // frmBuscarPedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(842, 353);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.cbo_proveedor);
            this.Controls.Add(this.lbl_proveedor);
            this.Controls.Add(this.cbo_fecha);
            this.Controls.Add(this.dgv_busquedaPedidos);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_modificarPedidoProveedor);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmBuscarPedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmBuscarPedido";
            this.Load += new System.EventHandler(this.frmBuscarPedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_busquedaPedidos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_proveedor;
        private System.Windows.Forms.Label lbl_proveedor;
        private System.Windows.Forms.DateTimePicker cbo_fecha;
        private System.Windows.Forms.DataGridView dgv_busquedaPedidos;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_modificarPedidoProveedor;
        private System.Windows.Forms.Button btn_buscar;
    }
}