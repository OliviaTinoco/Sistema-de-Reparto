﻿namespace sistemareparto
{
    partial class frmTelefono
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTelefono));
            this.txt_telefono1 = new System.Windows.Forms.TextBox();
            this.lbl_telefono1 = new System.Windows.Forms.Label();
            this.lbl_telefono2 = new System.Windows.Forms.Label();
            this.txt_telefono2 = new System.Windows.Forms.TextBox();
            this.lbl_telefonos = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_telefono1
            // 
            this.txt_telefono1.Location = new System.Drawing.Point(170, 65);
            this.txt_telefono1.Name = "txt_telefono1";
            this.txt_telefono1.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono1.TabIndex = 0;
            this.txt_telefono1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lbl_telefono1
            // 
            this.lbl_telefono1.AutoSize = true;
            this.lbl_telefono1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono1.Location = new System.Drawing.Point(28, 64);
            this.lbl_telefono1.Name = "lbl_telefono1";
            this.lbl_telefono1.Size = new System.Drawing.Size(108, 20);
            this.lbl_telefono1.TabIndex = 1;
            this.lbl_telefono1.Text = "Otro Telefono";
            // 
            // lbl_telefono2
            // 
            this.lbl_telefono2.AutoSize = true;
            this.lbl_telefono2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono2.Location = new System.Drawing.Point(28, 114);
            this.lbl_telefono2.Name = "lbl_telefono2";
            this.lbl_telefono2.Size = new System.Drawing.Size(108, 20);
            this.lbl_telefono2.TabIndex = 3;
            this.lbl_telefono2.Text = "Otro Telefono";
            // 
            // txt_telefono2
            // 
            this.txt_telefono2.Location = new System.Drawing.Point(170, 115);
            this.txt_telefono2.Name = "txt_telefono2";
            this.txt_telefono2.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono2.TabIndex = 4;
            // 
            // lbl_telefonos
            // 
            this.lbl_telefonos.AutoSize = true;
            this.lbl_telefonos.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefonos.Location = new System.Drawing.Point(74, 9);
            this.lbl_telefonos.Name = "lbl_telefonos";
            this.lbl_telefonos.Size = new System.Drawing.Size(254, 32);
            this.lbl_telefonos.TabIndex = 5;
            this.lbl_telefonos.Text = "OTROS TELEFONOS";
            this.lbl_telefonos.Click += new System.EventHandler(this.label3_Click);
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(360, 122);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 99;
            this.lbl_guardar.Text = "Guardar";
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(366, 54);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 98;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // frmTelefono
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(442, 186);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.lbl_telefonos);
            this.Controls.Add(this.txt_telefono2);
            this.Controls.Add(this.lbl_telefono2);
            this.Controls.Add(this.lbl_telefono1);
            this.Controls.Add(this.txt_telefono1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTelefono";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "telefono";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_telefono1;
        private System.Windows.Forms.Label lbl_telefono1;
        private System.Windows.Forms.Label lbl_telefono2;
        private System.Windows.Forms.TextBox txt_telefono2;
        private System.Windows.Forms.Label lbl_telefonos;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Button btn_guardar;
    }
}