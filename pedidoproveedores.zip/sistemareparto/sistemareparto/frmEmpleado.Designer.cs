﻿namespace sistemareparto
{
    partial class frmEmpleado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEmpleado));
            this.Lbl_titulo = new System.Windows.Forms.Label();
            this.txt_tel = new System.Windows.Forms.TextBox();
            this.txt_dir = new System.Windows.Forms.TextBox();
            this.txt_fechanac = new System.Windows.Forms.TextBox();
            this.txt_nit = new System.Windows.Forms.TextBox();
            this.txt_sapellido = new System.Windows.Forms.TextBox();
            this.txt_papellido = new System.Windows.Forms.TextBox();
            this.txt_snombre = new System.Windows.Forms.TextBox();
            this.lbl_tel = new System.Windows.Forms.Label();
            this.lbl_dir = new System.Windows.Forms.Label();
            this.lbl_sapellido = new System.Windows.Forms.Label();
            this.lbl_fechanac = new System.Windows.Forms.Label();
            this.lbl_nit = new System.Windows.Forms.Label();
            this.lbl_papellido = new System.Windows.Forms.Label();
            this.lbl_snombre = new System.Windows.Forms.Label();
            this.txt_pnombre = new System.Windows.Forms.TextBox();
            this.lbl_pnombre = new System.Windows.Forms.Label();
            this.dgv_empleado = new System.Windows.Forms.DataGridView();
            this.lbl_sueldo = new System.Windows.Forms.Label();
            this.lbl_correo = new System.Windows.Forms.Label();
            this.lbl_estado = new System.Windows.Forms.Label();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.txt_sueldo = new System.Windows.Forms.TextBox();
            this.txt_estado = new System.Windows.Forms.TextBox();
            this.txt_correo = new System.Windows.Forms.TextBox();
            this.txt_puesto = new System.Windows.Forms.TextBox();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.pic_empleado = new System.Windows.Forms.PictureBox();
            this.lbl_imagen = new System.Windows.Forms.Label();
            this.lbl_aceptar = new System.Windows.Forms.Label();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_actualizar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.btn_puesto = new System.Windows.Forms.Button();
            this.btn_correo = new System.Windows.Forms.Button();
            this.btn_tel = new System.Windows.Forms.Button();
            this.btn_dir = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_empleado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_empleado)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_titulo
            // 
            this.Lbl_titulo.AutoSize = true;
            this.Lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_titulo.Location = new System.Drawing.Point(354, 9);
            this.Lbl_titulo.Name = "Lbl_titulo";
            this.Lbl_titulo.Size = new System.Drawing.Size(156, 32);
            this.Lbl_titulo.TabIndex = 45;
            this.Lbl_titulo.Text = "EMPLEADO";
            // 
            // txt_tel
            // 
            this.txt_tel.Location = new System.Drawing.Point(662, 313);
            this.txt_tel.Name = "txt_tel";
            this.txt_tel.Size = new System.Drawing.Size(150, 20);
            this.txt_tel.TabIndex = 42;
            // 
            // txt_dir
            // 
            this.txt_dir.Location = new System.Drawing.Point(662, 269);
            this.txt_dir.Name = "txt_dir";
            this.txt_dir.Size = new System.Drawing.Size(150, 20);
            this.txt_dir.TabIndex = 41;
            // 
            // txt_fechanac
            // 
            this.txt_fechanac.Location = new System.Drawing.Point(662, 223);
            this.txt_fechanac.Name = "txt_fechanac";
            this.txt_fechanac.Size = new System.Drawing.Size(150, 20);
            this.txt_fechanac.TabIndex = 40;
            // 
            // txt_nit
            // 
            this.txt_nit.Location = new System.Drawing.Point(662, 173);
            this.txt_nit.Name = "txt_nit";
            this.txt_nit.Size = new System.Drawing.Size(150, 20);
            this.txt_nit.TabIndex = 39;
            // 
            // txt_sapellido
            // 
            this.txt_sapellido.Location = new System.Drawing.Point(214, 313);
            this.txt_sapellido.Name = "txt_sapellido";
            this.txt_sapellido.Size = new System.Drawing.Size(150, 20);
            this.txt_sapellido.TabIndex = 38;
            // 
            // txt_papellido
            // 
            this.txt_papellido.Location = new System.Drawing.Point(214, 268);
            this.txt_papellido.Name = "txt_papellido";
            this.txt_papellido.Size = new System.Drawing.Size(150, 20);
            this.txt_papellido.TabIndex = 37;
            // 
            // txt_snombre
            // 
            this.txt_snombre.Location = new System.Drawing.Point(214, 222);
            this.txt_snombre.Name = "txt_snombre";
            this.txt_snombre.Size = new System.Drawing.Size(150, 20);
            this.txt_snombre.TabIndex = 36;
            // 
            // lbl_tel
            // 
            this.lbl_tel.AutoSize = true;
            this.lbl_tel.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tel.Location = new System.Drawing.Point(443, 313);
            this.lbl_tel.Name = "lbl_tel";
            this.lbl_tel.Size = new System.Drawing.Size(77, 20);
            this.lbl_tel.TabIndex = 35;
            this.lbl_tel.Text = "Telefono*";
            // 
            // lbl_dir
            // 
            this.lbl_dir.AutoSize = true;
            this.lbl_dir.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dir.Location = new System.Drawing.Point(443, 268);
            this.lbl_dir.Name = "lbl_dir";
            this.lbl_dir.Size = new System.Drawing.Size(86, 20);
            this.lbl_dir.TabIndex = 34;
            this.lbl_dir.Text = "Direccion*";
            // 
            // lbl_sapellido
            // 
            this.lbl_sapellido.AutoSize = true;
            this.lbl_sapellido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sapellido.Location = new System.Drawing.Point(32, 313);
            this.lbl_sapellido.Name = "lbl_sapellido";
            this.lbl_sapellido.Size = new System.Drawing.Size(138, 20);
            this.lbl_sapellido.TabIndex = 33;
            this.lbl_sapellido.Text = "Segundo Apellido";
            // 
            // lbl_fechanac
            // 
            this.lbl_fechanac.AutoSize = true;
            this.lbl_fechanac.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fechanac.Location = new System.Drawing.Point(443, 222);
            this.lbl_fechanac.Name = "lbl_fechanac";
            this.lbl_fechanac.Size = new System.Drawing.Size(167, 20);
            this.lbl_fechanac.TabIndex = 32;
            this.lbl_fechanac.Text = "Fecha de Nacimiento";
            // 
            // lbl_nit
            // 
            this.lbl_nit.AutoSize = true;
            this.lbl_nit.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nit.Location = new System.Drawing.Point(443, 172);
            this.lbl_nit.Name = "lbl_nit";
            this.lbl_nit.Size = new System.Drawing.Size(30, 20);
            this.lbl_nit.TabIndex = 31;
            this.lbl_nit.Text = "NIT";
            // 
            // lbl_papellido
            // 
            this.lbl_papellido.AutoSize = true;
            this.lbl_papellido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_papellido.Location = new System.Drawing.Point(32, 268);
            this.lbl_papellido.Name = "lbl_papellido";
            this.lbl_papellido.Size = new System.Drawing.Size(124, 20);
            this.lbl_papellido.TabIndex = 30;
            this.lbl_papellido.Text = "Primer Apellido*";
            // 
            // lbl_snombre
            // 
            this.lbl_snombre.AutoSize = true;
            this.lbl_snombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_snombre.Location = new System.Drawing.Point(32, 222);
            this.lbl_snombre.Name = "lbl_snombre";
            this.lbl_snombre.Size = new System.Drawing.Size(137, 20);
            this.lbl_snombre.TabIndex = 29;
            this.lbl_snombre.Text = "Segundo Nombre";
            // 
            // txt_pnombre
            // 
            this.txt_pnombre.Location = new System.Drawing.Point(214, 175);
            this.txt_pnombre.Name = "txt_pnombre";
            this.txt_pnombre.Size = new System.Drawing.Size(150, 20);
            this.txt_pnombre.TabIndex = 28;
            // 
            // lbl_pnombre
            // 
            this.lbl_pnombre.AutoSize = true;
            this.lbl_pnombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pnombre.Location = new System.Drawing.Point(32, 172);
            this.lbl_pnombre.Name = "lbl_pnombre";
            this.lbl_pnombre.Size = new System.Drawing.Size(123, 20);
            this.lbl_pnombre.TabIndex = 27;
            this.lbl_pnombre.Text = "Primer Nombre*";
            // 
            // dgv_empleado
            // 
            this.dgv_empleado.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_empleado.Location = new System.Drawing.Point(36, 474);
            this.dgv_empleado.Name = "dgv_empleado";
            this.dgv_empleado.Size = new System.Drawing.Size(800, 150);
            this.dgv_empleado.TabIndex = 26;
            // 
            // lbl_sueldo
            // 
            this.lbl_sueldo.AutoSize = true;
            this.lbl_sueldo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_sueldo.Location = new System.Drawing.Point(32, 369);
            this.lbl_sueldo.Name = "lbl_sueldo";
            this.lbl_sueldo.Size = new System.Drawing.Size(58, 20);
            this.lbl_sueldo.TabIndex = 50;
            this.lbl_sueldo.Text = "Sueldo";
            // 
            // lbl_correo
            // 
            this.lbl_correo.AutoSize = true;
            this.lbl_correo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_correo.Location = new System.Drawing.Point(443, 369);
            this.lbl_correo.Name = "lbl_correo";
            this.lbl_correo.Size = new System.Drawing.Size(67, 20);
            this.lbl_correo.TabIndex = 51;
            this.lbl_correo.Text = "Correo*";
            // 
            // lbl_estado
            // 
            this.lbl_estado.AutoSize = true;
            this.lbl_estado.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_estado.Location = new System.Drawing.Point(32, 423);
            this.lbl_estado.Name = "lbl_estado";
            this.lbl_estado.Size = new System.Drawing.Size(58, 20);
            this.lbl_estado.TabIndex = 52;
            this.lbl_estado.Text = "Estado";
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puesto.Location = new System.Drawing.Point(443, 423);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(58, 20);
            this.lbl_puesto.TabIndex = 53;
            this.lbl_puesto.Text = "Puesto";
            // 
            // txt_sueldo
            // 
            this.txt_sueldo.Location = new System.Drawing.Point(214, 370);
            this.txt_sueldo.Name = "txt_sueldo";
            this.txt_sueldo.Size = new System.Drawing.Size(150, 20);
            this.txt_sueldo.TabIndex = 54;
            // 
            // txt_estado
            // 
            this.txt_estado.Location = new System.Drawing.Point(214, 426);
            this.txt_estado.Name = "txt_estado";
            this.txt_estado.Size = new System.Drawing.Size(150, 20);
            this.txt_estado.TabIndex = 55;
            // 
            // txt_correo
            // 
            this.txt_correo.Location = new System.Drawing.Point(662, 369);
            this.txt_correo.Name = "txt_correo";
            this.txt_correo.Size = new System.Drawing.Size(150, 20);
            this.txt_correo.TabIndex = 56;
            // 
            // txt_puesto
            // 
            this.txt_puesto.Location = new System.Drawing.Point(662, 423);
            this.txt_puesto.Name = "txt_puesto";
            this.txt_puesto.Size = new System.Drawing.Size(150, 20);
            this.txt_puesto.TabIndex = 57;
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_aceptar.BackgroundImage")));
            this.btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_aceptar.Location = new System.Drawing.Point(683, 65);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.btn_aceptar.TabIndex = 76;
            this.btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(496, 65);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 75;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelar.BackgroundImage")));
            this.btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelar.Location = new System.Drawing.Point(587, 63);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelar.TabIndex = 74;
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(148, 63);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 73;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Location = new System.Drawing.Point(419, 63);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 72;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_modificar
            // 
            this.btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_modificar.BackgroundImage")));
            this.btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_modificar.Location = new System.Drawing.Point(328, 63);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.btn_modificar.TabIndex = 71;
            this.btn_modificar.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(238, 63);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 70;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // pic_empleado
            // 
            this.pic_empleado.Location = new System.Drawing.Point(26, 41);
            this.pic_empleado.Name = "pic_empleado";
            this.pic_empleado.Size = new System.Drawing.Size(105, 64);
            this.pic_empleado.TabIndex = 77;
            this.pic_empleado.TabStop = false;
            // 
            // lbl_imagen
            // 
            this.lbl_imagen.AutoSize = true;
            this.lbl_imagen.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_imagen.Location = new System.Drawing.Point(41, 108);
            this.lbl_imagen.Name = "lbl_imagen";
            this.lbl_imagen.Size = new System.Drawing.Size(66, 20);
            this.lbl_imagen.TabIndex = 27;
            this.lbl_imagen.Text = "Imagen";
            // 
            // lbl_aceptar
            // 
            this.lbl_aceptar.AutoSize = true;
            this.lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_aceptar.Location = new System.Drawing.Point(679, 133);
            this.lbl_aceptar.Name = "lbl_aceptar";
            this.lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.lbl_aceptar.TabIndex = 99;
            this.lbl_aceptar.Text = "Aceptar";
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cancelar.Location = new System.Drawing.Point(584, 133);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 98;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscar.Location = new System.Drawing.Point(492, 133);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 97;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_eliminar.Location = new System.Drawing.Point(410, 131);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 96;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_actualizar
            // 
            this.lbl_actualizar.AutoSize = true;
            this.lbl_actualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_actualizar.Location = new System.Drawing.Point(321, 131);
            this.lbl_actualizar.Name = "lbl_actualizar";
            this.lbl_actualizar.Size = new System.Drawing.Size(81, 20);
            this.lbl_actualizar.TabIndex = 95;
            this.lbl_actualizar.Text = "Actualizar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(234, 131);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 94;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(154, 131);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 93;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // btn_puesto
            // 
            this.btn_puesto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_puesto.BackgroundImage")));
            this.btn_puesto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_puesto.Location = new System.Drawing.Point(827, 414);
            this.btn_puesto.Name = "btn_puesto";
            this.btn_puesto.Size = new System.Drawing.Size(28, 29);
            this.btn_puesto.TabIndex = 100;
            this.btn_puesto.UseVisualStyleBackColor = true;
            this.btn_puesto.Click += new System.EventHandler(this.busc_btndir_Click);
            // 
            // btn_correo
            // 
            this.btn_correo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_correo.BackgroundImage")));
            this.btn_correo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_correo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_correo.Location = new System.Drawing.Point(828, 359);
            this.btn_correo.Name = "btn_correo";
            this.btn_correo.Size = new System.Drawing.Size(27, 29);
            this.btn_correo.TabIndex = 101;
            this.btn_correo.UseVisualStyleBackColor = true;
            this.btn_correo.Click += new System.EventHandler(this.Btn_btel_Click);
            // 
            // btn_tel
            // 
            this.btn_tel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_tel.BackgroundImage")));
            this.btn_tel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_tel.Location = new System.Drawing.Point(828, 308);
            this.btn_tel.Name = "btn_tel";
            this.btn_tel.Size = new System.Drawing.Size(28, 29);
            this.btn_tel.TabIndex = 102;
            this.btn_tel.UseVisualStyleBackColor = true;
            this.btn_tel.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_dir
            // 
            this.btn_dir.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_dir.BackgroundImage")));
            this.btn_dir.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_dir.Location = new System.Drawing.Point(828, 263);
            this.btn_dir.Name = "btn_dir";
            this.btn_dir.Size = new System.Drawing.Size(28, 29);
            this.btn_dir.TabIndex = 103;
            this.btn_dir.UseVisualStyleBackColor = true;
            this.btn_dir.Click += new System.EventHandler(this.button2_Click);
            // 
            // frmEmpleado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(908, 636);
            this.Controls.Add(this.btn_dir);
            this.Controls.Add(this.btn_tel);
            this.Controls.Add(this.btn_correo);
            this.Controls.Add(this.btn_puesto);
            this.Controls.Add(this.lbl_aceptar);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_actualizar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.pic_empleado);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.txt_puesto);
            this.Controls.Add(this.txt_correo);
            this.Controls.Add(this.txt_estado);
            this.Controls.Add(this.txt_sueldo);
            this.Controls.Add(this.lbl_puesto);
            this.Controls.Add(this.lbl_estado);
            this.Controls.Add(this.lbl_correo);
            this.Controls.Add(this.lbl_sueldo);
            this.Controls.Add(this.Lbl_titulo);
            this.Controls.Add(this.txt_tel);
            this.Controls.Add(this.txt_dir);
            this.Controls.Add(this.txt_fechanac);
            this.Controls.Add(this.txt_nit);
            this.Controls.Add(this.txt_sapellido);
            this.Controls.Add(this.txt_papellido);
            this.Controls.Add(this.txt_snombre);
            this.Controls.Add(this.lbl_tel);
            this.Controls.Add(this.lbl_dir);
            this.Controls.Add(this.lbl_sapellido);
            this.Controls.Add(this.lbl_fechanac);
            this.Controls.Add(this.lbl_nit);
            this.Controls.Add(this.lbl_papellido);
            this.Controls.Add(this.lbl_snombre);
            this.Controls.Add(this.txt_pnombre);
            this.Controls.Add(this.lbl_imagen);
            this.Controls.Add(this.lbl_pnombre);
            this.Controls.Add(this.dgv_empleado);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmEmpleado";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Empleado";
            this.Load += new System.EventHandler(this.Empleado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_empleado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_empleado)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label Lbl_titulo;
        private System.Windows.Forms.TextBox txt_tel;
        private System.Windows.Forms.TextBox txt_dir;
        private System.Windows.Forms.TextBox txt_fechanac;
        private System.Windows.Forms.TextBox txt_nit;
        private System.Windows.Forms.TextBox txt_sapellido;
        private System.Windows.Forms.TextBox txt_papellido;
        private System.Windows.Forms.TextBox txt_snombre;
        private System.Windows.Forms.Label lbl_tel;
        private System.Windows.Forms.Label lbl_dir;
        private System.Windows.Forms.Label lbl_sapellido;
        private System.Windows.Forms.Label lbl_fechanac;
        private System.Windows.Forms.Label lbl_nit;
        private System.Windows.Forms.Label lbl_papellido;
        private System.Windows.Forms.Label lbl_snombre;
        private System.Windows.Forms.TextBox txt_pnombre;
        private System.Windows.Forms.Label lbl_pnombre;
        private System.Windows.Forms.DataGridView dgv_empleado;
        private System.Windows.Forms.Label lbl_sueldo;
        private System.Windows.Forms.Label lbl_correo;
        private System.Windows.Forms.Label lbl_estado;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.TextBox txt_sueldo;
        private System.Windows.Forms.TextBox txt_estado;
        private System.Windows.Forms.TextBox txt_correo;
        private System.Windows.Forms.TextBox txt_puesto;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.PictureBox pic_empleado;
        private System.Windows.Forms.Label lbl_imagen;
        private System.Windows.Forms.Label lbl_aceptar;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_actualizar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.Button btn_puesto;
        private System.Windows.Forms.Button btn_correo;
        private System.Windows.Forms.Button btn_tel;
        private System.Windows.Forms.Button btn_dir;
    }
}