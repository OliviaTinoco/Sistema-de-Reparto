﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    class clsPedidoProveedorOp
    {
        
             public static int Agregar(clsPedidoProveedor pPedido)
        {


            int retorno = 0;

            MySqlCommand comando = new MySqlCommand(string.Format("Insert into pedido_prov (pk_codprov, tipopago_pedi_prov, fec_pedi_prov ) values ('{0}','{1}','{2}')",
                pPedido.icodprov, pPedido.stpago, pPedido.sfecha), clsBdComun.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;

          
        }
       

        public static int AgregarProducto(clsPedidoProveedor pProductoPedido)
        {

            

            string result = "select pk_codpediprov FROM pedido_prov WHERE pedido_prov.pk_codprov = '{0}'";
            MySqlCommand contiene = new MySqlCommand(result, clsBdComun.ObtenerConexion());
            MySqlDataReader idcodpediprov = contiene.ExecuteReader();

           int retorno1 = 0;

            MySqlCommand comando = new MySqlCommand(string.Format("Insert into prod_pedid_prov (pk_codprov, cantidad_ppp, pk_codprod) values ('{0}','{1}','{2}' )",
                pProductoPedido.icodprov, pProductoPedido.scantidad, pProductoPedido.icodpro), clsBdComun.ObtenerConexion());
            retorno1 = comando.ExecuteNonQuery();
            return retorno1;


        }



    }
}
