﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class cliente : Form
    {
        public cliente()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void mtel_btn_Click(object sender, EventArgs e)
        {
            frmTelefono tele = new frmTelefono();
            tele.ShowDialog();
        }

        private void cliente_Load(object sender, EventArgs e)
        {

        }

        private void mdir_btn_Click(object sender, EventArgs e)
        {
            frmDireccion dir = new frmDireccion();
            dir.ShowDialog();
        }

        private void acpt_btn_Click(object sender, EventArgs e)
        {

        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            frmBuscar_cliente fin = new frmBuscar_cliente();
            fin.ShowDialog();
        }

        private void cncl_btn_Click(object sender, EventArgs e)
        {

        }

        private void new_btn_Click(object sender, EventArgs e)
        {

        }

        private void del_btn_Click(object sender, EventArgs e)
        {

        }

        private void mod_btn_Click(object sender, EventArgs e)
        {

        }

        private void save_btn_Click(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscar_cliente fin = new frmBuscar_cliente();
            fin.ShowDialog();
        }

        private void busc_btndir_Click(object sender, EventArgs e)
        {
            frmDireccion dir = new frmDireccion();
            dir.ShowDialog();
        }

        private void bus_btndir_Click(object sender, EventArgs e)
        {

            frmTelefono fin = new frmTelefono();
            fin.ShowDialog();
        }
    }
}
