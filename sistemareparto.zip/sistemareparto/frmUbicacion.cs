﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmUbicacion : Form
    {
        public frmUbicacion()
        {
            InitializeComponent();
        }

        private void dgv_ubicacionproducto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public clsUbicacion UbiAct { get; set; }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();

            if (buscubi.Ubiselec != null)
            {

                UbiAct = buscubi.Ubiselec;
                txt_estante.Text= buscubi.Ubiselec.sestante;
                txt_pasillo.Text = buscubi.Ubiselec.spasillo;
                txt_slot.Text = buscubi.Ubiselec.sslot;

                string scad = "select * from bodega";
                MySqlCommand mcd = new MySqlCommand(scad, clsBdComun.ObtenerConexion());
                MySqlDataReader mdr = mcd.ExecuteReader();
                while (mdr.Read())
                {
                    cbo_bod.Items.Add(mdr.GetString("ubic_bod"));
                }


            }
            //mostradatos();



        }

        private void frmUbicacion_Load(object sender, EventArgs e)
        {

        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            string scad = "select * from bodega";
            MySqlCommand mcd = new MySqlCommand(scad, clsBdComun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            while (mdr.Read())
            {
                cbo_bod.Items.Add(mdr.GetString("ubic_bod"));
            }
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cbo_bod.Text) || string.IsNullOrWhiteSpace(txt_estante.Text) ||
                           string.IsNullOrWhiteSpace(txt_pasillo.Text) || string.IsNullOrWhiteSpace(txt_slot.Text) ) 

                MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsUbicacion pUbicacion= new clsUbicacion();
                    pUbicacion.icodbod = 1; 
                    pUbicacion.sestante = txt_estante.Text.Trim();
                    pUbicacion.spasillo = txt_pasillo.Text.Trim();
                    pUbicacion.sslot = txt_slot.Text.Trim();



                    int iresultado = clsUbicacionOp.Agregar(pUbicacion);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ubicacion Guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la Ubicacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cbo_bod.Text) || string.IsNullOrWhiteSpace(txt_estante.Text) ||
                           string.IsNullOrWhiteSpace(txt_pasillo.Text) || string.IsNullOrWhiteSpace(txt_slot.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsUbicacion pUbicacion = new clsUbicacion();
                    pUbicacion.icodbod = 1;
                    pUbicacion.sestante = txt_estante.Text.Trim();
                    pUbicacion.spasillo = txt_pasillo.Text.Trim();
                    pUbicacion.sslot = txt_slot.Text.Trim();



                    int iresultado = clsUbicacionOp.Actualizar(pUbicacion);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ubicacion Actualizada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar la Ubicacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar la ubicación Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (clsUbicacionOp.Eliminar(UbiAct.icod) > 0)
                {
                    MessageBox.Show("Usuario Eliminado Correctamente!", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Limpiar();
                    //Deshabilitar();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el Usuario", "Cliente No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            //mostradatos();
        }
    }
}
