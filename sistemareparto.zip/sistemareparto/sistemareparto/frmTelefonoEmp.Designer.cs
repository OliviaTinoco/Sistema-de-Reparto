﻿namespace sistemareparto
{
    partial class frmTelefonoEmp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmTelefonoEmp));
            this.lbl_otrostelefonos = new System.Windows.Forms.Label();
            this.txt_telefono2 = new System.Windows.Forms.TextBox();
            this.lbl_telefono2 = new System.Windows.Forms.Label();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.txt_telefono1 = new System.Windows.Forms.TextBox();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_otrostelefonos
            // 
            this.lbl_otrostelefonos.AutoSize = true;
            this.lbl_otrostelefonos.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_otrostelefonos.Location = new System.Drawing.Point(69, 9);
            this.lbl_otrostelefonos.Name = "lbl_otrostelefonos";
            this.lbl_otrostelefonos.Size = new System.Drawing.Size(254, 32);
            this.lbl_otrostelefonos.TabIndex = 11;
            this.lbl_otrostelefonos.Text = "OTROS TELEFONOS";
            // 
            // txt_telefono2
            // 
            this.txt_telefono2.Location = new System.Drawing.Point(157, 128);
            this.txt_telefono2.Name = "txt_telefono2";
            this.txt_telefono2.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono2.TabIndex = 10;
            // 
            // lbl_telefono2
            // 
            this.lbl_telefono2.AutoSize = true;
            this.lbl_telefono2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono2.Location = new System.Drawing.Point(15, 127);
            this.lbl_telefono2.Name = "lbl_telefono2";
            this.lbl_telefono2.Size = new System.Drawing.Size(116, 21);
            this.lbl_telefono2.TabIndex = 9;
            this.lbl_telefono2.Text = "Otro Telefono";
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_telefono.Location = new System.Drawing.Point(15, 77);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(116, 21);
            this.lbl_telefono.TabIndex = 7;
            this.lbl_telefono.Text = "Otro Telefono";
            // 
            // txt_telefono1
            // 
            this.txt_telefono1.Location = new System.Drawing.Point(157, 78);
            this.txt_telefono1.Name = "txt_telefono1";
            this.txt_telefono1.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono1.TabIndex = 6;
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(357, 125);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 97;
            this.lbl_guardar.Text = "Guardar";
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(361, 57);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 96;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // frmTelefonoEmp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(474, 186);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.lbl_otrostelefonos);
            this.Controls.Add(this.txt_telefono2);
            this.Controls.Add(this.lbl_telefono2);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.txt_telefono1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmTelefonoEmp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Otros Telefonos";
            this.Load += new System.EventHandler(this.TelefonoEmp_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_otrostelefonos;
        private System.Windows.Forms.TextBox txt_telefono2;
        private System.Windows.Forms.Label lbl_telefono2;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.TextBox txt_telefono1;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Button btn_guardar;
    }
}