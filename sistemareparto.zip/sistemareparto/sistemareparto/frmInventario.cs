﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace sistemareparto
{
    public partial class frmInventario : Form
    {
        public frmInventario()
        {
            InitializeComponent();
        }

        void ayudar()
        {
            string ruta = @"C:\Users\ale_\Desktop\Repositorio.pdf";
            ProcessStartInfo startinfo = new ProcessStartInfo();
            startinfo.FileName = "AcroRd32.exe";
            startinfo.Arguments = ruta;
            Process.Start(startinfo);
        }

        private void txt_preventa_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_buscproducto_Click(object sender, EventArgs e) //Boton que abre formulario para buscar producto
        {
            frmBuscarProducto bucrprod = new frmBuscarProducto();
            bucrprod.ShowDialog();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarInventario businv = new frmBuscarInventario();
            businv.ShowDialog();
        }

        private void frmInventario_Load(object sender, EventArgs e)
        {
            btn_guardar.Enabled = false;
            txt_cantidad.Enabled = false;
            txt_pasillo.Enabled = false;
            txt_precompra.Enabled = false;
            txt_preventa.Enabled = false;
            txt_precompra.Enabled = false;
            btn_nuevo.Enabled = true;
            btn_aceptar.Enabled = false;
            btn_buscubicacion.Enabled = false;
        }

        public clsUbicacion UbiAct { get; set; } //clase publica, para obtener la ubicacion
        private void btn_buscubicacion_Click(object sender, EventArgs e)
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();

            if (buscubi.Ubiselec != null)
            {

                UbiAct = buscubi.Ubiselec;
                //txt_pasillo.Text = buscubi.Ubiselec.sestante;
                txt_pasillo.Text = buscubi.Ubiselec.spasillo;
                //txt_slot.Text = buscubi.Ubiselec.sslot;

            }
            MessageBox.Show(Convert.ToString(UbiAct.icod));
        }

        private void btn_guardar_Click(object sender, EventArgs e) //Boton que guarda los registro a la base de datos
        {
            try
            {

                if (string.IsNullOrWhiteSpace(txt_cantidad.Text) || string.IsNullOrWhiteSpace(txt_precompra.Text) ||
                           string.IsNullOrWhiteSpace(txt_pasillo.Text) || string.IsNullOrWhiteSpace(txt_preventa.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                }
                else
                {

                    ClsExistencia pexist = new ClsExistencia();
                    pexist.icodubi = UbiAct.icod;
                    pexist.iprecompra = Convert.ToInt16(txt_precompra.Text.Trim());
                    pexist.ipreventa = Convert.ToInt16(txt_preventa.Text.Trim());
                    pexist.icantidad = Convert.ToInt16(txt_cantidad.Text.Trim());





                    int iresultado = clsExistenciaOp.Agregar(pexist);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Existencia Guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        // Limpiar();
                        //Deshabilitar();
                        btn_aceptar.Enabled = true;
                        btn_nuevo.Enabled = false;
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Insertar", "Existencias");

                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la existencia", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            //mostradatos();
        }

        public ClsExistencia InvSelec { get; set; }
        private void btn_aceptar_Click(object sender, EventArgs e) //Boton que lleva los datos al formulario de producto
        {
            ClsExistencia ex = new ClsExistencia();
            MySqlCommand _comando = new MySqlCommand(String.Format(
           "SELECT pk_codexis FROM existencia where cantidad_exis ='{0}' and precom_exis = '{1}' ", txt_cantidad.Text, txt_precompra.Text), clsBdComun.ObtenerConexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {

               ex.icod = _reader.GetInt16(0);
            }
            //MessageBox.Show(Convert.ToString(ex.icod));

            InvSelec = clsExistenciaOp.ObtenerExistencia(ex.icod);

            this.Close();





        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            btn_guardar.Enabled = true;
            txt_cantidad.Enabled = true;
            txt_pasillo.Enabled = true;
            txt_precompra.Enabled = true;
            txt_preventa.Enabled = true;
            txt_precompra.Enabled = true;
            btn_buscubicacion.Enabled = true;
            
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            ayudar();
        }
    }
}
