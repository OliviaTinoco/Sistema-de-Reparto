﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto { 
    public partial class frmBuscarRuta : Form
    {
        public frmBuscarRuta()
        {
            InitializeComponent();
        }

        private void frmBuscarRuta_Load(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e) //Boton que busca el dato y lo despliega en el data grid
        {
            try
            {
                dgv_ruta.DataSource = clsRutaOp.Buscar(txt_zona.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        public clsRuta RutaSelec { get; set; }
        private void btn_aceptar_Click(object sender, EventArgs e) //Boton que lleva los datos a otro formularios
        {

            try
            {
                if (dgv_ruta.SelectedRows.Count == 1)
                {
                    int id = Convert.ToInt16(dgv_ruta.CurrentRow.Cells[0].Value);
                    //string id = dataGridView1.Row.Cells[0].Value;
                    //string id1 = dataGridView1.CurrentRow.Cells[0].Value.ToString;
                    RutaSelec = clsRutaOp.ObtenerRuta(id);

                    this.Close();
                }
                else
                    MessageBox.Show("debe de seleccionar una fila");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
    }
}
