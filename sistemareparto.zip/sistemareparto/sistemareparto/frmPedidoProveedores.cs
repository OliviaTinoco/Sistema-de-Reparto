﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmPedidoProveedores : Form
    {
        public frmPedidoProveedores()
        {
            InitializeComponent();
        }

        private void frmPedidoProveedores_Load(object sender, EventArgs e)
        {

        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            frmBuscarPedido busped = new frmBuscarPedido();
            busped.ShowDialog(); 
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();
            prod.ShowDialog(); 
        }
    }
}
