﻿using System;



namespace sistemareparto.Modelo
{
    class clsGestionVehiculo
    {
        public int iIdGest { get; set; }
        public int iVehi { get; set; }
        public DateTime dFechaSale { get; set; }
        public DateTime dFechaIngre { get; set; }
        public String sEstadoIngre { get; set; }
        public String sEstadoSale { get; set; }
        public String sEstadoGestion { get; set; }

    }
}
