﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmBuscar_cliente : Form
    {
        public frmBuscar_cliente()
        {
            InitializeComponent();
        }

        public clsCliente ClienteSeleccionado { get; set; }         //Clase publica para obtener y enviar variables

        private void btn_aceptar_Click(object sender, EventArgs e)
        {

            if (dgv_inventario.SelectedRows.Count == 1)     //condicion al seleccionar una fila
            {
                int id = Convert.ToInt32(dgv_inventario.CurrentRow.Cells[0].Value); //Se toma el primer valor del datagrid (id)
                ClienteSeleccionado = clsClientedal.ObtenerCliente(id);             //Se pasa Id como parametro a la funcion

                this.Close();
            }
            else
                MessageBox.Show("debe de seleccionar una fila");    //no se selecciono ninguna fila

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            dgv_inventario.DataSource = clsClientedal.Buscar(txt_nombre.Text, txt_apellido.Text);   //se llena el datagrid con el resultado de busqueda
        }

        private void frmBuscar_cliente_Load(object sender, EventArgs e)
        {
            //Cargando datagrid con la consulta a tabla cliente

            MySqlConnection cn = clsBdComun.ObtenerConexion();                      //Inicia Conexion con base de datos
            DataTable dt = new DataTable();                                         // Crea objeto DataTable
            String query = "SELECT pk_codclte, pnom_clte, snom_clte, papel_clte, saple_clte, nit_clte FROM cliente";  //Consulta
            MySqlCommand cmd = new MySqlCommand(query, cn);                         //Ejecuta consulta
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);                        //Obtiene los datos de la consulta

            da.Fill(dt);                                            //Llena con los datos del DataTable
            dgv_inventario.DataSource = dt;                         //Llena el datagrid
        }

        private void dgv_inventario_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
