﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto.Modelo
{
    class clsMantenimientoVehiculo
    {
        public int iIdmate { get; set; }
        public int iIdvehi { get; set; }
        public DateTime dFechaUltimo { get; set; }
        public DateTime dFechaSig { get; set; }
        public String sKiloRecord { get; set; }
        public String sKiloFinal { get; set; }
        public String sObser { get; set; }
        public String sEstadoMante { get; set; }

    }
}
