﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmBitacora : Form
    {
        public frmBitacora()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void funllenarGridBitacora()
        {
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "CONSULTA", "BITACORA");
            string squery = "SELECT * from bitacora";
            MySqlCommand cmdc = new MySqlCommand(squery, Bdcomun.ObtenerConexion());
            DataTable dtDatos = new DataTable();
            MySqlDataAdapter mdaDatos = new MySqlDataAdapter(squery, Bdcomun.ObtenerConexion());
            mdaDatos.Fill(dtDatos);
            dgv_bitacora.DataSource = dtDatos;
        }
        private void Btn_ingresa_Click(object sender, EventArgs e)
        {
            mant_usuarios frm = new mant_usuarios();
            frm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            funllenarGridBitacora();
        }

        private void dgv_bitacora_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
