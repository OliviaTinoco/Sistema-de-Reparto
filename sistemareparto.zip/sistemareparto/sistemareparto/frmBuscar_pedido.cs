﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmBuscar_pedido : Form
    {
        public frmBuscar_pedido()
        {
            InitializeComponent();
        }

        public clsPedido PedidoSeleccionado { get; set; }       //Se crea la clase para obtener y enviar parametros de la clase clsPedido

        private void Btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();                                       //Cancela la operacion
        }

        private void Buscar_pedido_Load(object sender, EventArgs e)
        {
            //Se llenan los datos de la tabla Pedido en el datagrid de nuestro formulario
            MySqlConnection cn2 = clsBdComun.ObtenerConexion();     //Se crea la conexion
            DataTable dt2 = new DataTable();                        //Se crea objeto DataTable
            String query2 = "Select pk_pclte, pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod  from pedidoclte"; //Consulta en un string
            MySqlCommand cmd2 = new MySqlCommand(query2, cn2);      //Se ejecuta consulta
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);      //Se cargan los datos de la consulta
            da2.Fill(dt2);                                          //Se cargan los datos en el DataTable
            dgv_pedido.DataSource = dt2;                            //Se copian los datos al Datagrid
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            dgv_pedido.DataSource = clsPedidodal.Buscar(txt_cliente.Text, txt_producto.Text);   //Se llena el datagrid con el resultado de la busqueda

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_pedido.SelectedRows.Count == 1)             //condicion de cuando se selecciona una fila
            {
                int id = Convert.ToInt32(dgv_pedido.CurrentRow.Cells[0].Value); //se guarda el primer valor del datagrid en una variable (id)
                PedidoSeleccionado = clsPedidodal.ObtenerPedido(id);            //Se manda como parametro el id a la clase

                this.Close();                                       //Cerrar formulario
            }
            else
                MessageBox.Show("debe de seleccionar una fila");        //Si no se ha seleccionado alguna fila
        }

        private void dgv_pedido_CellContentClick(object sender, DataGridViewCellEventArgs e) //DataGrid pedido
        {

        }
    }
}
