﻿namespace sistemareparto
{
    partial class Proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Proveedor));
            this.Lbl_titulo = new System.Windows.Forms.Label();
            this.Btn_agregar = new System.Windows.Forms.Button();
            this.Btn_guardar = new System.Windows.Forms.Button();
            this.Btn_actualizar = new System.Windows.Forms.Button();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Btn_buscar = new System.Windows.Forms.Button();
            this.Btn_cancelar = new System.Windows.Forms.Button();
            this.Btn_aceptar = new System.Windows.Forms.Button();
            this.Lbl_nombre = new System.Windows.Forms.Label();
            this.Lbl_direccion = new System.Windows.Forms.Label();
            this.Lbl_telefono = new System.Windows.Forms.Label();
            this.Lbl_razon = new System.Windows.Forms.Label();
            this.Lbl_observaciones = new System.Windows.Forms.Label();
            this.Lbl_nit = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.txt_razon = new System.Windows.Forms.TextBox();
            this.txt_observaciones = new System.Windows.Forms.TextBox();
            this.txt_nit = new System.Windows.Forms.TextBox();
            this.dgv_proveedor = new System.Windows.Forms.DataGridView();
            this.Lbl_agregar = new System.Windows.Forms.Label();
            this.Lbl_guardar = new System.Windows.Forms.Label();
            this.Lbl_actualizar = new System.Windows.Forms.Label();
            this.Lbl_eliminar = new System.Windows.Forms.Label();
            this.Lbl_buscar = new System.Windows.Forms.Label();
            this.Lbl_cancelar = new System.Windows.Forms.Label();
            this.Lbl_aceptar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_proveedor)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_titulo
            // 
            this.Lbl_titulo.AutoSize = true;
            this.Lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_titulo.Location = new System.Drawing.Point(336, 9);
            this.Lbl_titulo.Name = "Lbl_titulo";
            this.Lbl_titulo.Size = new System.Drawing.Size(183, 36);
            this.Lbl_titulo.TabIndex = 0;
            this.Lbl_titulo.Text = "PROVEEDOR";
            // 
            // Btn_agregar
            // 
            this.Btn_agregar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_agregar.BackgroundImage")));
            this.Btn_agregar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_agregar.Location = new System.Drawing.Point(47, 112);
            this.Btn_agregar.Name = "Btn_agregar";
            this.Btn_agregar.Size = new System.Drawing.Size(65, 65);
            this.Btn_agregar.TabIndex = 1;
            this.Btn_agregar.UseVisualStyleBackColor = true;
            // 
            // Btn_guardar
            // 
            this.Btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_guardar.BackgroundImage")));
            this.Btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_guardar.Location = new System.Drawing.Point(174, 112);
            this.Btn_guardar.Name = "Btn_guardar";
            this.Btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.Btn_guardar.TabIndex = 2;
            this.Btn_guardar.UseVisualStyleBackColor = true;
            // 
            // Btn_actualizar
            // 
            this.Btn_actualizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_actualizar.BackgroundImage")));
            this.Btn_actualizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_actualizar.Location = new System.Drawing.Point(289, 112);
            this.Btn_actualizar.Name = "Btn_actualizar";
            this.Btn_actualizar.Size = new System.Drawing.Size(65, 65);
            this.Btn_actualizar.TabIndex = 3;
            this.Btn_actualizar.UseVisualStyleBackColor = true;
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_eliminar.BackgroundImage")));
            this.Btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_eliminar.Location = new System.Drawing.Point(404, 112);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.Btn_eliminar.TabIndex = 4;
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // Btn_buscar
            // 
            this.Btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar.BackgroundImage")));
            this.Btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar.Location = new System.Drawing.Point(513, 112);
            this.Btn_buscar.Name = "Btn_buscar";
            this.Btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscar.TabIndex = 5;
            this.Btn_buscar.UseVisualStyleBackColor = true;
            this.Btn_buscar.Click += new System.EventHandler(this.Btn_buscar_Click);
            // 
            // Btn_cancelar
            // 
            this.Btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_cancelar.BackgroundImage")));
            this.Btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cancelar.Location = new System.Drawing.Point(620, 113);
            this.Btn_cancelar.Name = "Btn_cancelar";
            this.Btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.Btn_cancelar.TabIndex = 6;
            this.Btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // Btn_aceptar
            // 
            this.Btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_aceptar.BackgroundImage")));
            this.Btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_aceptar.Location = new System.Drawing.Point(718, 113);
            this.Btn_aceptar.Name = "Btn_aceptar";
            this.Btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.Btn_aceptar.TabIndex = 7;
            this.Btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // Lbl_nombre
            // 
            this.Lbl_nombre.AutoSize = true;
            this.Lbl_nombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nombre.Location = new System.Drawing.Point(47, 237);
            this.Lbl_nombre.Name = "Lbl_nombre";
            this.Lbl_nombre.Size = new System.Drawing.Size(68, 20);
            this.Lbl_nombre.TabIndex = 8;
            this.Lbl_nombre.Text = "Nombre";
            // 
            // Lbl_direccion
            // 
            this.Lbl_direccion.AutoSize = true;
            this.Lbl_direccion.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_direccion.Location = new System.Drawing.Point(43, 283);
            this.Lbl_direccion.Name = "Lbl_direccion";
            this.Lbl_direccion.Size = new System.Drawing.Size(80, 20);
            this.Lbl_direccion.TabIndex = 9;
            this.Lbl_direccion.Text = "Direccion";
            // 
            // Lbl_telefono
            // 
            this.Lbl_telefono.AutoSize = true;
            this.Lbl_telefono.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_telefono.Location = new System.Drawing.Point(314, 237);
            this.Lbl_telefono.Name = "Lbl_telefono";
            this.Lbl_telefono.Size = new System.Drawing.Size(71, 20);
            this.Lbl_telefono.TabIndex = 10;
            this.Lbl_telefono.Text = "Telefono";
            // 
            // Lbl_razon
            // 
            this.Lbl_razon.AutoSize = true;
            this.Lbl_razon.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_razon.Location = new System.Drawing.Point(314, 281);
            this.Lbl_razon.Name = "Lbl_razon";
            this.Lbl_razon.Size = new System.Drawing.Size(53, 20);
            this.Lbl_razon.TabIndex = 11;
            this.Lbl_razon.Text = "Razon";
            // 
            // Lbl_observaciones
            // 
            this.Lbl_observaciones.AutoSize = true;
            this.Lbl_observaciones.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_observaciones.Location = new System.Drawing.Point(555, 234);
            this.Lbl_observaciones.Name = "Lbl_observaciones";
            this.Lbl_observaciones.Size = new System.Drawing.Size(121, 20);
            this.Lbl_observaciones.TabIndex = 12;
            this.Lbl_observaciones.Text = "Observaciones";
            // 
            // Lbl_nit
            // 
            this.Lbl_nit.AutoSize = true;
            this.Lbl_nit.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nit.Location = new System.Drawing.Point(585, 281);
            this.Lbl_nit.Name = "Lbl_nit";
            this.Lbl_nit.Size = new System.Drawing.Size(28, 20);
            this.Lbl_nit.TabIndex = 13;
            this.Lbl_nit.Text = "Nit";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(129, 239);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(150, 20);
            this.txt_nombre.TabIndex = 14;
            // 
            // txt_direccion
            // 
            this.txt_direccion.Location = new System.Drawing.Point(129, 283);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(150, 20);
            this.txt_direccion.TabIndex = 15;
            // 
            // txt_telefono
            // 
            this.txt_telefono.Location = new System.Drawing.Point(390, 239);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(150, 20);
            this.txt_telefono.TabIndex = 16;
            // 
            // txt_razon
            // 
            this.txt_razon.Location = new System.Drawing.Point(390, 281);
            this.txt_razon.Name = "txt_razon";
            this.txt_razon.Size = new System.Drawing.Size(150, 20);
            this.txt_razon.TabIndex = 17;
            // 
            // txt_observaciones
            // 
            this.txt_observaciones.Location = new System.Drawing.Point(682, 234);
            this.txt_observaciones.Name = "txt_observaciones";
            this.txt_observaciones.Size = new System.Drawing.Size(150, 20);
            this.txt_observaciones.TabIndex = 18;
            // 
            // txt_nit
            // 
            this.txt_nit.Location = new System.Drawing.Point(682, 278);
            this.txt_nit.Name = "txt_nit";
            this.txt_nit.Size = new System.Drawing.Size(150, 20);
            this.txt_nit.TabIndex = 19;
            // 
            // dgv_proveedor
            // 
            this.dgv_proveedor.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_proveedor.Location = new System.Drawing.Point(32, 346);
            this.dgv_proveedor.Name = "dgv_proveedor";
            this.dgv_proveedor.Size = new System.Drawing.Size(800, 150);
            this.dgv_proveedor.TabIndex = 20;
            // 
            // Lbl_agregar
            // 
            this.Lbl_agregar.AutoSize = true;
            this.Lbl_agregar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_agregar.Location = new System.Drawing.Point(51, 195);
            this.Lbl_agregar.Name = "Lbl_agregar";
            this.Lbl_agregar.Size = new System.Drawing.Size(70, 20);
            this.Lbl_agregar.TabIndex = 21;
            this.Lbl_agregar.Text = "Agregar";
            // 
            // Lbl_guardar
            // 
            this.Lbl_guardar.AutoSize = true;
            this.Lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_guardar.Location = new System.Drawing.Point(171, 195);
            this.Lbl_guardar.Name = "Lbl_guardar";
            this.Lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.Lbl_guardar.TabIndex = 22;
            this.Lbl_guardar.Text = "Guardar";
            // 
            // Lbl_actualizar
            // 
            this.Lbl_actualizar.AutoSize = true;
            this.Lbl_actualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_actualizar.Location = new System.Drawing.Point(286, 195);
            this.Lbl_actualizar.Name = "Lbl_actualizar";
            this.Lbl_actualizar.Size = new System.Drawing.Size(81, 20);
            this.Lbl_actualizar.TabIndex = 23;
            this.Lbl_actualizar.Text = "Actualizar";
            // 
            // Lbl_eliminar
            // 
            this.Lbl_eliminar.AutoSize = true;
            this.Lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_eliminar.Location = new System.Drawing.Point(401, 195);
            this.Lbl_eliminar.Name = "Lbl_eliminar";
            this.Lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.Lbl_eliminar.TabIndex = 24;
            this.Lbl_eliminar.Text = "Eliminar";
            // 
            // Lbl_buscar
            // 
            this.Lbl_buscar.AutoSize = true;
            this.Lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_buscar.Location = new System.Drawing.Point(510, 195);
            this.Lbl_buscar.Name = "Lbl_buscar";
            this.Lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.Lbl_buscar.TabIndex = 25;
            this.Lbl_buscar.Text = "Buscar";
            // 
            // Lbl_cancelar
            // 
            this.Lbl_cancelar.AutoSize = true;
            this.Lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cancelar.Location = new System.Drawing.Point(617, 195);
            this.Lbl_cancelar.Name = "Lbl_cancelar";
            this.Lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.Lbl_cancelar.TabIndex = 26;
            this.Lbl_cancelar.Text = "Cancelar";
            // 
            // Lbl_aceptar
            // 
            this.Lbl_aceptar.AutoSize = true;
            this.Lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_aceptar.Location = new System.Drawing.Point(714, 195);
            this.Lbl_aceptar.Name = "Lbl_aceptar";
            this.Lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.Lbl_aceptar.TabIndex = 27;
            this.Lbl_aceptar.Text = "Aceptar";
            // 
            // Proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(852, 511);
            this.Controls.Add(this.Lbl_aceptar);
            this.Controls.Add(this.Lbl_cancelar);
            this.Controls.Add(this.Lbl_buscar);
            this.Controls.Add(this.Lbl_eliminar);
            this.Controls.Add(this.Lbl_actualizar);
            this.Controls.Add(this.Lbl_guardar);
            this.Controls.Add(this.Lbl_agregar);
            this.Controls.Add(this.dgv_proveedor);
            this.Controls.Add(this.txt_nit);
            this.Controls.Add(this.txt_observaciones);
            this.Controls.Add(this.txt_razon);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.Lbl_nit);
            this.Controls.Add(this.Lbl_observaciones);
            this.Controls.Add(this.Lbl_razon);
            this.Controls.Add(this.Lbl_telefono);
            this.Controls.Add(this.Lbl_direccion);
            this.Controls.Add(this.Lbl_nombre);
            this.Controls.Add(this.Btn_aceptar);
            this.Controls.Add(this.Btn_cancelar);
            this.Controls.Add(this.Btn_buscar);
            this.Controls.Add(this.Btn_eliminar);
            this.Controls.Add(this.Btn_actualizar);
            this.Controls.Add(this.Btn_guardar);
            this.Controls.Add(this.Btn_agregar);
            this.Controls.Add(this.Lbl_titulo);
            this.Name = "Proveedor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Proveedor";
            this.Load += new System.EventHandler(this.Proveedor_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_proveedor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_titulo;
        private System.Windows.Forms.Button Btn_agregar;
        private System.Windows.Forms.Button Btn_guardar;
        private System.Windows.Forms.Button Btn_actualizar;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Button Btn_buscar;
        private System.Windows.Forms.Button Btn_cancelar;
        private System.Windows.Forms.Button Btn_aceptar;
        private System.Windows.Forms.Label Lbl_nombre;
        private System.Windows.Forms.Label Lbl_direccion;
        private System.Windows.Forms.Label Lbl_telefono;
        private System.Windows.Forms.Label Lbl_razon;
        private System.Windows.Forms.Label Lbl_observaciones;
        private System.Windows.Forms.Label Lbl_nit;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.TextBox txt_razon;
        private System.Windows.Forms.TextBox txt_observaciones;
        private System.Windows.Forms.TextBox txt_nit;
        private System.Windows.Forms.DataGridView dgv_proveedor;
        private System.Windows.Forms.Label Lbl_agregar;
        private System.Windows.Forms.Label Lbl_guardar;
        private System.Windows.Forms.Label Lbl_actualizar;
        private System.Windows.Forms.Label Lbl_eliminar;
        private System.Windows.Forms.Label Lbl_buscar;
        private System.Windows.Forms.Label Lbl_cancelar;
        private System.Windows.Forms.Label Lbl_aceptar;
    }
}