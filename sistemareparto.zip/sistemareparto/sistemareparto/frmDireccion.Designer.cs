﻿namespace sistemareparto
{
    partial class frmDireccion
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDireccion));
            this.lbl_titulo = new System.Windows.Forms.Label();
            this.txt_dir3 = new System.Windows.Forms.TextBox();
            this.lbl_dir3 = new System.Windows.Forms.Label();
            this.lbl_dir2 = new System.Windows.Forms.Label();
            this.txt_dir2 = new System.Windows.Forms.TextBox();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_titulo
            // 
            this.lbl_titulo.AutoSize = true;
            this.lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_titulo.Location = new System.Drawing.Point(63, 9);
            this.lbl_titulo.Name = "lbl_titulo";
            this.lbl_titulo.Size = new System.Drawing.Size(285, 32);
            this.lbl_titulo.TabIndex = 11;
            this.lbl_titulo.Text = "OTRAS DIRECCIONES";
            this.lbl_titulo.Click += new System.EventHandler(this.label3_Click);
            // 
            // txt_dir3
            // 
            this.txt_dir3.Location = new System.Drawing.Point(157, 115);
            this.txt_dir3.Name = "txt_dir3";
            this.txt_dir3.Size = new System.Drawing.Size(150, 20);
            this.txt_dir3.TabIndex = 10;
            // 
            // lbl_dir3
            // 
            this.lbl_dir3.AutoSize = true;
            this.lbl_dir3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dir3.Location = new System.Drawing.Point(15, 114);
            this.lbl_dir3.Name = "lbl_dir3";
            this.lbl_dir3.Size = new System.Drawing.Size(117, 20);
            this.lbl_dir3.TabIndex = 9;
            this.lbl_dir3.Text = "Otra Direccion";
            // 
            // lbl_dir2
            // 
            this.lbl_dir2.AutoSize = true;
            this.lbl_dir2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_dir2.Location = new System.Drawing.Point(15, 64);
            this.lbl_dir2.Name = "lbl_dir2";
            this.lbl_dir2.Size = new System.Drawing.Size(117, 20);
            this.lbl_dir2.TabIndex = 7;
            this.lbl_dir2.Text = "Otra Direccion";
            // 
            // txt_dir2
            // 
            this.txt_dir2.Location = new System.Drawing.Point(157, 65);
            this.txt_dir2.Name = "txt_dir2";
            this.txt_dir2.Size = new System.Drawing.Size(150, 20);
            this.txt_dir2.TabIndex = 6;
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(328, 123);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 99;
            this.lbl_guardar.Text = "Guardar";
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(332, 55);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 98;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // frmDireccion
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(409, 186);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.lbl_titulo);
            this.Controls.Add(this.txt_dir3);
            this.Controls.Add(this.lbl_dir3);
            this.Controls.Add(this.lbl_dir2);
            this.Controls.Add(this.txt_dir2);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmDireccion";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Direccion";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_titulo;
        private System.Windows.Forms.TextBox txt_dir3;
        private System.Windows.Forms.Label lbl_dir3;
        private System.Windows.Forms.Label lbl_dir2;
        private System.Windows.Forms.TextBox txt_dir2;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Button btn_guardar;
    }
}