﻿namespace sistemareparto
{
    partial class Buscar_pedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Buscar_pedido));
            this.dgv_pedido = new System.Windows.Forms.DataGridView();
            this.Lbl_nombre = new System.Windows.Forms.Label();
            this.Lbl_cliente = new System.Windows.Forms.Label();
            this.txt_cliente = new System.Windows.Forms.TextBox();
            this.txt_producto = new System.Windows.Forms.TextBox();
            this.Lbl_pedido_cliente = new System.Windows.Forms.Label();
            this.Btn_buscar = new System.Windows.Forms.Button();
            this.Btn_aceptar = new System.Windows.Forms.Button();
            this.Btn_cancelar = new System.Windows.Forms.Button();
            this.Lbl_aceptar = new System.Windows.Forms.Label();
            this.Lbl_cancelar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedido)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_pedido
            // 
            this.dgv_pedido.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pedido.Location = new System.Drawing.Point(26, 154);
            this.dgv_pedido.Name = "dgv_pedido";
            this.dgv_pedido.Size = new System.Drawing.Size(800, 150);
            this.dgv_pedido.TabIndex = 0;
            // 
            // Lbl_nombre
            // 
            this.Lbl_nombre.AutoSize = true;
            this.Lbl_nombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nombre.Location = new System.Drawing.Point(187, 69);
            this.Lbl_nombre.Name = "Lbl_nombre";
            this.Lbl_nombre.Size = new System.Drawing.Size(144, 20);
            this.Lbl_nombre.TabIndex = 9;
            this.Lbl_nombre.Text = "Nombre Producto:";
            // 
            // Lbl_cliente
            // 
            this.Lbl_cliente.AutoSize = true;
            this.Lbl_cliente.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cliente.Location = new System.Drawing.Point(187, 104);
            this.Lbl_cliente.Name = "Lbl_cliente";
            this.Lbl_cliente.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_cliente.Size = new System.Drawing.Size(128, 20);
            this.Lbl_cliente.TabIndex = 14;
            this.Lbl_cliente.Text = "Nombre Cliente:";
            // 
            // txt_cliente
            // 
            this.txt_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cliente.Location = new System.Drawing.Point(337, 104);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(150, 20);
            this.txt_cliente.TabIndex = 15;
            // 
            // txt_producto
            // 
            this.txt_producto.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_producto.Location = new System.Drawing.Point(337, 66);
            this.txt_producto.Name = "txt_producto";
            this.txt_producto.Size = new System.Drawing.Size(150, 20);
            this.txt_producto.TabIndex = 16;
            // 
            // Lbl_pedido_cliente
            // 
            this.Lbl_pedido_cliente.AutoSize = true;
            this.Lbl_pedido_cliente.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_pedido_cliente.Location = new System.Drawing.Point(334, 16);
            this.Lbl_pedido_cliente.Name = "Lbl_pedido_cliente";
            this.Lbl_pedido_cliente.Size = new System.Drawing.Size(226, 32);
            this.Lbl_pedido_cliente.TabIndex = 17;
            this.Lbl_pedido_cliente.Text = "BUSCAR PEDIDO";
            // 
            // Btn_buscar
            // 
            this.Btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar.BackgroundImage")));
            this.Btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_buscar.Location = new System.Drawing.Point(511, 59);
            this.Btn_buscar.Name = "Btn_buscar";
            this.Btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscar.TabIndex = 44;
            this.Btn_buscar.UseVisualStyleBackColor = true;
            // 
            // Btn_aceptar
            // 
            this.Btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_aceptar.BackgroundImage")));
            this.Btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_aceptar.Location = new System.Drawing.Point(371, 310);
            this.Btn_aceptar.Name = "Btn_aceptar";
            this.Btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.Btn_aceptar.TabIndex = 45;
            this.Btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // Btn_cancelar
            // 
            this.Btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_cancelar.BackgroundImage")));
            this.Btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cancelar.Location = new System.Drawing.Point(466, 310);
            this.Btn_cancelar.Name = "Btn_cancelar";
            this.Btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.Btn_cancelar.TabIndex = 46;
            this.Btn_cancelar.UseVisualStyleBackColor = true;
            this.Btn_cancelar.Click += new System.EventHandler(this.Btn_cancelar_Click);
            // 
            // Lbl_aceptar
            // 
            this.Lbl_aceptar.AutoSize = true;
            this.Lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_aceptar.Location = new System.Drawing.Point(367, 378);
            this.Lbl_aceptar.Name = "Lbl_aceptar";
            this.Lbl_aceptar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.Lbl_aceptar.TabIndex = 47;
            this.Lbl_aceptar.Text = "Aceptar";
            // 
            // Lbl_cancelar
            // 
            this.Lbl_cancelar.AutoSize = true;
            this.Lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cancelar.Location = new System.Drawing.Point(462, 378);
            this.Lbl_cancelar.Name = "Lbl_cancelar";
            this.Lbl_cancelar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.Lbl_cancelar.TabIndex = 48;
            this.Lbl_cancelar.Text = "Cancelar";
            // 
            // Buscar_pedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(844, 419);
            this.Controls.Add(this.Lbl_cancelar);
            this.Controls.Add(this.Lbl_aceptar);
            this.Controls.Add(this.Btn_cancelar);
            this.Controls.Add(this.Btn_aceptar);
            this.Controls.Add(this.Btn_buscar);
            this.Controls.Add(this.Lbl_pedido_cliente);
            this.Controls.Add(this.txt_producto);
            this.Controls.Add(this.txt_cliente);
            this.Controls.Add(this.Lbl_cliente);
            this.Controls.Add(this.Lbl_nombre);
            this.Controls.Add(this.dgv_pedido);
            this.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Buscar_pedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Buscar_pedido";
            this.Load += new System.EventHandler(this.Buscar_pedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedido)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_pedido;
        private System.Windows.Forms.Label Lbl_nombre;
        private System.Windows.Forms.Label Lbl_cliente;
        private System.Windows.Forms.TextBox txt_cliente;
        private System.Windows.Forms.TextBox txt_producto;
        private System.Windows.Forms.Label Lbl_pedido_cliente;
        private System.Windows.Forms.Button Btn_buscar;
        private System.Windows.Forms.Button Btn_aceptar;
        private System.Windows.Forms.Label Lbl_aceptar;
        private System.Windows.Forms.Label Lbl_cancelar;
        private System.Windows.Forms.Button Btn_cancelar;
    }
}