﻿using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace sistemareparto.Modelo
{
    class clsModeloMantimientoVehiculo
    {
        public bool fun_guardarMantenimientoVehi(clsMantenimientoVehiculo pMantenimiento)
        {
            /*FUNCION PARA INSERTAR EN BASE DE DATOS EL MANTENIMIENTO
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA INSERCIÓN
            try
            {
                //SE CREA SCRIPT DE INSERCIÓN
                string Query = "INSERT INTO mantenimiento (	fk_codvehi, kilo_recor_manten, fec_ulti_manten, kilo_final_manten, fec_sig_manten, observ_manten, estado_mante) VALUES(" + pMantenimiento.iIdvehi + ",'" +pMantenimiento.sKiloRecord + "','" + pMantenimiento.dFechaUltimo.Date.ToString("yyyy-MM-dd")+ "','" + pMantenimiento.sKiloFinal+ "','" +pMantenimiento.dFechaSig.Date.ToString("yyyy-MM-dd")+ "','" +pMantenimiento.sObser+ "','ACTIVO');";

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool fun_actualizarMantenimiento(clsMantenimientoVehiculo pMantenimiento)
        {
            /*FUNCION PARA ACTUALIZAR DATOS DEL MANTENIMIENTO EN BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA LA ACTUALIZACION 
            try
            {
                //SE CREA SCRIPT DE LA ACTUALIZACION
                string Query = "UPDATE mantenimiento SET ";
                Query += "fec_ulti_manten = '" +pMantenimiento.dFechaUltimo.Date.ToString("yyyy-MM-dd") + "', ";
                Query += "fec_sig_manten = '" + pMantenimiento.dFechaSig.Date.ToString("yyyy-MM-dd") + "', ";
                Query += "kilo_recor_manten = '" + pMantenimiento.sKiloRecord + "', ";
                Query += "kilo_final_manten = '" + pMantenimiento.sKiloFinal + "', ";
                Query += "observ_manten = '" + pMantenimiento.sObser+ "' ";
                Query += "WHERE pk_codmanten = " + pMantenimiento.iIdmate.ToString();

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                
                    System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                    return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool fun_eliminarMantenimiento(int pIdMantenimiento)
        {
            /*FUNCION PARA ELIMINAR DATOS DEL MANTENIMIENTO EN BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA ELIMINACION
            try
            {
             
                //SE CREA SCRIPT DE ELIMINACION
                string Query = "UPDATE mantenimiento SET ";
                Query += "estado_mante = 'ELIMINADO' ";
                Query += "WHERE pk_codmanten = " + pIdMantenimiento.ToString();

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public BindingSource fun_getAllMantenimientos()
            {

            /*FUNCION PARA OBTENER LISTADO COMPLETO DE VEHICULOS DE BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return null;
            }

            try
            {
                //SCRIPT PARA OBTENER TODOS LOS VEHICULOS DE LA BASE DE DATOS
                MySqlDataAdapter MyDA = new MySqlDataAdapter();
                string sqlSelectAll = "SELECT pk_codmanten AS Codigo, pk_codvehi AS CodigoVehiculo, DATE_FORMAT(fec_ulti_manten,'%d/%m/%Y') AS UltimoMantenimiento, DATE_FORMAT(fec_sig_manten,'%d/%m/%Y') AS SiguienteMantenimiento, kilo_recor_manten AS KM_Recorrido, kilo_final_manten AS KM_Final, observ_manten AS Observaciones, estado_mante AS Estado FROM mantenimiento AS m JOIN vehiculo AS v ON (m.fk_codvehi = v.pk_codvehi and v.estado_vehi !='ELIMINADO') WHERE m.estado_mante != 'ELIMINADO'";
                MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, conn);

                DataTable table = new DataTable();
                MyDA.Fill(table);

                BindingSource bSource = new BindingSource();
                bSource.DataSource = table;

                return bSource;
            }
            catch (MySqlException ex)
            {
                return null;
            }
            finally
            {
                conn.Close();
            }
        }

        public BindingSource fun_getAllMantenimientosFiltrado(int pVehiculo)
        {
            /*FUNCION PARA OBTENER LISTADO DE VEHICULOS QUE CUMPLAN CON LAS RESTRICCIONES DE BASE DE DATOS 
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return null;
            }

            try
            {
                //SCRIPT PARA OBTENER TODOS LOS MANTENIMIENTOS DE LA BASE DE DATOS
                MySqlDataAdapter MyDA = new MySqlDataAdapter();
                string sqlSelectAll = "SELECT pk_codmanten AS Codigo, pk_codvehi AS CodigoVehiculo, DATE_FORMAT(fec_ulti_manten,'%d/%m/%Y') AS UltimoMantenimiento, DATE_FORMAT(fec_sig_manten,'%d/%m/%Y') AS SiguienteMantenimiento, kilo_recor_manten AS KM_Recorrido, kilo_final_manten AS KM_Final, observ_manten AS Observaciones, estado_mante FROM mantenimiento AS m JOIN vehiculo AS v ON (m.fk_codvehi = v.pk_codvehi and v.estado_vehi !='ELIMINADO') WHERE estado_mante != 'ELIMINADO' AND (pk_codmanten = '" + pVehiculo + "' OR '" + pVehiculo + "' = '')";
                MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, conn);

                DataTable table = new DataTable();
                MyDA.Fill(table);

                BindingSource bSource = new BindingSource();
                bSource.DataSource = table;

                return bSource;
            }
            catch (MySqlException ex)
            {
                return null;
            }
            finally
            {
                conn.Close();
            }
        }

    }
}
