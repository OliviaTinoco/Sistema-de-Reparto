﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmbuscar_usuario : Form
    {
        public frmbuscar_usuario()
        {
            InitializeComponent();
        }
        public usuario UsuarioSeleccionado { get; set; }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            dgv_mostrar.DataSource = usuariodal.Buscar(txt_usuario.Text);
        }

        private void txt_usuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void dgv_mostrar_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_mostrar.SelectedRows.Count == 1)
            {
                int pk_coduser = Convert.ToInt32(dgv_mostrar.CurrentRow.Cells[0].Value);
                UsuarioSeleccionado = usuariodal.ObtenerUsuario(pk_coduser);
                //MessageBox.Show();

                this.Close();
            }
            else
                MessageBox.Show("debe de seleccionar una fila");
                
        }

        private void frmbuscar_usuario_Load(object sender, EventArgs e)
        {

        }
    }
    }

