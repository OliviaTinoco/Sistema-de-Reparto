﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class clsPlanificacion
    {
        public int id { get; set; }
        public string cliente { get; set; }
        public string fecha { get; set; }
        public string fecha2 { get; set; }
        public string producto { get; set; }
        public string cantidad { get; set; }
        public string vehiculo { get; set; }
        public string zona { get; set; }
        public string calle { get; set; }
        public string avenida { get; set; }
        public int codasigruta { get; set; }
        public int codruta { get; set; }
        public int codpuesto { get; set; }
        public int codvehiculo { get; set; }
  

        public clsPlanificacion() { }

        public clsPlanificacion(int pid, string nombre, string fec, string fec2, string ru, string ped, string ped2, string ve, string z, string c, string av, int ar, int cruta, int cpuesto, int cvehiculo)

        {
            this.id = pid;
            this.cliente = nombre;
            this.fecha = fec;
            this.fecha2 = fec2;
            this.producto = ped;
            this.cantidad = ped2;
            this.vehiculo = ve;
            this.zona = z;
            this.calle = c;
            this.avenida = av;
            this.codasigruta = ar;
            this.codruta = cruta;
            this.codpuesto = cpuesto;
            this.codvehiculo = cvehiculo;
        }
    }
}
