﻿namespace sistemareparto
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Administrador));
            this.Lbl_usuario = new System.Windows.Forms.Label();
            this.Lbl_contraseña = new System.Windows.Forms.Label();
            this.Lbl_administrador = new System.Windows.Forms.Label();
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.Btn_ingresa = new System.Windows.Forms.Button();
            this.Btn_salir = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_usuario
            // 
            this.Lbl_usuario.AutoSize = true;
            this.Lbl_usuario.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_usuario.Location = new System.Drawing.Point(12, 140);
            this.Lbl_usuario.Name = "Lbl_usuario";
            this.Lbl_usuario.Size = new System.Drawing.Size(61, 20);
            this.Lbl_usuario.TabIndex = 0;
            this.Lbl_usuario.Text = "usuario";
            // 
            // Lbl_contraseña
            // 
            this.Lbl_contraseña.AutoSize = true;
            this.Lbl_contraseña.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_contraseña.Location = new System.Drawing.Point(12, 190);
            this.Lbl_contraseña.Name = "Lbl_contraseña";
            this.Lbl_contraseña.Size = new System.Drawing.Size(93, 20);
            this.Lbl_contraseña.TabIndex = 1;
            this.Lbl_contraseña.Text = "contraseña";
            // 
            // Lbl_administrador
            // 
            this.Lbl_administrador.AutoSize = true;
            this.Lbl_administrador.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_administrador.Location = new System.Drawing.Point(134, 6);
            this.Lbl_administrador.Name = "Lbl_administrador";
            this.Lbl_administrador.Size = new System.Drawing.Size(210, 36);
            this.Lbl_administrador.TabIndex = 2;
            this.Lbl_administrador.Text = "Administrador";
            // 
            // txt_usuario
            // 
            this.txt_usuario.Location = new System.Drawing.Point(119, 140);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(150, 20);
            this.txt_usuario.TabIndex = 3;
            this.txt_usuario.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Location = new System.Drawing.Point(119, 190);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.Size = new System.Drawing.Size(150, 20);
            this.txt_contraseña.TabIndex = 4;
            // 
            // Btn_ingresa
            // 
            this.Btn_ingresa.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_ingresa.Location = new System.Drawing.Point(375, 130);
            this.Btn_ingresa.Name = "Btn_ingresa";
            this.Btn_ingresa.Size = new System.Drawing.Size(75, 30);
            this.Btn_ingresa.TabIndex = 5;
            this.Btn_ingresa.Text = "Ingresar";
            this.Btn_ingresa.UseVisualStyleBackColor = true;
            this.Btn_ingresa.Click += new System.EventHandler(this.Btn_ingresa_Click);
            // 
            // Btn_salir
            // 
            this.Btn_salir.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_salir.Location = new System.Drawing.Point(375, 180);
            this.Btn_salir.Name = "Btn_salir";
            this.Btn_salir.Size = new System.Drawing.Size(75, 30);
            this.Btn_salir.TabIndex = 6;
            this.Btn_salir.Text = "Salir";
            this.Btn_salir.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(204, 45);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(65, 65);
            this.pictureBox1.TabIndex = 7;
            this.pictureBox1.TabStop = false;
            // 
            // Administrador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(484, 336);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Btn_salir);
            this.Controls.Add(this.Btn_ingresa);
            this.Controls.Add(this.txt_contraseña);
            this.Controls.Add(this.txt_usuario);
            this.Controls.Add(this.Lbl_administrador);
            this.Controls.Add(this.Lbl_contraseña);
            this.Controls.Add(this.Lbl_usuario);
            this.Name = "Administrador";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "log_administrador";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_usuario;
        private System.Windows.Forms.Label Lbl_contraseña;
        private System.Windows.Forms.Label Lbl_administrador;
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.Button Btn_ingresa;
        private System.Windows.Forms.Button Btn_salir;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}