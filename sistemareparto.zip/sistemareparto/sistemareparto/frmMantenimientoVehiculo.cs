﻿using System;
using System.Windows.Forms;
using sistemareparto.Modelo;

namespace sistemareparto
{
    public partial class frmMantenimientoVehiculo : Form
    {
        #region Procedimientos
        private void pro_habilitaInputs()
        {
            /*METODO PARA HABILITAR TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_record.Enabled = true;
                ltp_Ultimo.Enabled = true;
                txt_final.Enabled = true;
                ltp_Siguiente.Enabled = true;
                txt_observaciones.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }
        private void pro_deshabilitaInputs()
        {
            /*METODO PARA DESHABILITAR TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_Vehiculo.Enabled = false;
                txt_record.Enabled = false;
                ltp_Ultimo.Enabled = false;
                txt_final.Enabled = false;
                ltp_Siguiente.Enabled = false;
                txt_observaciones.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }
        private void pro_limpiaInputs()
        {
            /*METODO PARA LIMPIAR VALORES DE TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_Vehiculo.Text = string.Empty;
                txt_record.Text = string.Empty;
                ltp_Ultimo.Text = string.Empty;
                txt_final.Text = string.Empty;
                ltp_Siguiente.Text = string.Empty;
                txt_observaciones.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }
        private void pro_habilitaBotones()
        {
            btn_nuevo.Enabled = true;
            btn_buscar.Enabled = true;
        }
        private void pro_loadMantenimientos()
        {
            clsModeloMantimientoVehiculo mclsModeloMantenimientoVehiculo = new clsModeloMantimientoVehiculo();
            dgv_vehiculo.DataSource = mclsModeloMantenimientoVehiculo.fun_getAllMantenimientos();
        }
        #endregion


        #region Funciones

        private bool fun_esEntero(String SNumero)
        {
            /*FUNCION PARA QUE VALIDA STRING PARA ASEGURAR QUE ES ENTERO
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            int INumero;
            return int.TryParse(SNumero, out INumero);
        }

        private bool fun_esDecimal(String SNumero)
        {
            /*FUNCION PARA QUE VALIDA STRING PARA ASEGURAR QUE ES DOUBLE
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            Double DNumero;
            return Double.TryParse(SNumero, out DNumero);
        }

        private bool fun_validaCampos()
        {
            /*FUNCION PARA VALIDAR LOS DATOS INGRESADOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            if (txt_Vehiculo.Text == String.Empty)
            {
                MessageBox.Show("Debe Indicar un Vehiculo");
                return false;
            }
            if (txt_record.Text == String.Empty)
            {
                MessageBox.Show("Debe Ingresar un Kilometro Recorrido");
                return false;
            }
            if (ltp_Ultimo.Text == String.Empty)
            {
                MessageBox.Show("Debe Indicar la Fecha del Ultimo Mantenimiento");
                return false;
            }
            if (txt_final.Text == String.Empty)
            {
                MessageBox.Show("Debe Indicar el Kilometro Final");
                return false;
            }
            if (ltp_Siguiente.Text == String.Empty)
            {
                MessageBox.Show("Debe Indicar la Fecha del Siguiente Mantenimiento");
                return false;
            }
            if (txt_observaciones.Text == String.Empty)
            {
                MessageBox.Show("Debe Indicar Algunas Observaciones");
                return false;
            }

            return true;
        }
        #endregion


        #region Eventos
        public frmMantenimientoVehiculo()
        {
            InitializeComponent();
            pro_loadMantenimientos();
        }  

        private void frmMantenimientoVehiculo_Load(object sender, EventArgs e)
        {
            
        }
        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            //DESHABILITA BOTONES INECESARIOS
            btn_nuevo.Enabled = false;
            btn_guardar.Enabled = true;
            btn_actualizar.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_cancelar.Enabled = true;
            btn_buscar.Enabled = false;
            btn_busVehi.Enabled = true;

            //DESHABILITA LOS CAMPOS PARA INGRESO DE DATOS
            pro_deshabilitaInputs();

        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            //CREAMOS OBJETO MANTENIMIENTO CON DATOS INGRESADOS


            clsMantenimientoVehiculo mMantenimiento = new clsMantenimientoVehiculo();
            
            mMantenimiento.iIdvehi = Convert.ToInt32(txt_Vehiculo.Text);
            mMantenimiento.sKiloRecord = txt_record.Text;
            mMantenimiento.dFechaUltimo = ltp_Ultimo.Value.Date;
            mMantenimiento.sKiloFinal = txt_final.Text;
            mMantenimiento.dFechaSig = ltp_Siguiente.Value.Date;
            mMantenimiento.sObser = txt_observaciones.Text;

            //INSERTA MANTENIMIENTO
            clsModeloMantimientoVehiculo mModeloVehiculoMante = new clsModeloMantimientoVehiculo();
            //GUARDA EL MANTENIMIENTO EN bBDD
            if (mModeloVehiculoMante.fun_guardarMantenimientoVehi(mMantenimiento))
            {
                MessageBox.Show("Mantenimiento guardado correctamente...");
                //LIMPIA INFORMACIÓN DE CAMPOS
                pro_limpiaInputs();
                //DESHABILITA LOS CAMPOS
                pro_deshabilitaInputs();
                //HABILITA LOS BOTONES
                pro_habilitaBotones();
                //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                pro_loadMantenimientos();

                //DESHABILITA BOTONES INECESARIOS
                btn_guardar.Enabled = true;
                btn_cancelar.Enabled = true;
            }
            else
            {
                MessageBox.Show("Error al guardar Vehículo");
            }

        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            //SE VALIDA QUE SE INGRESEN LOS CAMPOS CORRECTAMENTE
            if (fun_validaCampos())
            {
                //CREAMOS OBJETO VEHICULO CON DATOS INGRESADOS
                clsMantenimientoVehiculo mMantenimiento = new clsMantenimientoVehiculo();

                mMantenimiento.iIdmate = Convert.ToInt32(txt_Id.Text);
                mMantenimiento.iIdvehi = Convert.ToInt32(txt_Vehiculo.Text);
                mMantenimiento.dFechaUltimo = ltp_Ultimo.Value.Date;
                mMantenimiento.dFechaSig = ltp_Siguiente.Value.Date;
                mMantenimiento.sKiloRecord = txt_record.Text;
                mMantenimiento.sKiloFinal = txt_final.Text;
                mMantenimiento.sObser = txt_observaciones.Text;

                //ACTUALIZA MANTENIMIENTO
                clsModeloMantimientoVehiculo mModeloVehiculoMante = new clsModeloMantimientoVehiculo();
                //ACTUALIZA EL MANTENIMIENTO EN BDD
                if (mModeloVehiculoMante.fun_actualizarMantenimiento(mMantenimiento))
                {
                    MessageBox.Show("Mantenimiento actualizado correctamente...");
                    //LIMPIA INFORMACIÓN DE CAMPOS
                    pro_limpiaInputs();
                    //DESHABILITA LOS CAMPOS
                    pro_deshabilitaInputs();
                    //HABILITA LOS BOTONES
                    pro_habilitaBotones();
                    //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                    pro_loadMantenimientos();

                    //DESHABILITA BOTONES INECESARIOS
                    btn_actualizar.Enabled = false;
                    btn_eliminar.Enabled = false;
                    btn_cancelar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Error al actualizar Vehículo");
                }

            }
            else
            {
                MessageBox.Show("Seleccione un vehiculo correcto");
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            /*EVENTO DESENCADENADO EN CLICK DEL BOTON ELIMINAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            //SE VALIDA QUE HAYA SELECIONADO UN MANTENIMIENTO
            if (txt_Id.Text != String.Empty && fun_esEntero(txt_Id.Text))
            {
                //ELIMINA MANTENIMIENTO
                clsModeloMantimientoVehiculo mModeloVehiculoMante = new clsModeloMantimientoVehiculo();
                //ELIMINAEL VEHICULO EN BDD
                if (mModeloVehiculoMante.fun_eliminarMantenimiento(Convert.ToInt32(txt_Id.Text)))
                {
                    MessageBox.Show("Mantenimiento Eliminado correctamente...");
                    //LIMPIA INFORMACIÓN DE CAMPOS
                    pro_limpiaInputs();
                    //DESHABILITA LOS CAMPOS
                    pro_deshabilitaInputs();
                    //HABILITA LOS BOTONES
                    pro_habilitaBotones();
                    //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                    pro_loadMantenimientos();

                    //DESHABILITA BOTONES INECESARIOS
                    btn_actualizar.Enabled = false;
                    btn_eliminar.Enabled = false;
                    btn_cancelar.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Error al eliminar Vehículo");
                }
            }
            else
            {
                MessageBox.Show("Seleccione un vehiculo correcto");
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {

            /*EVENTO DESENCADENADO EN CLICK DEL BOTON CANCELAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            //LIMPIA INFORMACIÓN DE CAMPOS
            pro_limpiaInputs();
            //DESHABILITA LOS CAMPOS
            pro_deshabilitaInputs();
            //HABILITA LOS BOTONES
            pro_habilitaBotones();

            //DESHABILITA BOTONES INECESARIOS
            btn_guardar.Enabled = false;
            btn_actualizar.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_cancelar.Enabled = false;
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
             frmBuscarVehiculo busc = new frmBuscarVehiculo();
             busc.ShowDialog();

             if (busc.Vehiculo != null)
             {
                 txt_Vehiculo.Text = busc.Vehiculo.iId.ToString();


                 //HABILITAMOS CAMPOS DE INGRESO DE DATOS
                 pro_habilitaInputs();


                 //HABILITAR BOTONES NECESARIOS
                 btn_nuevo.Enabled = false;
                 btn_guardar.Enabled = true;
                 btn_actualizar.Enabled = false;
                 btn_eliminar.Enabled = false;
                 btn_cancelar.Enabled = true;
                 btn_busVehi.Enabled = false;

             }
             
          
        }

        private void btn_busVehi_Click(object sender, EventArgs e)
        {
            frmBuscarVehiculo busc = new frmBuscarVehiculo();
            busc.ShowDialog();

            if (busc.Vehiculo != null)
            {
                txt_Vehiculo.Text = busc.Vehiculo.iId.ToString();


                //HABILITAMOS CAMPOS DE INGRESO DE DATOS
                 pro_habilitaInputs();


                //HABILITAR BOTONES NECESARIOS
                btn_nuevo.Enabled = false;
                btn_guardar.Enabled = true;
                btn_actualizar.Enabled = false;
                btn_eliminar.Enabled = false;
                btn_cancelar.Enabled = true;
                btn_busVehi.Enabled = false;

            }

        }

        private void dgv_vehiculo_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_vehiculo.SelectedRows.Count > 0)
            {
                DataGridViewRow dgvrFila = dgv_vehiculo.SelectedRows[0];

                txt_Id.Text = dgvrFila.Cells[0].Value.ToString();
                txt_Vehiculo.Text = dgvrFila.Cells[1].Value.ToString();
                ltp_Ultimo.Value = Convert.ToDateTime(dgvrFila.Cells[2].Value.ToString());
                ltp_Siguiente.Value = Convert.ToDateTime(dgvrFila.Cells[3].Value.ToString());
                txt_record.Text = dgvrFila.Cells[4].Value.ToString();
                txt_final.Text = dgvrFila.Cells[5].Value.ToString();
                txt_observaciones.Text = dgvrFila.Cells[6].Value.ToString();

                //HABILITAMOS CAMPOS DE INGRESO DE DATOS
                pro_habilitaInputs();
                //HABILITAR BOTONES NECESARIOS
                btn_nuevo.Enabled = false;
                btn_guardar.Enabled = false;
                btn_actualizar.Enabled = true;
                btn_eliminar.Enabled = true;
                btn_cancelar.Enabled = true;
                btn_buscar.Enabled = false;
            }
        }

        
    }
   
    
    #endregion
}
