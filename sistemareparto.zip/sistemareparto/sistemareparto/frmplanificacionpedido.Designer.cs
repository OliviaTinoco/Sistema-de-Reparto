﻿namespace sistemareparto
{
    partial class frmplanificacionpedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmplanificacionpedido));
            this.lbl_planificacionpedido = new System.Windows.Forms.Label();
            this.lbl_ruta = new System.Windows.Forms.Label();
            this.txt_ruta = new System.Windows.Forms.TextBox();
            this.btn_ruta = new System.Windows.Forms.Button();
            this.lbl_pedido = new System.Windows.Forms.Label();
            this.txt_pedido = new System.Windows.Forms.TextBox();
            this.btn_pedido = new System.Windows.Forms.Button();
            this.lbl_vehiculo = new System.Windows.Forms.Label();
            this.txt_vehiculo = new System.Windows.Forms.TextBox();
            this.btn_vehiculo = new System.Windows.Forms.Button();
            this.lbl_fecplan = new System.Windows.Forms.Label();
            this.dgv_plan = new System.Windows.Forms.DataGridView();
            this.cbo_fecha = new System.Windows.Forms.ComboBox();
            this.lbl_empleado = new System.Windows.Forms.Label();
            this.btn_fecha = new System.Windows.Forms.Button();
            this.txt_empleado = new System.Windows.Forms.TextBox();
            this.btn_empleado = new System.Windows.Forms.Button();
            this.lbl_puesto = new System.Windows.Forms.Label();
            this.cbo_puesto = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cbo_zona = new System.Windows.Forms.ComboBox();
            this.cbo_calle = new System.Windows.Forms.ComboBox();
            this.cbo_avenida = new System.Windows.Forms.ComboBox();
            this.btn_guardarpedido = new System.Windows.Forms.Button();
            this.lbl_guardar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_plan)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_planificacionpedido
            // 
            this.lbl_planificacionpedido.AutoSize = true;
            this.lbl_planificacionpedido.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_planificacionpedido.Location = new System.Drawing.Point(209, 9);
            this.lbl_planificacionpedido.Name = "lbl_planificacionpedido";
            this.lbl_planificacionpedido.Size = new System.Drawing.Size(371, 32);
            this.lbl_planificacionpedido.TabIndex = 1;
            this.lbl_planificacionpedido.Text = "PLANIFICACION DE PEDIDO";
            // 
            // lbl_ruta
            // 
            this.lbl_ruta.AutoSize = true;
            this.lbl_ruta.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ruta.Location = new System.Drawing.Point(30, 168);
            this.lbl_ruta.Name = "lbl_ruta";
            this.lbl_ruta.Size = new System.Drawing.Size(82, 20);
            this.lbl_ruta.TabIndex = 9;
            this.lbl_ruta.Text = "Ruta Zona";
            // 
            // txt_ruta
            // 
            this.txt_ruta.Location = new System.Drawing.Point(146, 168);
            this.txt_ruta.Name = "txt_ruta";
            this.txt_ruta.Size = new System.Drawing.Size(150, 20);
            this.txt_ruta.TabIndex = 10;
            // 
            // btn_ruta
            // 
            this.btn_ruta.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_ruta.BackgroundImage")));
            this.btn_ruta.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_ruta.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_ruta.Location = new System.Drawing.Point(312, 165);
            this.btn_ruta.Name = "btn_ruta";
            this.btn_ruta.Size = new System.Drawing.Size(27, 30);
            this.btn_ruta.TabIndex = 11;
            this.btn_ruta.UseVisualStyleBackColor = true;
            this.btn_ruta.Click += new System.EventHandler(this.btn_ruta_Click);
            // 
            // lbl_pedido
            // 
            this.lbl_pedido.AutoSize = true;
            this.lbl_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedido.Location = new System.Drawing.Point(366, 207);
            this.lbl_pedido.Name = "lbl_pedido";
            this.lbl_pedido.Size = new System.Drawing.Size(61, 20);
            this.lbl_pedido.TabIndex = 12;
            this.lbl_pedido.Text = "Pedido";
            // 
            // txt_pedido
            // 
            this.txt_pedido.Location = new System.Drawing.Point(482, 207);
            this.txt_pedido.Name = "txt_pedido";
            this.txt_pedido.Size = new System.Drawing.Size(150, 20);
            this.txt_pedido.TabIndex = 13;
            this.txt_pedido.TextChanged += new System.EventHandler(this.txt_pedido_TextChanged);
            // 
            // btn_pedido
            // 
            this.btn_pedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_pedido.BackgroundImage")));
            this.btn_pedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_pedido.Location = new System.Drawing.Point(649, 203);
            this.btn_pedido.Name = "btn_pedido";
            this.btn_pedido.Size = new System.Drawing.Size(27, 30);
            this.btn_pedido.TabIndex = 14;
            this.btn_pedido.UseVisualStyleBackColor = true;
            this.btn_pedido.Click += new System.EventHandler(this.btn_pedido_Click);
            // 
            // lbl_vehiculo
            // 
            this.lbl_vehiculo.AutoSize = true;
            this.lbl_vehiculo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vehiculo.Location = new System.Drawing.Point(366, 170);
            this.lbl_vehiculo.Name = "lbl_vehiculo";
            this.lbl_vehiculo.Size = new System.Drawing.Size(74, 20);
            this.lbl_vehiculo.TabIndex = 15;
            this.lbl_vehiculo.Text = "Vehiculo";
            // 
            // txt_vehiculo
            // 
            this.txt_vehiculo.Location = new System.Drawing.Point(482, 170);
            this.txt_vehiculo.Name = "txt_vehiculo";
            this.txt_vehiculo.Size = new System.Drawing.Size(150, 20);
            this.txt_vehiculo.TabIndex = 16;
            // 
            // btn_vehiculo
            // 
            this.btn_vehiculo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_vehiculo.BackgroundImage")));
            this.btn_vehiculo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_vehiculo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_vehiculo.Location = new System.Drawing.Point(649, 165);
            this.btn_vehiculo.Name = "btn_vehiculo";
            this.btn_vehiculo.Size = new System.Drawing.Size(27, 30);
            this.btn_vehiculo.TabIndex = 17;
            this.btn_vehiculo.UseVisualStyleBackColor = true;
            this.btn_vehiculo.Click += new System.EventHandler(this.btn_vehiculo_Click);
            // 
            // lbl_fecplan
            // 
            this.lbl_fecplan.AutoSize = true;
            this.lbl_fecplan.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecplan.Location = new System.Drawing.Point(30, 134);
            this.lbl_fecplan.Name = "lbl_fecplan";
            this.lbl_fecplan.Size = new System.Drawing.Size(55, 20);
            this.lbl_fecplan.TabIndex = 18;
            this.lbl_fecplan.Text = "Fecha";
            // 
            // dgv_plan
            // 
            this.dgv_plan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_plan.Location = new System.Drawing.Point(34, 268);
            this.dgv_plan.Name = "dgv_plan";
            this.dgv_plan.Size = new System.Drawing.Size(658, 150);
            this.dgv_plan.TabIndex = 21;
            this.dgv_plan.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // cbo_fecha
            // 
            this.cbo_fecha.FormattingEnabled = true;
            this.cbo_fecha.Location = new System.Drawing.Point(146, 134);
            this.cbo_fecha.Name = "cbo_fecha";
            this.cbo_fecha.Size = new System.Drawing.Size(150, 21);
            this.cbo_fecha.TabIndex = 22;
            this.cbo_fecha.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lbl_empleado
            // 
            this.lbl_empleado.AutoSize = true;
            this.lbl_empleado.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_empleado.Location = new System.Drawing.Point(30, 202);
            this.lbl_empleado.Name = "lbl_empleado";
            this.lbl_empleado.Size = new System.Drawing.Size(83, 20);
            this.lbl_empleado.TabIndex = 23;
            this.lbl_empleado.Text = "Empleado";
            this.lbl_empleado.Click += new System.EventHandler(this.label2_Click);
            // 
            // btn_fecha
            // 
            this.btn_fecha.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_fecha.BackgroundImage")));
            this.btn_fecha.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_fecha.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_fecha.Location = new System.Drawing.Point(312, 130);
            this.btn_fecha.Name = "btn_fecha";
            this.btn_fecha.Size = new System.Drawing.Size(27, 30);
            this.btn_fecha.TabIndex = 24;
            this.btn_fecha.UseVisualStyleBackColor = true;
            this.btn_fecha.Click += new System.EventHandler(this.button1_Click);
            // 
            // txt_empleado
            // 
            this.txt_empleado.Location = new System.Drawing.Point(146, 204);
            this.txt_empleado.Name = "txt_empleado";
            this.txt_empleado.Size = new System.Drawing.Size(150, 20);
            this.txt_empleado.TabIndex = 25;
            // 
            // btn_empleado
            // 
            this.btn_empleado.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_empleado.BackgroundImage")));
            this.btn_empleado.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_empleado.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_empleado.Location = new System.Drawing.Point(312, 201);
            this.btn_empleado.Name = "btn_empleado";
            this.btn_empleado.Size = new System.Drawing.Size(27, 30);
            this.btn_empleado.TabIndex = 26;
            this.btn_empleado.UseVisualStyleBackColor = true;
            this.btn_empleado.Click += new System.EventHandler(this.button2_Click);
            // 
            // lbl_puesto
            // 
            this.lbl_puesto.AutoSize = true;
            this.lbl_puesto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_puesto.Location = new System.Drawing.Point(29, 236);
            this.lbl_puesto.Name = "lbl_puesto";
            this.lbl_puesto.Size = new System.Drawing.Size(58, 20);
            this.lbl_puesto.TabIndex = 27;
            this.lbl_puesto.Text = "Puesto";
            // 
            // cbo_puesto
            // 
            this.cbo_puesto.FormattingEnabled = true;
            this.cbo_puesto.Location = new System.Drawing.Point(146, 238);
            this.cbo_puesto.Name = "cbo_puesto";
            this.cbo_puesto.Size = new System.Drawing.Size(150, 21);
            this.cbo_puesto.TabIndex = 28;
            this.cbo_puesto.SelectedIndexChanged += new System.EventHandler(this.cbo_puesto_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(366, 237);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 20);
            this.label1.TabIndex = 31;
            this.label1.Text = "Direccion";
            // 
            // cbo_zona
            // 
            this.cbo_zona.FormattingEnabled = true;
            this.cbo_zona.Location = new System.Drawing.Point(482, 236);
            this.cbo_zona.Name = "cbo_zona";
            this.cbo_zona.Size = new System.Drawing.Size(37, 21);
            this.cbo_zona.TabIndex = 34;
            this.cbo_zona.SelectedIndexChanged += new System.EventHandler(this.cbo_dir_SelectedIndexChanged);
            // 
            // cbo_calle
            // 
            this.cbo_calle.FormattingEnabled = true;
            this.cbo_calle.Location = new System.Drawing.Point(525, 236);
            this.cbo_calle.Name = "cbo_calle";
            this.cbo_calle.Size = new System.Drawing.Size(37, 21);
            this.cbo_calle.TabIndex = 37;
            // 
            // cbo_avenida
            // 
            this.cbo_avenida.FormattingEnabled = true;
            this.cbo_avenida.Location = new System.Drawing.Point(568, 236);
            this.cbo_avenida.Name = "cbo_avenida";
            this.cbo_avenida.Size = new System.Drawing.Size(37, 21);
            this.cbo_avenida.TabIndex = 38;
            // 
            // btn_guardarpedido
            // 
            this.btn_guardarpedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardarpedido.BackgroundImage")));
            this.btn_guardarpedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardarpedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarpedido.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_guardarpedido.Location = new System.Drawing.Point(641, 49);
            this.btn_guardarpedido.Name = "btn_guardarpedido";
            this.btn_guardarpedido.Size = new System.Drawing.Size(65, 65);
            this.btn_guardarpedido.TabIndex = 39;
            this.btn_guardarpedido.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_guardarpedido.UseVisualStyleBackColor = true;
            this.btn_guardarpedido.Click += new System.EventHandler(this.btn_guardarpedido_Click);
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(637, 26);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 40;
            this.lbl_guardar.Text = "Guardar";
            // 
            // frmplanificacionpedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(860, 430);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.btn_guardarpedido);
            this.Controls.Add(this.cbo_avenida);
            this.Controls.Add(this.cbo_calle);
            this.Controls.Add(this.cbo_zona);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbo_puesto);
            this.Controls.Add(this.lbl_puesto);
            this.Controls.Add(this.btn_empleado);
            this.Controls.Add(this.txt_empleado);
            this.Controls.Add(this.btn_fecha);
            this.Controls.Add(this.lbl_empleado);
            this.Controls.Add(this.cbo_fecha);
            this.Controls.Add(this.dgv_plan);
            this.Controls.Add(this.lbl_fecplan);
            this.Controls.Add(this.btn_vehiculo);
            this.Controls.Add(this.txt_vehiculo);
            this.Controls.Add(this.lbl_vehiculo);
            this.Controls.Add(this.btn_pedido);
            this.Controls.Add(this.txt_pedido);
            this.Controls.Add(this.lbl_pedido);
            this.Controls.Add(this.btn_ruta);
            this.Controls.Add(this.txt_ruta);
            this.Controls.Add(this.lbl_ruta);
            this.Controls.Add(this.lbl_planificacionpedido);
            this.Name = "frmplanificacionpedido";
            this.Text = "PLANIFICACION PEDIDO";
            this.Load += new System.EventHandler(this.frmplanificacionpedido_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_plan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_planificacionpedido;
        private System.Windows.Forms.Label lbl_ruta;
        private System.Windows.Forms.TextBox txt_ruta;
        private System.Windows.Forms.Button btn_ruta;
        private System.Windows.Forms.Label lbl_pedido;
        private System.Windows.Forms.TextBox txt_pedido;
        private System.Windows.Forms.Button btn_pedido;
        private System.Windows.Forms.Label lbl_vehiculo;
        private System.Windows.Forms.TextBox txt_vehiculo;
        private System.Windows.Forms.Button btn_vehiculo;
        private System.Windows.Forms.Label lbl_fecplan;
        private System.Windows.Forms.DataGridView dgv_plan;
        private System.Windows.Forms.ComboBox cbo_fecha;
        private System.Windows.Forms.Label lbl_empleado;
        private System.Windows.Forms.Button btn_fecha;
        private System.Windows.Forms.TextBox txt_empleado;
        private System.Windows.Forms.Button btn_empleado;
        private System.Windows.Forms.Label lbl_puesto;
        private System.Windows.Forms.ComboBox cbo_puesto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbo_zona;
        private System.Windows.Forms.ComboBox cbo_calle;
        private System.Windows.Forms.ComboBox cbo_avenida;
        private System.Windows.Forms.Button btn_guardarpedido;
        private System.Windows.Forms.Label lbl_guardar;
    }
}