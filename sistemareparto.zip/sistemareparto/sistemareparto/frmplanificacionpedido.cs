﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using sistemareparto.Modelo;

namespace sistemareparto
{
    public partial class frmplanificacionpedido : Form
    {
        public clsPlanificacion PlanAct { get; set; }

        public clsRuta RutAct { get; set; }

        public clsPedido pedidoactual { get; set; }

        public clsVehiculo vehiculoactual { get; set; }

        public clsEmpleado empleadoactual { get; set; }

        /*-------------------Llenando Asignacion ruta -----------------*/

        public Int32 codruta;

        public Int32 codemp;

        public Int32 codpuesto;

        public Int32 codvehi;

        /* --------------------Llenando Plan-----------------------------*/

        public Int32 codpedido;

        public Int32 codplanif;

        public Int32 codclte;

        public Int32 codasigruta;

        /* ------------------------------------------------------------*/
       

        public frmplanificacionpedido()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlConnection cn = clsBdComun.ObtenerConexion();

            MySqlCommand cmd = cn.CreateCommand();
            cmd.CommandText = "SELECT pk_codplanif FROM planificacion_pedidos WHERE fec_planif='" + cbo_fecha.Text.Trim() + "';";
            cmd.CommandType = CommandType.Text;
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                codplanif = reader.GetInt32(0);
            }
            reader.Close();
            cmd.Dispose();
            cn.Dispose();
        }

        private void frmplanificacionpedido_Load(object sender, EventArgs e)
        {

            MySqlConnection cn = clsBdComun.ObtenerConexion();          //Crea Conexion con la base de datos
            DataTable dt = new DataTable();                             //C
            string query = "SELECT pk_codplanif, fec_planif from planificacion_pedidos";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            MySqlDataAdapter da1 = new MySqlDataAdapter(cmd);
            da1.Fill(dt);
            cbo_fecha.ValueMember = "pk_codplanif";
            cbo_fecha.DisplayMember = "fec_planif";
            cbo_fecha.DataSource = dt;
            cbo_zona.ValueMember = "";
            cbo_zona.DisplayMember = "";


            DataTable dt2 = new DataTable();
            string query2 = "SELECT pk_codpuesto, nom_puesto from puesto";
            MySqlCommand cmd2 = new MySqlCommand(query2, cn);
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);
            da2.Fill(dt2);
            cbo_puesto.ValueMember = "pk_codpuesto";
            cbo_puesto.DisplayMember = "nom_puesto";
            cbo_puesto.DataSource = dt2;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_ruta_Click(object sender, EventArgs e)
        {
            frmBuscarRuta ruta = new frmBuscarRuta();        //Se crea objeto de la clase Buscar Cliente
            ruta.ShowDialog();                                       //Se manda la pantalla
            if (ruta.RutaSelec != null)
            {
                RutAct = ruta.RutaSelec;
                txt_ruta.Text = ruta.RutaSelec.szona;
                codruta = Convert.ToInt32(ruta.RutaSelec.icod);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsPlanificacion pPlanificacion = new clsPlanificacion();
            pPlanificacion.fecha = cbo_fecha.Text.Trim();

            dgv_plan.DataSource = clsPlanificacionOp.Buscar(cbo_fecha.Text);
        }

        private void btn_pedido_Click(object sender, EventArgs e)
        {
            frmBuscar_pedido bus = new frmBuscar_pedido();      //Mandar a llamar el formulario Buscar pedido
            bus.ShowDialog();                                   //Mandar la pantalla
            if (bus.PedidoSeleccionado != null)                  //Condicion de cuando se realice mas de una busqueda
            {
                pedidoactual = bus.PedidoSeleccionado;
                txt_pedido.Text = bus.PedidoSeleccionado.pnom_clte;
                codpedido = bus.PedidoSeleccionado.id;
                try
                {
                    MySqlConnection con = clsBdComun.ObtenerConexion();
                    DataTable dt = new DataTable();
                   
                    //MySqlCommand _comando = new MySqlCommand(String.Format(
                    //"Select DIR.zona_dir_clte, DIR.calle_dir_clte, DIR.aven_dir_clte from direccion_clte DIR, cliente CL where CL.pnom_clte ='"+txt_pedido.Text.Trim()+"'"), clsBdComun.ObtenerConexion());
                    //string query = "SELECT CONCAT(dir.zona_dir_clte,'-',dir.calle_dir_clte,'calle-',dir.aven_dir_clte,'ave') AS zona,dir.calle_dir_clte,dir.aven_dir_clte FROM direccion_clte as dir INNER JOIN cliente cte ON dir.pk_codclte=cte.pk_codclte INNER JOIN pedidoclte p ON cte.pnom_clte = p.pnom_clte WHERE p.pnom_clte='" + txt_pedido.Text.Trim() + "';";

                    string query = "SELECT dir.zona_dir_clte AS zona, dir.pk_coddirclte AS id FROM direccion_clte as dir INNER JOIN cliente cte ON dir.pk_codclte=cte.pk_codclte INNER JOIN pedidoclte p ON cte.pnom_clte = p.pnom_clte WHERE p.pnom_clte='" + txt_pedido.Text.Trim() + "';";
                    MySqlCommand _comand = new MySqlCommand(query, con);
                    MySqlDataAdapter da = new MySqlDataAdapter(_comand);
                    da.Fill(dt);
                    cbo_zona.ValueMember = "id";
                    cbo_zona.DisplayMember = "zona";
                    cbo_zona.DataSource = dt;

                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
                
            }
        }

        private void btn_vehiculo_Click(object sender, EventArgs e)
        {
            frmBuscarVehiculo bus = new frmBuscarVehiculo();      //Mandar a llamar el formulario Buscar pedido
            bus.ShowDialog();                                   //Mandar la pantalla
            if (bus.VehiculoActivo != null)                  //Condicion de cuando se realice mas de una busqueda
            {
                vehiculoactual = bus.VehiculoActivo;
                txt_vehiculo.Text = bus.VehiculoActivo.sChasis;
                codvehi = bus.VehiculoActivo.iId;
            }
            if (txt_vehiculo.Text == "") { MessageBox.Show("Vehiculo Inactivo"); }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmBuscar_empleado bus = new frmBuscar_empleado();      //Mandar a llamar el formulario Buscar pedido
            bus.ShowDialog();                                   //Mandar la pantalla
            if (bus.EmpleadoSeleccionado != null)                  //Condicion de cuando se realice mas de una busqueda
            {
                empleadoactual = bus.EmpleadoSeleccionado;
                txt_empleado.Text = bus.EmpleadoSeleccionado.pnombre;
                codemp = bus.EmpleadoSeleccionado.id;
               
            }
        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void txt_pedido_TextChanged(object sender, EventArgs e)
        {
            MySqlConnection cn = clsBdComun.ObtenerConexion();

            MySqlCommand cmd = cn.CreateCommand();
            cmd.CommandText = "SELECT ct.pk_codclte FROM cliente ct, pedidoclte ped WHERE ped.pnom_clte = ct.pnom_clte and ped.pnom_clte='" + txt_pedido.Text.Trim() + "';";
            cmd.CommandType = CommandType.Text;
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                codclte = reader.GetInt32(0);
              
            }
            reader.Close();
            cmd.Dispose();
            cn.Dispose();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
         
        }
        
        private void cbo_dir_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlConnection con = clsBdComun.ObtenerConexion();
            DataTable dt2 = new DataTable();
            string query2 = "SELECT dir.calle_dir_clte AS calle FROM direccion_clte dir where dir.zona_dir_clte='" + cbo_zona.Text.Trim() + "';";
            MySqlCommand _comand2 = new MySqlCommand(query2, con);
            MySqlDataAdapter da2 = new MySqlDataAdapter(_comand2);
            da2.Fill(dt2);
            cbo_calle.ValueMember = "calle";
            cbo_calle.DisplayMember = "calle";
            cbo_calle.DataSource = dt2;

            DataTable dt3 = new DataTable();
            string query3 = "SELECT dir.aven_dir_clte AS avenida FROM direccion_clte dir where dir.zona_dir_clte='" + cbo_zona.Text.Trim() + "';";
            MySqlCommand _comand3 = new MySqlCommand(query3, con);
            MySqlDataAdapter da3 = new MySqlDataAdapter(_comand3);
            da3.Fill(dt3);
            cbo_avenida.ValueMember = "avenida";
            cbo_avenida.DisplayMember = "avenida";
            cbo_avenida.DataSource = dt3;

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void cbo_puesto_SelectedIndexChanged(object sender, EventArgs e)
        {
            MySqlConnection cn = clsBdComun.ObtenerConexion();

            MySqlCommand cmd = cn.CreateCommand();
            cmd.CommandText = "SELECT pk_codpuesto FROM puesto WHERE nom_puesto='" + cbo_puesto.Text.Trim() + "';";
            cmd.CommandType = CommandType.Text;
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                codpuesto = reader.GetInt32(0);
               
            }
            reader.Close();
            cmd.Dispose();
            cn.Dispose();
        }
        public static int Agregar(Int32 ruta, Int32 codemp, Int32 codpuesto, Int32 codvehi)
        {

            int retorno = 0;

            MySqlConnection conectar = clsBdComun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format("insert into asignacion_ruta (pk_codruta, pk_codemp, pk_codpuesto, pk_codvehi) values ('{0}','{1}','{2}', '{3}')",
            ruta, codemp, codpuesto, codvehi), conectar);
            retorno = comando.ExecuteNonQuery();
            conectar.Close();
            return retorno;
        }

        public static int Agregar2(Int32 pedido, Int32 planif, Int32 cliente, Int32 asigruta, Int32 ruta, Int32 emp, Int32 puesto, String zona, String calle, String avenida, String estado)
        {

            int retorno = 0;

            MySqlConnection conectar = clsBdComun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format("insert into plan (pk_pclte, pk_codplanif, pk_codclte,pk_codasigruta,pk_codruta, pk_codemp, pk_codpuesto, zona_plan, calle_plan, avenida_plan, estado_plan) values ('{0}','{1}','{2}', '{3}', '{4}', '{5}', '{6}', '{7}', '{8}', '{9}', '{10}')",
            pedido, planif, cliente, asigruta, ruta, emp, puesto, zona, calle, avenida, estado), conectar);
            retorno = comando.ExecuteNonQuery();
            conectar.Close();
            return retorno;
        }

        private void btn_guardarpedido_Click(object sender, EventArgs e)
        {
            Agregar(codruta, codemp, codpuesto, codvehi);

            MySqlConnection cn = clsBdComun.ObtenerConexion();

            MySqlCommand cmd = cn.CreateCommand();
            cmd.CommandText = "Select MAX(pk_codasigruta) AS id From asignacion_ruta";
            cmd.CommandType = CommandType.Text;
            MySqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                codasigruta = reader.GetInt32(0);
                MessageBox.Show(Convert.ToString(codasigruta));
            }
            reader.Close();
            cmd.Dispose();
            cn.Dispose();

            String estados = "no realizado";
            Agregar2(codpedido, codplanif, codclte, codasigruta, codruta, codemp, codpuesto, cbo_zona.Text, cbo_calle.Text, cbo_avenida.Text, estados);

        }
    }
}
