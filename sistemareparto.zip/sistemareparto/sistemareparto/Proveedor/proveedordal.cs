﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Net;

namespace sistemareparto
{
    public class proveedordal
    {

        public static int Agregar(Proveedor proveedor)  // procesode insertar un nuevo proveedor al sistema
        {

            int retorno = 0;
            //int retorno2 = 0;
            MySqlCommand comando = new MySqlCommand(string.Format("Insert into proveedor (nombre_prov, direc_prov, razon_social_prov, observ_prov, nit_prov) values ('{0}','{1}','{2}', '{3}','{4}')",
            proveedor.nombre_prov, proveedor.direc_prov, proveedor.razon_social_prov, proveedor.observ_prov, proveedor.nit_prov), Bdcomun.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
            /*if (retorno != 0) { 
            MySqlCommand comando2 = new MySqlCommand(string.Format("Insert into telefono_prov(telefono1,telefono2) values ('{5}','{6}')",
                proveedor.telefono1, proveedor.telefono2), Bdcomun.ObtenerConexion());
            retorno2 = comando2.ExecuteNonQuery();
            return retorno2;
            }*/

            /*int resultado = proveedordal.Agregar();
            if (resultado > 0)
            {
                MySqlConnection conectar = Bdcomun.ObtenerConexion();

                MySqlCommand _comando = new MySqlCommand(String.Format("SELECT pk_codprov FROM proveedor  where papel_clte = '{0}' ", txt_papellido.Text), conectar);
                MySqlDataReader _reader = _comando.ExecuteReader();
                while (_reader.Read())
                {

                     = _reader.GetInt16(0);
                    pDircliente1.idc = _reader.GetInt16(0);
                    pDircliente2.idc = _reader.GetInt16(0);




                }
                // MessageBox.Show("Cliente Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }*/
            //int resultado1 = telefonodal.AgregarTelefono(telefono1);
            //int resultado2 = telefonodal.AgregarTelefono(telefono2);
            //int resultado3 = clsDircdal.Agregar(pDircliente2);
        }

        public static void obtenerBitacora(String txtUsuario, String Accion, String table )
        {
            //int retorno = 0;
            string ip = ObtenerIP();
            string coduser = "";
            MySqlCommand _comando = new MySqlCommand(String.Format("select coduser from USUARIO where username_user = '{0}'", txtUsuario), Bdcomun.ObtenerConexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            if (_reader.Read())
                coduser = _reader.GetString(0);

            _comando = new MySqlCommand(String.Format("INSERT INTO BITACORA (accion, tabla, fecha, hora, ip, coduser) VALUES('{0}','{1}',CURDATE(),DATE_FORMAT(CURTIME(), '%h:%i:%s'), '{2}','{3}')", Accion, table, ip, coduser), Bdcomun.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            //return retorno;
        }

        public static string ObtenerIP()
        {
            IPHostEntry host;
            string localIP = "?";
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily.ToString() == "InterNetwork")
                {
                    localIP = ip.ToString();
                }
            }
            return localIP;
        }

        /*public static void funobtenerBitacora(String txtUsuario, String Accion, String table)
        {
            string ip = ObtenerIP();
            string codigo = "";
            _comando = new OdbcCommand(String.Format("select codigo_usuario from USUARIO where nombre_usuario = '{0}'", txtUsuario), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            if (_reader.Read())
                codigo = _reader.GetString(0);

            _comando = new OdbcCommand(String.Format("INSERT INTO BITACORA (accion, tabla, fecha, hora, ip, codigo_usuario) VALUES('{0}','{1}',CURDATE(),DATE_FORMAT(CURTIME(), '%h:%i:%s'), '{2}','{3}')", Accion, table, ip, codigo), ConexionODBC.Conexion.ObtenerConexion());
            _reader = _comando.ExecuteReader();
        }*/

        //---------------------------------actualizar cliente -----------------------------------------------------------------
        /*public static int Actualizar(Proveedor proveedor)
        {
            int retorno = 0;
            MySqlConnection conexion = Bdcomun.ObtenerConexion();

            MySqlCommand comando = new MySqlCommand(string.Format("Update proveedor set nombre_prov='{0}', direc_prov='{1}', razon_social_prov='{2}', observ_prov='{3}', nit_prov='{4}' where codprov={5}",
                proveedor.nombre_prov, proveedor.direc_prov, proveedor.razon_social_prov, proveedor.observ_prov, proveedor.nit_prov, proveedor.codprov), conexion);

            retorno = comando.ExecuteNonQuery();
            conexion.Close();

            return retorno;


        }*/
        public static List<Proveedor> Buscar(string nombre_prov)

        {

            List<Proveedor> _lista = new List<Proveedor>();



            MySqlCommand _comando = new MySqlCommand(String.Format(

           "SELECT codprov, nombre_prov, direc_prov, razon_social_prov, observ_prov, nit_prov FROM proveedor  where nombre_prov ='{0}'", nombre_prov), Bdcomun.ObtenerConexion());

            MySqlDataReader _reader = _comando.ExecuteReader();

            while (_reader.Read())

            {

                Proveedor proveedor = new Proveedor();

                proveedor.codprov = _reader.GetInt32(0);

                proveedor.nombre_prov = _reader.GetString(1);

                proveedor.direc_prov = _reader.GetString(2);

                proveedor.razon_social_prov = _reader.GetString(3);

                proveedor.observ_prov = _reader.GetString(4);

                proveedor.nit_prov = _reader.GetString(5);






                _lista.Add(proveedor);

            }



            return _lista;



        }
        public static Proveedor ObtenerProveedor(int codprov)

        {

            Proveedor proveedor = new Proveedor();

            MySqlConnection conexion = Bdcomun.ObtenerConexion();




            MySqlCommand _comando = new MySqlCommand(String.Format("SELECT codprov, nombre_prov, direc_prov, razon_social_prov, observ_prov, nit_prov FROM proveedor where codprov={0}", codprov), conexion);

            MySqlDataReader _reader = _comando.ExecuteReader();

            while (_reader.Read())

            {

                proveedor.codprov = _reader.GetInt32(0);

                proveedor.nombre_prov = _reader.GetString(1);

                proveedor.direc_prov = _reader.GetString(2);

                //proveedor.telefono

                proveedor.razon_social_prov = _reader.GetString(3);

                proveedor.observ_prov = _reader.GetString(4);

                proveedor.nit_prov = _reader.GetString(5);

            }




            conexion.Close();

            return proveedor;





        }

        public static int Actualizar(Proveedor proveedor)
        {
            int retorno = 0;
            MySqlConnection conexion = Bdcomun.ObtenerConexion();

            MySqlCommand comando = new MySqlCommand(string.Format("Update proveedor set nombre_prov='{0}', direc_prov='{1}', razon_social_prov='{2}', observ_prov='{3}', nit_prov='{4}' where codprov={5}",
                proveedor.nombre_prov, proveedor.direc_prov, proveedor.razon_social_prov, proveedor.observ_prov, proveedor.nit_prov, proveedor.codprov), conexion);

            retorno = comando.ExecuteNonQuery();
            conexion.Close();

            return retorno;


        }
        public static int Eliminar(int codprov)

        {

            int retorno = 0;
            MySqlConnection conexion = Bdcomun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format(" Delete From proveedor where codprov={0}", codprov), conexion);
            retorno = comando.ExecuteNonQuery();
            conexion.Close();
            return retorno;
        }


    }
}
