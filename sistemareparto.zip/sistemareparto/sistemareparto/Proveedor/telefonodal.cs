﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public class telefonodal
    {
        
            public static int AgregarTelefono(clsTelefonoProveedor telefono)
            {

                int retorno = 0;
                MySqlCommand comando = new MySqlCommand(string.Format("Insert into telefono_prov (codprov, telefono, telefono2) values ('{0}','{1}','{2}')",
                telefono.codprov, telefono.telefono, telefono.telefono), Bdcomun.ObtenerConexion());
                retorno = comando.ExecuteNonQuery();
                return retorno;
            }

    }
    
}
