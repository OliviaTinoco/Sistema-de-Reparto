﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class Proveedor
    {
        public int codprov { get; set; }
        public string nombre_prov { get; set; }
        public string direc_prov { get; set; }
        public string razon_social_prov { get; set; }
        public string observ_prov { get; set; }
        public string nit_prov { get; set; }
        public string telefono1 { get; set; }
        public string telefono2 { get; set; }
        public Proveedor() { }

        public Proveedor(int codprov, string nombre_prov, string direc_prov, string razon_social_prov, string observ_prov, string nit_prov, string telefono1, string telefono2)

        {
            this.codprov = codprov;
            this.nombre_prov = nombre_prov;
            this.direc_prov = direc_prov;
            this.razon_social_prov = razon_social_prov;
            this.observ_prov = observ_prov;
            this.nit_prov = nit_prov;
            this.telefono1 = telefono1;
            this.telefono2 = telefono2;
        }
    }
    
}