﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class clsTelefonoProveedor
    {
        public int codtelprov { get; set; }
        public int codprov { get; set; }
        public string telefono { get; set; }
        public string telefono2 { get; set; }

        public clsTelefonoProveedor() { }

        public clsTelefonoProveedor(int codtelprov, int codprov, string telefono, string telefono2)

        {
            this.codtelprov = codtelprov;
            this.codprov = codprov;
            this.telefono = telefono;
            this.telefono2 = telefono2;
        }
    }
}
