﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmbuscar_proveedor : Form
    {
        public frmbuscar_proveedor()
        {
            InitializeComponent();
        }

        //public Proveedor ProveedorSeleccionado { get; set; }
        public Proveedor ProveedorSeleccionado { get; set; }

        private void btn_buscarprov_Click(object sender, EventArgs e)
        {
            dgv_buscarprov.DataSource = proveedordal.Buscar(txt_buscar.Text);


        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_buscarprov.SelectedRows.Count == 1)
            {
                int codprov = Convert.ToInt32(dgv_buscarprov.CurrentRow.Cells[0].Value);
                ProveedorSeleccionado = proveedordal.ObtenerProveedor(codprov);
                //MessageBox.Show();

                this.Close();
            }
            else
                MessageBox.Show("debe de seleccionar una fila");

        }

        private void dgv_buscarprov_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txt_buscar_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
