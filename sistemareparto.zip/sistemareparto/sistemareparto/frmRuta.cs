﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace sistemareparto
{
    public partial class frmRuta : Form
    {
        public frmRuta()
        {
            InitializeComponent();
           // Deshabilitar();
            mostradatos();
        }

        void ayudar()
        {
            string ruta = @"C:\Users\ale_\Desktop\Repositorio.pdf";
            ProcessStartInfo startinfo = new ProcessStartInfo();
            startinfo.FileName = "AcroRd32.exe";
            startinfo.Arguments = ruta;
            Process.Start(startinfo);
        }

        void Limpiar()
        {
            txt_desc.Clear();
            txt_zona.Clear();
           
        }

        void Habilitar()
        {

            txt_desc.Enabled = true;
            txt_zona.Enabled = true;
            btn_guardar.Enabled = true;
            btn_cancelar.Enabled = true;
            
        }

        void Deshabilitar()
        {
            txt_desc.Enabled = false;
            txt_zona.Enabled = false;
            btn_guardar.Enabled = false;
            btn_cancelar.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_modificar.Enabled = false;
            

        }


        private void mostradatos() //Para mostrar dado en el DataGried
        {

            MySqlConnection conexion = clsBdComun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM ruta", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "ruta");
            dgv_ruta.DataSource = dsuario;
            dgv_ruta.DataMember = "ruta";
           
        }

        public clsRuta RutAct { get; set; }
        private void btn_buscar_Click(object sender, EventArgs e)
        {

            try
            {
                frmBuscarRuta buscrut = new frmBuscarRuta();
                buscrut.ShowDialog();


                if (buscrut.RutaSelec != null)
                {

                    RutAct = buscrut.RutaSelec;
                    txt_zona.Text = buscrut.RutaSelec.szona;
                    txt_desc.Text = buscrut.RutaSelec.sdecripcion;


                }
                //mostradatos();
                mostradatos();
                btn_modificar.Enabled = true;
                btn_eliminar.Enabled = true;
                btn_cancelar.Enabled = true;
                btn_guardar.Enabled = false;                
                btn_nuevo.Enabled = false;                
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            btn_nuevo.Enabled = false;
            btn_guardar.Enabled = false;
            Habilitar();
        }

        private void frmRuta_Load(object sender, EventArgs e)
        {
            Deshabilitar();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            clsBdComun.ObtenerConexion();
            MessageBox.Show("Conectado");
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_zona.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                }
                else
                {

                    clsRuta pRuta = new clsRuta();

                    pRuta.szona = txt_zona.Text.Trim();
                    pRuta.sdecripcion = txt_desc.Text.Trim();



                    int iresultado = clsRutaOp.Agregar(pRuta);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Usuario Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Limpiar();
                        Deshabilitar();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Insertar", "Ruta");
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar el usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            mostradatos();
            Limpiar();
            Deshabilitar();
        }

        private void txt_zona_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_modificar_Click(object sender, EventArgs e) //Boton que modifica los datos en la base de datos
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_zona.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                }
                else
                {

                    clsRuta pRuta = new clsRuta();

                    pRuta.szona = txt_zona.Text.Trim();
                    pRuta.sdecripcion = txt_desc.Text.Trim();



                    int iresultado = clsRutaOp.Actualizar(pRuta);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ruta actualizada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Limpiar();
                        Deshabilitar();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Modificar", "Ruta");
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar la ruta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                 mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            Limpiar();
            Deshabilitar();
        }

        private void btn_eliminar_Click(object sender, EventArgs e) //boton que elimina el registro.
        {

            try
            {
                if (MessageBox.Show("Esta Seguro que desea eliminar la ruta Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (clsRutaOp.Eliminar(RutAct.icod) > 0)
                    {
                        MessageBox.Show("Ruta Eliminado Correctamente!", "Ruta Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        Limpiar();
                        Deshabilitar();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "Ruta");

                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar la ruta", "Ruta No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                mostradatos();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            Limpiar();
            Deshabilitar();
        }

        private void btn_nuevo_Click(object sender, EventArgs e) //Boton que genera una nueva operacion
        {
            try
            {
                mostradatos();
                Habilitar();
                btn_modificar.Enabled = false;
                btn_eliminar.Enabled = false;
                btn_buscar.Enabled = false;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }            
        }

        private void btn_cancelar_Click(object sender, EventArgs e) //Boton que cancela  la operacion
        {
            try
            {
                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            Limpiar();
            Deshabilitar();
            btn_nuevo.Enabled = true;
            btn_buscar.Enabled = true;
        }

        private void btn_aceptar_Click(object sender, EventArgs e) 
        {
            try
            {
                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clsBdComun.ObtenerConexion();
            MessageBox.Show("Conectado");
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            ayudar();
        }
    }
}
