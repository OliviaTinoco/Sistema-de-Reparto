﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmRuta : Form
    {
        public frmRuta()
        {
            InitializeComponent();
        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarRuta buscrut = new frmBuscarRuta();
            buscrut.ShowDialog();
        }

        private void frmRuta_Load(object sender, EventArgs e)
        {

        }
    }
}
