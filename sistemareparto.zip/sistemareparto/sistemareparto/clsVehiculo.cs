﻿using System;
using MySql.Data.MySqlClient;


namespace sistemareparto.Modelo
{
    public class clsVehiculo
    {
        public int iId { get; set; }
        public String sPlaca { get; set; }
        public String sLinea { get; set; }
        public String sChasis { get; set; }
        public String sMarca { get; set; }
        public String sColor { get; set; }
        public String sEstado { get; set; }
        
    }

}
