﻿namespace sistemareparto
{
    partial class mant_usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mant_usuarios));
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.Btn_buscar = new System.Windows.Forms.Button();
            this.dgv_usuarios = new System.Windows.Forms.DataGridView();
            this.Btn_guardar = new System.Windows.Forms.Button();
            this.Btn_modificar = new System.Windows.Forms.Button();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Lbl_usuario2 = new System.Windows.Forms.Label();
            this.Lbl_contraseña = new System.Windows.Forms.Label();
            this.Lbl_tipousu = new System.Windows.Forms.Label();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.txt_tipousu = new System.Windows.Forms.TextBox();
            this.Btn_registro = new System.Windows.Forms.Button();
            this.Lbl_modificar = new System.Windows.Forms.Label();
            this.Lbl_eliminar = new System.Windows.Forms.Label();
            this.Lbl_guardar = new System.Windows.Forms.Label();
            this.Lbl_buscar = new System.Windows.Forms.Label();
            this.Lbl_registro = new System.Windows.Forms.Label();
            this.Lbl_titulo = new System.Windows.Forms.Label();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.bnt_imagen = new System.Windows.Forms.Button();
            this.pic_imagen = new System.Windows.Forms.PictureBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.acpt_btn = new System.Windows.Forms.Button();
            this.cncl_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_usuarios)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagen)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_usuario
            // 
            this.txt_usuario.Location = new System.Drawing.Point(146, 167);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(150, 20);
            this.txt_usuario.TabIndex = 2;
            // 
            // Btn_buscar
            // 
            this.Btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar.BackgroundImage")));
            this.Btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar.Location = new System.Drawing.Point(146, 48);
            this.Btn_buscar.Name = "Btn_buscar";
            this.Btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscar.TabIndex = 3;
            this.Btn_buscar.UseVisualStyleBackColor = true;
            this.Btn_buscar.Click += new System.EventHandler(this.Btn_buscar_Click);
            // 
            // dgv_usuarios
            // 
            this.dgv_usuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_usuarios.Location = new System.Drawing.Point(30, 287);
            this.dgv_usuarios.Name = "dgv_usuarios";
            this.dgv_usuarios.Size = new System.Drawing.Size(800, 150);
            this.dgv_usuarios.TabIndex = 4;
            // 
            // Btn_guardar
            // 
            this.Btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_guardar.BackgroundImage")));
            this.Btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_guardar.Location = new System.Drawing.Point(487, 48);
            this.Btn_guardar.Name = "Btn_guardar";
            this.Btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.Btn_guardar.TabIndex = 5;
            this.Btn_guardar.UseVisualStyleBackColor = true;
            // 
            // Btn_modificar
            // 
            this.Btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_modificar.BackgroundImage")));
            this.Btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_modificar.Location = new System.Drawing.Point(231, 48);
            this.Btn_modificar.Name = "Btn_modificar";
            this.Btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.Btn_modificar.TabIndex = 6;
            this.Btn_modificar.UseVisualStyleBackColor = true;
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_eliminar.BackgroundImage")));
            this.Btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_eliminar.Location = new System.Drawing.Point(317, 48);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.Btn_eliminar.TabIndex = 7;
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // Lbl_usuario2
            // 
            this.Lbl_usuario2.AutoSize = true;
            this.Lbl_usuario2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_usuario2.Location = new System.Drawing.Point(67, 169);
            this.Lbl_usuario2.Name = "Lbl_usuario2";
            this.Lbl_usuario2.Size = new System.Drawing.Size(63, 20);
            this.Lbl_usuario2.TabIndex = 8;
            this.Lbl_usuario2.Text = "Usuario";
            // 
            // Lbl_contraseña
            // 
            this.Lbl_contraseña.AutoSize = true;
            this.Lbl_contraseña.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_contraseña.Location = new System.Drawing.Point(301, 169);
            this.Lbl_contraseña.Name = "Lbl_contraseña";
            this.Lbl_contraseña.Size = new System.Drawing.Size(95, 20);
            this.Lbl_contraseña.TabIndex = 9;
            this.Lbl_contraseña.Text = "Contraseña";
            // 
            // Lbl_tipousu
            // 
            this.Lbl_tipousu.AutoSize = true;
            this.Lbl_tipousu.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_tipousu.Location = new System.Drawing.Point(571, 167);
            this.Lbl_tipousu.Name = "Lbl_tipousu";
            this.Lbl_tipousu.Size = new System.Drawing.Size(99, 20);
            this.Lbl_tipousu.TabIndex = 10;
            this.Lbl_tipousu.Text = "Tipo_Usuario";
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Location = new System.Drawing.Point(402, 167);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.Size = new System.Drawing.Size(150, 20);
            this.txt_contraseña.TabIndex = 11;
            // 
            // txt_tipousu
            // 
            this.txt_tipousu.Location = new System.Drawing.Point(676, 167);
            this.txt_tipousu.Name = "txt_tipousu";
            this.txt_tipousu.Size = new System.Drawing.Size(150, 20);
            this.txt_tipousu.TabIndex = 12;
            // 
            // Btn_registro
            // 
            this.Btn_registro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_registro.BackgroundImage")));
            this.Btn_registro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_registro.Location = new System.Drawing.Point(402, 48);
            this.Btn_registro.Name = "Btn_registro";
            this.Btn_registro.Size = new System.Drawing.Size(65, 65);
            this.Btn_registro.TabIndex = 13;
            this.Btn_registro.UseVisualStyleBackColor = true;
            // 
            // Lbl_modificar
            // 
            this.Lbl_modificar.AutoSize = true;
            this.Lbl_modificar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_modificar.Location = new System.Drawing.Point(227, 124);
            this.Lbl_modificar.Name = "Lbl_modificar";
            this.Lbl_modificar.Size = new System.Drawing.Size(80, 20);
            this.Lbl_modificar.TabIndex = 14;
            this.Lbl_modificar.Text = "Modificar";
            // 
            // Lbl_eliminar
            // 
            this.Lbl_eliminar.AutoSize = true;
            this.Lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_eliminar.Location = new System.Drawing.Point(319, 124);
            this.Lbl_eliminar.Name = "Lbl_eliminar";
            this.Lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.Lbl_eliminar.TabIndex = 15;
            this.Lbl_eliminar.Text = "Eliminar";
            // 
            // Lbl_guardar
            // 
            this.Lbl_guardar.AutoSize = true;
            this.Lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_guardar.Location = new System.Drawing.Point(483, 124);
            this.Lbl_guardar.Name = "Lbl_guardar";
            this.Lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.Lbl_guardar.TabIndex = 16;
            this.Lbl_guardar.Text = "Guardar";
            // 
            // Lbl_buscar
            // 
            this.Lbl_buscar.AutoSize = true;
            this.Lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_buscar.Location = new System.Drawing.Point(153, 124);
            this.Lbl_buscar.Name = "Lbl_buscar";
            this.Lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.Lbl_buscar.TabIndex = 17;
            this.Lbl_buscar.Text = "Buscar";
            // 
            // Lbl_registro
            // 
            this.Lbl_registro.AutoSize = true;
            this.Lbl_registro.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_registro.Location = new System.Drawing.Point(400, 124);
            this.Lbl_registro.Name = "Lbl_registro";
            this.Lbl_registro.Size = new System.Drawing.Size(67, 20);
            this.Lbl_registro.TabIndex = 18;
            this.Lbl_registro.Text = "Registro";
            // 
            // Lbl_titulo
            // 
            this.Lbl_titulo.AutoSize = true;
            this.Lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_titulo.Location = new System.Drawing.Point(251, 9);
            this.Lbl_titulo.Name = "Lbl_titulo";
            this.Lbl_titulo.Size = new System.Drawing.Size(351, 36);
            this.Lbl_titulo.TabIndex = 19;
            this.Lbl_titulo.Text = "Mantenimiento Usuarios";
            this.Lbl_titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // bnt_imagen
            // 
            this.bnt_imagen.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bnt_imagen.Location = new System.Drawing.Point(157, 243);
            this.bnt_imagen.Name = "bnt_imagen";
            this.bnt_imagen.Size = new System.Drawing.Size(82, 30);
            this.bnt_imagen.TabIndex = 20;
            this.bnt_imagen.Text = "Imagen";
            this.bnt_imagen.UseVisualStyleBackColor = true;
            // 
            // pic_imagen
            // 
            this.pic_imagen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pic_imagen.BackgroundImage")));
            this.pic_imagen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pic_imagen.Location = new System.Drawing.Point(71, 208);
            this.pic_imagen.Name = "pic_imagen";
            this.pic_imagen.Size = new System.Drawing.Size(65, 65);
            this.pic_imagen.TabIndex = 21;
            this.pic_imagen.TabStop = false;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(667, 118);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 20);
            this.label15.TabIndex = 103;
            this.label15.Text = "Aceptar";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(572, 118);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(78, 20);
            this.label16.TabIndex = 102;
            this.label16.Text = "Cancelar";
            // 
            // acpt_btn
            // 
            this.acpt_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("acpt_btn.BackgroundImage")));
            this.acpt_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.acpt_btn.Location = new System.Drawing.Point(671, 50);
            this.acpt_btn.Name = "acpt_btn";
            this.acpt_btn.Size = new System.Drawing.Size(65, 65);
            this.acpt_btn.TabIndex = 101;
            this.acpt_btn.UseVisualStyleBackColor = true;
            // 
            // cncl_btn
            // 
            this.cncl_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cncl_btn.BackgroundImage")));
            this.cncl_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cncl_btn.Location = new System.Drawing.Point(575, 48);
            this.cncl_btn.Name = "cncl_btn";
            this.cncl_btn.Size = new System.Drawing.Size(65, 65);
            this.cncl_btn.TabIndex = 100;
            this.cncl_btn.UseVisualStyleBackColor = true;
            // 
            // mant_usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(854, 449);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.acpt_btn);
            this.Controls.Add(this.cncl_btn);
            this.Controls.Add(this.pic_imagen);
            this.Controls.Add(this.bnt_imagen);
            this.Controls.Add(this.Lbl_titulo);
            this.Controls.Add(this.Lbl_registro);
            this.Controls.Add(this.Lbl_buscar);
            this.Controls.Add(this.Lbl_guardar);
            this.Controls.Add(this.Lbl_eliminar);
            this.Controls.Add(this.Lbl_modificar);
            this.Controls.Add(this.Btn_registro);
            this.Controls.Add(this.txt_tipousu);
            this.Controls.Add(this.txt_contraseña);
            this.Controls.Add(this.Lbl_tipousu);
            this.Controls.Add(this.Lbl_contraseña);
            this.Controls.Add(this.Lbl_usuario2);
            this.Controls.Add(this.Btn_eliminar);
            this.Controls.Add(this.Btn_modificar);
            this.Controls.Add(this.Btn_guardar);
            this.Controls.Add(this.dgv_usuarios);
            this.Controls.Add(this.Btn_buscar);
            this.Controls.Add(this.txt_usuario);
            this.Name = "mant_usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "mant_usuarios";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_usuarios)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_imagen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txt_usuario;
        private System.Windows.Forms.Button Btn_buscar;
        private System.Windows.Forms.DataGridView dgv_usuarios;
        private System.Windows.Forms.Button Btn_guardar;
        private System.Windows.Forms.Button Btn_modificar;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Label Lbl_usuario2;
        private System.Windows.Forms.Label Lbl_contraseña;
        private System.Windows.Forms.Label Lbl_tipousu;
        private System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.TextBox txt_tipousu;
        private System.Windows.Forms.Button Btn_registro;
        private System.Windows.Forms.Label Lbl_modificar;
        private System.Windows.Forms.Label Lbl_eliminar;
        private System.Windows.Forms.Label Lbl_guardar;
        private System.Windows.Forms.Label Lbl_buscar;
        private System.Windows.Forms.Label Lbl_registro;
        private System.Windows.Forms.Label Lbl_titulo;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.PictureBox pic_imagen;
        private System.Windows.Forms.Button bnt_imagen;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Button acpt_btn;
        private System.Windows.Forms.Button cncl_btn;
    }
}