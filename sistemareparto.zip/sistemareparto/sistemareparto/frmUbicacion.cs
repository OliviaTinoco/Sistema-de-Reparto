﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace sistemareparto
{
    public partial class frmUbicacion : Form
    {
        public frmUbicacion()
        {
            InitializeComponent();
        }

        void ayudar()
        {
            string ruta = @"C:\Users\ale_\Desktop\Repositorio.pdf";
            ProcessStartInfo startinfo = new ProcessStartInfo();
            startinfo.FileName = "AcroRd32.exe";
            startinfo.Arguments = ruta;
            Process.Start(startinfo);
        }

        private void dgv_ubicacionproducto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void mostradatos() //Muesta los datos de la tabla en el DataGrid
        {

            try
            {
                MySqlConnection conexion = clsBdComun.ObtenerConexion();
                MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM ubicacion", conexion);
                DataSet dsuario = new DataSet();
                dausuario.Fill(dsuario, "ubicacion");
                dgv_ubicacionproducto.DataSource = dsuario;
                dgv_ubicacionproducto.DataMember = "ubicacion";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        public clsUbicacion UbiAct { get; set; }  //Objeto publico, para traer datos de otro formulario.

        private void btn_buscar_Click(object sender, EventArgs e) //Botón para buscar un registro
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();

            if (buscubi.Ubiselec != null)
            {

                UbiAct = buscubi.Ubiselec;
                txt_estante.Text= buscubi.Ubiselec.sestante;
                txt_pasillo.Text = buscubi.Ubiselec.spasillo;
                txt_slot.Text = buscubi.Ubiselec.sslot;

                string scad = "select * from bodega";
                MySqlCommand mcd = new MySqlCommand(scad, clsBdComun.ObtenerConexion());
                MySqlDataReader mdr = mcd.ExecuteReader();
                while (mdr.Read())
                {
                    cbo_bod.Items.Add(mdr.GetString("ubic_bod"));
                }


            }
            mostradatos();



        }

        private void frmUbicacion_Load(object sender, EventArgs e)
        {
            mostradatos();
        }

        private void btn_nuevo_Click(object sender, EventArgs e) //Botón que genera una nueva operación
        {
            string scad = "select * from bodega";
            MySqlCommand mcd = new MySqlCommand(scad, clsBdComun.ObtenerConexion());
            MySqlDataReader mdr = mcd.ExecuteReader();
            while (mdr.Read())
            {
                cbo_bod.Items.Add(mdr.GetString("ubic_bod"));
            }

            mostradatos();
        }

        private void btn_guardar_Click(object sender, EventArgs e) //Boton para ingresar los datos a la base de datos
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cbo_bod.Text) || string.IsNullOrWhiteSpace(txt_estante.Text) ||
                           string.IsNullOrWhiteSpace(txt_pasillo.Text) || string.IsNullOrWhiteSpace(txt_slot.Text) ) 

                MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsUbicacion pUbicacion= new clsUbicacion();
                    pUbicacion.sestante = txt_estante.Text.Trim();
                    pUbicacion.spasillo = txt_pasillo.Text.Trim();
                    pUbicacion.sslot = txt_slot.Text.Trim();


                    MySqlCommand _comando = new MySqlCommand(String.Format(
                   "SELECT pk_codbod FROM bodega where ubic_bod ='{0}' ", cbo_bod.Text ), clsBdComun.ObtenerConexion());
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {
                       
                        pUbicacion.icodbod = _reader.GetInt16(0);
                    }

                        int iresultado = clsUbicacionOp.Agregar(pUbicacion);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ubicacion Guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la Ubicacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_modificar_Click(object sender, EventArgs e) //Botón que modifica un registro
        {
            try
            {
                if (string.IsNullOrWhiteSpace(cbo_bod.Text) || string.IsNullOrWhiteSpace(txt_estante.Text) ||
                           string.IsNullOrWhiteSpace(txt_pasillo.Text) || string.IsNullOrWhiteSpace(txt_slot.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {


                    clsUbicacion pUbicacion = new clsUbicacion();
                    // pUbicacion.icodbod = 1;


                    MySqlCommand _comando = new MySqlCommand(String.Format(
                   "SELECT pk_codbod FROM bodega where ubic_bod ='{0}' ", cbo_bod.Text), clsBdComun.ObtenerConexion());
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {

                        pUbicacion.icodbod = _reader.GetInt16(0);
                    }

                    pUbicacion.sestante = txt_estante.Text.Trim();
                    pUbicacion.spasillo = txt_pasillo.Text.Trim();
                    pUbicacion.sslot = txt_slot.Text.Trim();



                    int iresultado = clsUbicacionOp.Actualizar(pUbicacion);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ubicacion Actualizada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar la Ubicacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e) //Botón que elimina un registro
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar la ubicación Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (clsUbicacionOp.Eliminar(UbiAct.icod) > 0)
                {
                    MessageBox.Show("Usuario Eliminado Correctamente!", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Limpiar();
                    //Deshabilitar();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar el Usuario", "Cliente No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            mostradatos();
        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            mostradatos();
        }

        private void btn_cancelar_Click(object sender, EventArgs e) //Bótón para cancelar la operación
        {

            string ruta = @"C:\Users\Olivia\Desktop\manual_us.pdf";
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.FileName = "AcroRd32.exe";
            startInfo.Arguments = ruta;
            mostradatos();
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            ayudar();
        }
    }
}
