﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmUbicacion : Form
    {
        public frmUbicacion()
        {
            InitializeComponent();
        }

        private void dgv_ubicacionproducto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();
        }

        private void frmUbicacion_Load(object sender, EventArgs e)
        {

        }
    }
}
