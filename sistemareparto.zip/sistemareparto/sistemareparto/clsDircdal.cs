﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    class clsDircdal
    {
        public static int Agregar(clsDircliente pDircliente)
        {

            int retorno = 0;

            MySqlCommand comando = new MySqlCommand(string.Format("Insert into direccion_clte (pk_codclte, zona_dir_clte, calle_dir_clte, aven_dir_clte) values ('{0}','{1}','{2}','{3}')",
               pDircliente.idc, pDircliente.zona, pDircliente.calle, pDircliente.avenida), clsBdComun.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }
    }
}
