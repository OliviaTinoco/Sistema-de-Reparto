﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmBuscarUbicacion : Form
    {
        public frmBuscarUbicacion()
        {
            InitializeComponent();
        }

        private void frmBuscarUbicacion_Load(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e) //Boton que busca el registro e ingresa los datos al datagrid
        {
            try
            {
                dgv_ubic.DataSource = clsUbicacionOp.Buscar(txt_pasillo.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        public clsUbicacion Ubiselec { get; set; }

        private void btn_aceptar_Click(object sender, EventArgs e) //Boton que lleva los datos seleccionados a otro formulario
        {
            try
            {
                if (dgv_ubic.SelectedRows.Count == 1)
                {
                    int id = Convert.ToInt16(dgv_ubic.CurrentRow.Cells[0].Value);
                    //string id = dataGridView1.Row.Cells[0].Value;
                    //string id1 = dataGridView1.CurrentRow.Cells[0].Value.ToString;
                    Ubiselec = clsUbicacionOp.ObtenerUbicacion(id);

                    this.Close();
                }
                else
                    MessageBox.Show("debe de seleccionar una fila");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }
    }
}
