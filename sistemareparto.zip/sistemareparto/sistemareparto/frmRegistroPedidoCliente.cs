﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class Form_registro_pedido : Form
    {
        public Form_registro_pedido()
        {
            InitializeComponent();
        }

        public clsCliente clienteactual { get; set; }  //clase publica para obtener y mandar parametros de clsCliente

        public clsPedido pedidoactual { get; set; }     //clase publica para obtener y mandar parametros de clsPedido

        public clsProducto productoactual { get; set; }     //clase publica para obtener y mandar parametros de clsProducto

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

            Deshabilitar();
            //Llenando datagrid de lista productos
            MySqlConnection cn = clsBdComun.ObtenerConexion();          //Crea Conexion con la base de datos
            DataTable dt = new DataTable();                             //Crea objeto DataTable 
            String query = "Select nom_prod, mac_prod, desc_prod from PRODUCTO";    //Guarda consulta en un String
            MySqlCommand cmd = new MySqlCommand(query, cn);             //Ejecuta consulta
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);            //Carga los datos de la consulta

            da.Fill(dt);                                                //Llena el DataTable con los datos de la consulta
            dgv_producto.DataSource = dt;                               //Pasa esos datos al DataGrid

            //Llenando datgrid de lista pedidos
            MySqlConnection cn2 = clsBdComun.ObtenerConexion();         //Crea Conexion con la base de datos
            DataTable dt2 = new DataTable();                            //Crea objeto DataTable 
            String query2 = "Select pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod  from pedidoclte";        //Guarda consulta en un String
            MySqlCommand cmd2 = new MySqlCommand(query2, cn2);          //Ejecuta consulta
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);          //Carga los datos de la consulta
            da2.Fill(dt2);                                              //Llena el DataTable con los datos de la consulta
            dgv_pedidocliente.DataSource = dt2;                         //Pasa esos datos al DataGrid

            txt_fecha.Text = DateTime.Now.ToString("dd/MM/yyyy");       //Guarda fecha actual
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }

        private void Btn_registro_pedido_Click(object sender, EventArgs e)
        {
            Form_registro_pedido forma1 = new Form_registro_pedido();
            forma1.ShowDialog();
        }

        private void Btn_modificar_pedido_Click(object sender, EventArgs e)         //Boton modificar
        {

            if (string.IsNullOrWhiteSpace(txt_cliente.Text) || string.IsNullOrWhiteSpace(txt_fecha.Text) ||
                           string.IsNullOrWhiteSpace(txt_producto.Text) || string.IsNullOrWhiteSpace(txt_cant.Text))    //Condicion para que se llenen los campos obligatorios

                MessageBox.Show("Se deben llenar todos los campos obligatorios (*)!", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);     
            else
            {

                clsPedido pPedido = new clsPedido();        //Crear objeto pPedido para guardar datos de los campos

                /* ----------------------Llenando parametros en el objeto con los datos de los campos ----------------*/
                pPedido.pnom_clte = txt_cliente.Text.Trim();   
                pPedido.pnom_prod = txt_producto.Text.Trim();
                pPedido.cant_prod = txt_cant.Text.Trim();
                pPedido.pnom2_prod = txt_producto2.Text.Trim();         //Funcion Trim para eliminar espacios innecesarios en los datos
                pPedido.cant2_prod = txt_cantidad2.Text.Trim();
                pPedido.pnom3_prod = txt_producto3.Text.Trim();
                pPedido.cant3_prod = txt_cantidad3.Text.Trim();
                pPedido.id = pedidoactual.id;
                /* ---------------------------------------------------------------------------------------------------*/

                if (clsPedidodal.Actualizar(pPedido) > 0)           //Condicion de cuando existe un pedido a ser modificado
                {
                    MessageBox.Show("Los datos del pedido se actualizaron", "Datos Actualizados", MessageBoxButtons.OK, MessageBoxIcon.Information);    //Confirmar de operacion realizada
                    Limpiar();          //Funcion para limpiar los campos 
                    Deshabilitar();     //Funcion para deshabilitar los botones sin utilizar
                }
                else
                {
                    MessageBox.Show("No se pudo actualizar", "Error al Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);      //Mensaje de aviso de fallo

                }
            }
        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void Btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscar_pedido bus = new frmBuscar_pedido();      //Mandar a llamar el formulario Buscar pedido
            bus.ShowDialog();                                   //Mandar la pantalla

            if(bus.PedidoSeleccionado != null)                  //Condicion de cuando se realice mas de una busqueda
            {
                /* --------------------------------------Llenando campos de formulario con resultados --------------- */
                pedidoactual = bus.PedidoSeleccionado;
                txt_cliente.Text = bus.PedidoSeleccionado.pnom_clte;
                txt_fecha.Text = bus.PedidoSeleccionado.fec_pedi;
                txt_producto.Text = bus.PedidoSeleccionado.pnom_prod;
                txt_cant.Text = bus.PedidoSeleccionado.cant_prod;
                txt_producto2.Text = bus.PedidoSeleccionado.pnom2_prod;
                txt_cantidad2.Text = bus.PedidoSeleccionado.cant2_prod;
                txt_producto3.Text = bus.PedidoSeleccionado.pnom3_prod;
                txt_cantidad3.Text = bus.PedidoSeleccionado.cant3_prod;

                /* --------------------------------------------------------------------------------------------------- */

                btn_modificarpedido.Enabled = true;         //Habilitar el boton
                btn_eliminar.Enabled = true;                //Habilitar el boton
                Habilitar();                                //Funcion Habilitar
                btn_guardarpedido.Enabled = false;          //Deshabilitar boton guardar mientras se termina la operacion
                
            }

        }

        private void Btn_cancelar_pedido_Click(object sender, EventArgs e)  //Boton cancelar
        {
            Limpiar();              //Funcion limpiar
            Deshabilitar();         //Funcion Deshabilitar
        }

        private void Btn_cliente_Click(object sender, EventArgs e)   
        {
            frmBuscar_cliente cte = new frmBuscar_cliente();        //Se crea objeto de la clase Buscar Cliente
            cte.ShowDialog();                                       //Se manda la pantalla
            if(cte.ClienteSeleccionado!=null)                       //Condicion si se seleccion un cliente 
            {
                clienteactual = cte.ClienteSeleccionado;            //Se mandan los datos en Set y Get
                txt_cliente.Text = cte.ClienteSeleccionado.pnombre; //Se toma el nombre del cliente al campo del formulario
            }
        }

        private void Btn_buscar_producto_Click(object sender, EventArgs e)  //Boton Buscar Producto
        {
            frmBuscarProducto prod = new frmBuscarProducto();       //Se manda a llamar el formulario Buscar Producto
            prod.ShowDialog();                                      //Se manda la pantalla con el resultado
        }

        private void txt_cantidad_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {

        }

        private void dgv_producto_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void dgv_pedidocliente_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cbo_marcaproducto_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txt_fecha_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btn_guardarpedido_Click(object sender, EventArgs e)        //Boton guardar pedido
        {
            if (string.IsNullOrWhiteSpace(txt_cliente.Text) || string.IsNullOrWhiteSpace(txt_fecha.Text) ||
                            string.IsNullOrWhiteSpace(txt_producto.Text) || string.IsNullOrWhiteSpace(txt_cant.Text))   //Condicion de llenar campos obligatorios

                MessageBox.Show("Se deben llenar todos los campos obligatorios (*)!", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);     //Aviso de llenar todos los campos obligatorios
            else
            {

                /* ------------------------------------ Mandando datos de los campos a parametros -------------------*/
                clsPedido pPedido = new clsPedido();                      
                pPedido.pnom_clte = txt_cliente.Text.Trim();
                pPedido.fec_pedi = txt_fecha.Text.Trim();
                pPedido.pnom_prod = txt_producto.Text.Trim();
                pPedido.cant_prod = txt_cant.Text.Trim();           //Funcion Trim para eliminar espacios innecesarios
                pPedido.pnom2_prod = txt_producto2.Text.Trim();
                pPedido.cant2_prod = txt_cantidad2.Text.Trim();
                pPedido.pnom3_prod = txt_producto3.Text.Trim();
                pPedido.cant3_prod = txt_cantidad3.Text.Trim();

                /* --------------------------------------------------------------------------------------------------*/

                int resultado = clsPedidodal.Agregar(pPedido);      // Verificando operacion

                if (resultado > 0)
                {
                    MessageBox.Show("Pedido Guardado Correctamente!", "Guardar", MessageBoxButtons.OK, MessageBoxIcon.Information);     //Mensaje de operacion exitosa
                    Limpiar();      //Funcion limpiar
                    Deshabilitar();             //Funcion Deshabilitar
                }
                else //Si no se cumple
                {
                    MessageBox.Show("No se puedo guardar el pedido", "Fallo", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);    //Mensaje de fallo de operacion
                }

            }
        }

        private void label1_Click_3(object sender, EventArgs e)
        {

        }

        private void btn_producto_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();           //Mandamos a llamar a formulario Buscar Producto
            prod.ShowDialog();                                          //Pantalla
            if (prod.ProdSelec != null)                                 //Condicion para cuando se seleccione producto
            {
                productoactual = prod.ProdSelec;                        //Activacion de SET y GET
                txt_producto.Text = prod.ProdSelec.snom;                //Se guarda el nombre de producto en el campo
            }
        }

        private void txt_producto_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_producto2_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();          //Se manda a llamar el formulario Buscar Producto
            prod.ShowDialog();                                          //Se manda a llamar pantalla de formulario
            if (prod.ProdSelec != null)                                 //Condicion de seleccion de producto
            {
                productoactual = prod.ProdSelec;                    //Activacion de SET y GET
                txt_producto2.Text = prod.ProdSelec.snom;           //Se guarda el nombre de producto en el campo
            }
        }

        private void btn_producto3_Click(object sender, EventArgs e)
        {
            frmBuscarProducto prod = new frmBuscarProducto();       //Se manda a llamar el formulario Buscar Producto
            prod.ShowDialog();                                      //Se manda a llamar pantalla de formulario
            if (prod.ProdSelec != null)                             //Condicion de seleccion de producto
            {
                productoactual = prod.ProdSelec;                    //Activacion de SET y GET
                txt_producto3.Text = prod.ProdSelec.snom;           //Se guarda el nombre de producto en el campo
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)     //Boton Eliminar
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar el Pedido Actual", "Esta Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes) //Mensaje de verificacion
            {
                if (clsPedidodal.Eliminar(pedidoactual.id) > 0)         //Condicion de cuando se seleccione una fila
                {
                    MessageBox.Show("Pedido Eliminado Correctamente!", "Pedido Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);           //Confirmacion de operacion
                    Limpiar();                  //Funcion limpiar
                    Deshabilitar();             //Funcion deshabilitar
                }
                else //Si no cumple con la condicion
                {
                    MessageBox.Show("No se pudo eliminar el Pedido", "Pedido No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);  //Mensaje de operacion no confirmada
                }
            }
            else 
                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);    //Mensaje de eliminacion cancelada

        }

        private void cargarproductos()              //Funcion para cargar productos
        {
            MySqlConnection cn = clsBdComun.ObtenerConexion();          //Crear conexion con base de datos
            DataTable dt = new DataTable();                     //Crear objeto con atributos de DataTable
            String query = "Select nom_prod, mac_prod, desc_prod from PRODUCTO";        //String de consulta
            MySqlCommand cmd = new MySqlCommand(query, cn);         //Ejecutando consulta
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);        //Cargando datos de consulta

            da.Fill(dt);                                        //Llenando DataTable con los datos de consulta
            dgv_producto.DataSource = dt;                       //Llenando DataGrid con los datos del DataTable
        }

        private void cargarpedidos()            //Funcion para cargar productos
        {
            MySqlConnection cn2 = clsBdComun.ObtenerConexion();     //Crear conexion con base de datos
            DataTable dt2 = new DataTable();                        //Crear objeto con atributos de DataTable
            String query2 = "Select pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod  from pedidoclte";    //String de consulta
            MySqlCommand cmd2 = new MySqlCommand(query2, cn2);      //Ejecutando consulta
            MySqlDataAdapter da2 = new MySqlDataAdapter(cmd2);      //Cargando datos de consulta
            da2.Fill(dt2);                                          //Llenando DataTable con los datos de consulta
            dgv_pedidocliente.DataSource = dt2;                     //Llenando DataGrid con los datos del DataTable

            txt_fecha.Text = DateTime.Now.ToString("dd/MM/yyyy");  //Copiando fecha actual al campo
        }


        void Limpiar()              //Funcion Limpiar
        {
            /* ----------------------- Limpiando campos con Clear() -------------------- */
            txt_cliente.Clear();    
            txt_fecha.Clear();
            txt_producto.Clear();
            txt_cant.Clear();
            txt_producto2.Clear();
            txt_cantidad2.Clear();
            txt_producto3.Clear();
            txt_cantidad3.Clear();
            /* -------------------------------------------------------------------------- */

        }

        void Habilitar()                //Funcion Habilitar
        {
            /* -------------------------- Habilitando Campos ----------------------------- */
            txt_cliente.Enabled = true;
            txt_fecha.Enabled = true;
            txt_producto.Enabled = true;
            txt_cant.Enabled = true;
            txt_producto2.Enabled = true;
            txt_cantidad2.Enabled = true;
            txt_producto3.Enabled = true;
            txt_cantidad3.Enabled = true;
            /* -------------------------------------------------------------------------- */

            /* ------------------------- Habilitando Botones ---------------------------- */
            btn_nuevo.Enabled = true;
            btn_guardarpedido.Enabled = true;
            btn_eliminar.Enabled = true;
            btn_modificarpedido.Enabled = true;
            btn_cancelarpedido.Enabled = true;
            btn_buscar.Enabled = true;
            btn_cliente.Enabled = true;
            btn_producto.Enabled = true;
            btn_producto2.Enabled = true;
            btn_producto3.Enabled = true;
            /* --------------------------------------------------------------------------- */
        }

        void Deshabilitar()                 //Funcion DesHabilitar
        {
            /* ----------------------------------- Deshabilitando Campos ------------------ */
            txt_cliente.Enabled = false;
            txt_fecha.Enabled = false;
            txt_producto.Enabled = false;
            txt_cant.Enabled = false;
            txt_producto2.Enabled = false;
            txt_cantidad2.Enabled = false;
            txt_producto3.Enabled = false;
            txt_cantidad3.Enabled = false;
            /* ----------------------------------------------------------------------------- */

            btn_nuevo.Enabled = true;               //Se habilita siempre el boton NUEVO

            /* ----------------------------- Deshabilitando botones ------------------------ */

            btn_guardarpedido.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_modificarpedido.Enabled = false;
            btn_cancelarpedido.Enabled = false;
           /* btn_buscar.Enabled = false; */
            btn_cliente.Enabled = false;
            btn_producto.Enabled = false;
            btn_producto2.Enabled = false;
            btn_producto3.Enabled = false;

            /* ---------------------------------------------------------------------------- */

        }

        private void btn_nuevo_Click(object sender, EventArgs e)        //Boton NUEVO
        {   
            Limpiar();          //Funcion Limpiar
            Habilitar();        //Funcion Habilitar
            txt_fecha.Text = DateTime.Now.ToString("dd/MM/yyyy");   //Copiando fecha actual a campo fecha
        }

        private void button1_Click(object sender, EventArgs e)      //Boton REFRESCAR
        {
            cargarpedidos();        //Funcion cargarpedidos
            cargarproductos();      //Funcion cargarproductos
        }


        private void Ayuda_Click(object sender, EventArgs e)
        {
            //System.Windows.Forms.Help.ShowHelp(Control h, String f);
            Help.ShowHelp(this, "file://c:\\Users\\salaz\\Desktop\\modulo.chm");
        }
    }
}
