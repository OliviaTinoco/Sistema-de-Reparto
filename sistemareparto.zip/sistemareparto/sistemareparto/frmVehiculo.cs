﻿using System;
using System.Windows.Forms;
using sistemareparto.Modelo;

namespace sistemareparto
{
    public partial class frmVehiculo : Form
    {
        #region Procedimientos
        private void pro_habilitaInputs()
        {
            /*METODO PARA HABILITAR TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_placa.Enabled = true;
                txt_linea.Enabled = true;
                txt_chasis.Enabled = true;
                txt_marca.Enabled = true;
                txt_color.Enabled = true;
                cbo_Estado.Enabled = true;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }

        private void pro_deshabilitaInputs()
        {
            /*METODO PARA DESHABILITAR TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_placa.Enabled = false;
                txt_linea.Enabled = false;
                txt_chasis.Enabled = false;
                txt_marca.Enabled = false;
                txt_color.Enabled = false;
                cbo_Estado.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }

        private void pro_limpiaInputs()
        {
            /*METODO PARA LIMPIAR VALORES DE TODOS LOS CAMPOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            try
            {
                txt_placa.Text = string.Empty;
                txt_linea.Text = string.Empty;
                txt_chasis.Text = string.Empty;
                txt_marca.Text = string.Empty;
                txt_color.Text = string.Empty;
                cbo_Estado.SelectedItem = null;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.InnerException.ToString());
            }
        }

        private void pro_habilitaBotones()
        {
            btn_nuevo.Enabled = true;
            btn_buscar1.Enabled = true;
        }

        private void pro_loadVehiculos()
        {
            clsModeloVehiclo mclsModeloVehiclo = new clsModeloVehiclo();
            dgv_vehiculo.DataSource = mclsModeloVehiclo.fun_getAllVehiculos();
        }
        #endregion

        #region Funciones

        private bool fun_esEntero(String SNumero)
        {
            /*FUNCION PARA QUE VALIDA STRING PARA ASEGURAR QUE ES ENTERO
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            int INumero;
            return int.TryParse(SNumero, out INumero);
        }

        private bool fun_esDecimal(String SNumero)
        {
            /*FUNCION PARA QUE VALIDA STRING PARA ASEGURAR QUE ES DOUBLE
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            Double DNumero;
            return Double.TryParse(SNumero, out DNumero);
        }

        private bool fun_validaCampos()
        {
            /*FUNCION PARA VALIDAR LOS DATOS INGRESADOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            if (txt_placa.Text == String.Empty)
            {
                MessageBox.Show("Debe indicar una placa");
                return false;
            }
            if (txt_linea.Text == String.Empty)
            {
                MessageBox.Show("Debe ingresar una Linea");
                return false;
            }
            if (txt_chasis.Text == String.Empty)
            {
                MessageBox.Show("Debe indicar un chasis correcto");
                return false;
            }
            if (txt_marca.Text == String.Empty)
            {
                MessageBox.Show("Debe indicar una marca");
                return false;
            }
            if (txt_color.Text == String.Empty)
            {
                MessageBox.Show("Debe indicar un color");
                return false;
            }
            if (cbo_Estado.SelectedItem == null)
            {
                MessageBox.Show("Debe indicar un estado");
                return false;
            }

            return true;
        }
        #endregion

        #region Eventos

        public frmVehiculo()
        {
            InitializeComponent();
            pro_loadVehiculos();
        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            //DESHABILITA BOTONES INECESARIOS
            btn_nuevo.Enabled = false;
            btn_guardar.Enabled = true;
            btn_actualizar.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_cancelar.Enabled = true;
            btn_buscar1.Enabled = false;

            //HABILITA CAMPOS PARA INGRESO DE DATOS
            pro_habilitaInputs();
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            /*EVENTO DESENCADENADO EN CLICK DEL BOTON GUARDAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            //SE VALIDA QUE SE INGRESEN LOS CAMPOS CORRECTAMENTE
            if (fun_validaCampos())
            {
                //CREAMOS OBJETO VEHICULO CON DATOS INGRESADOS
                clsVehiculo mVehiculo = new clsVehiculo();
                mVehiculo.sPlaca = txt_placa.Text;
                mVehiculo.sLinea = txt_linea.Text;
                mVehiculo.sChasis = txt_chasis.Text;
                mVehiculo.sMarca = txt_marca.Text;
                mVehiculo.sColor = txt_color.Text;
                mVehiculo.sEstado = cbo_Estado.SelectedItem.ToString();

                //INSERTA VEHICULO
                clsModeloVehiclo mModeloVehiclo = new clsModeloVehiclo();
                //GUARDA EL VEHICULO EN BDD
                if (mModeloVehiclo.fun_guardarVehiculo(mVehiculo))
                {
                    MessageBox.Show("Vehículo guardado correctamente...");
                    usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Guardar", "Vehiculo");
                    //LIMPIA INFORMACIÓN DE CAMPOS
                    pro_limpiaInputs();
                    //DESHABILITA LOS CAMPOS
                    pro_deshabilitaInputs();
                    //HABILITA LOS BOTONES
                    pro_habilitaBotones();
                    //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                    pro_loadVehiculos();

                    //DESHABILITA BOTONES INECESARIOS
                    btn_guardar.Enabled = true;
                    btn_cancelar.Enabled = true;
                }
                else
                {
                    MessageBox.Show("Error al guardar Vehículo");
                }
            }
        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            /*EVENTO DESENCADENADO EN CLICK DEL BOTON ACTUALIZAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/
            //SE VALIDA QUE HAYA SELECIONADO UN VEHICULO
            if (txt_Id.Text != String.Empty && fun_esEntero(txt_Id.Text))
            {
                //SE VALIDA QUE SE INGRESEN LOS CAMPOS CORRECTAMENTE
                if (fun_validaCampos())
                {
                    //CREAMOS OBJETO VEHICULO CON DATOS INGRESADOS
                    clsVehiculo mVehiculo = new clsVehiculo();
                    mVehiculo.iId = Convert.ToInt32(txt_Id.Text);
                    mVehiculo.sPlaca = txt_placa.Text;
                    mVehiculo.sLinea = txt_linea.Text;
                    mVehiculo.sChasis = txt_chasis.Text;
                    mVehiculo.sMarca = txt_marca.Text;
                    mVehiculo.sColor = txt_color.Text;
                    mVehiculo.sEstado = cbo_Estado.SelectedItem.ToString();

                    //ACTUALIZA VEHICULO
                    clsModeloVehiclo mModeloVehiclo = new clsModeloVehiclo();
                    //ACTUALIZA EL VEHICULO EN BDD
                    if (mModeloVehiclo.fun_actualizarVehiculo(mVehiculo))
                    {
                        MessageBox.Show("Vehículo actualizado correctamente...");
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Actualizar", "Vehiculo");
                        //LIMPIA INFORMACIÓN DE CAMPOS
                        pro_limpiaInputs();
                        //DESHABILITA LOS CAMPOS
                        pro_deshabilitaInputs();
                        //HABILITA LOS BOTONES
                        pro_habilitaBotones();
                        //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                        pro_loadVehiculos();

                        //DESHABILITA BOTONES INECESARIOS
                        btn_actualizar.Enabled = false;
                        btn_eliminar.Enabled = false;
                        btn_cancelar.Enabled = false;
                    }
                    else
                    {
                        MessageBox.Show("Error al actualizar Vehículo");
                    }
                }
            }
            else
            {
                MessageBox.Show("Seleccione un vehiculo correcto");
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            /*EVENTO DESENCADENADO EN CLICK DEL BOTON ELIMINAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            //SE VALIDA QUE HAYA SELECIONADO UN VEHICULO
            if (txt_Id.Text != String.Empty && fun_esEntero(txt_Id.Text))
            {
                //ELIMINA VEHICULO
                clsModeloVehiclo mModeloVehiclo = new clsModeloVehiclo();
                //ELIMINAEL VEHICULO EN BDD
                if (mModeloVehiclo.fun_eliminarVehiculo(Convert.ToInt32(txt_Id.Text)))
                {
                    MessageBox.Show("Vehículo Eliminado correctamente...");
                    usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "Vehiculo");
                    //LIMPIA INFORMACIÓN DE CAMPOS
                    pro_limpiaInputs();
                    //DESHABILITA LOS CAMPOS
                    pro_deshabilitaInputs();
                    //HABILITA LOS BOTONES
                    pro_habilitaBotones();
                    //LLENA DATAGRIDVIEW CON EL NUEVO REGISTRO
                    pro_loadVehiculos();

                    //DESHABILITA BOTONES INECESARIOS
                    btn_actualizar.Enabled = false;
                    btn_eliminar.Enabled = false;
                    btn_cancelar.Enabled = false;
                }
                else
                {
                    MessageBox.Show("Error al eliminar Vehículo");
                }
            }
            else
            {
                MessageBox.Show("Seleccione un vehiculo correcto");
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            /*EVENTO DESENCADENADO EN CLICK DEL BOTON CANCELAR
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            //LIMPIA INFORMACIÓN DE CAMPOS
            pro_limpiaInputs();
            //DESHABILITA LOS CAMPOS
            pro_deshabilitaInputs();
            //HABILITA LOS BOTONES
            pro_habilitaBotones();

            //DESHABILITA BOTONES INECESARIOS
            btn_guardar.Enabled = false;
            btn_actualizar.Enabled = false;
            btn_eliminar.Enabled = false;
            btn_cancelar.Enabled = false;
        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            frmBuscarVehiculo busc = new frmBuscarVehiculo();
            busc.ShowDialog();

            if (busc.Vehiculo != null)
            {
                txt_Id.Text = busc.Vehiculo.iId.ToString();
                txt_placa.Text = busc.Vehiculo.sPlaca;
                txt_chasis.Text = busc.Vehiculo.sChasis;
                txt_color.Text = busc.Vehiculo.sColor;
                txt_linea.Text = busc.Vehiculo.sLinea;
                txt_marca.Text = busc.Vehiculo.sMarca;
                cbo_Estado.SelectedItem = busc.Vehiculo.sEstado;

                //HABILITAMOS CAMPOS DE INGRESO DE DATOS
                pro_habilitaInputs();
                //HABILITAR BOTONES NECESARIOS
                btn_nuevo.Enabled = false;
                btn_guardar.Enabled = false;
                btn_actualizar.Enabled = true;
                btn_eliminar.Enabled = true;
                btn_cancelar.Enabled = true;
                btn_buscar1.Enabled = false;
            }
        }

        private void dgv_vehiculo_SelectionChanged(object sender, EventArgs e)
        {
            if (dgv_vehiculo.SelectedRows.Count > 0)
            {
                DataGridViewRow dgvrFila = dgv_vehiculo.SelectedRows[0];

                txt_Id.Text = dgvrFila.Cells[0].Value.ToString();
                txt_placa.Text = dgvrFila.Cells[1].Value.ToString();
                txt_chasis.Text = dgvrFila.Cells[2].Value.ToString();
                txt_color.Text = dgvrFila.Cells[3].Value.ToString();
                txt_linea.Text = dgvrFila.Cells[4].Value.ToString();
                txt_marca.Text = dgvrFila.Cells[5].Value.ToString();
                cbo_Estado.SelectedItem = dgvrFila.Cells[6].Value.ToString();

                //HABILITAMOS CAMPOS DE INGRESO DE DATOS
                pro_habilitaInputs();
                //HABILITAR BOTONES NECESARIOS
                btn_nuevo.Enabled = false;
                btn_guardar.Enabled = false;
                btn_actualizar.Enabled = true;
                btn_eliminar.Enabled = true;
                btn_cancelar.Enabled = true;
                btn_buscar1.Enabled = false;
            }
        }


        #endregion

        private void frmVehiculo_Load(object sender, EventArgs e)
        {

        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            //ayudar();
        }
    }
}