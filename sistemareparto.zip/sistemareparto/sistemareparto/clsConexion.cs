﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto.Modelo
{
    public class clsConexion
    {
        public MySqlConnection fun_Conectar()
        {
            /*FUNCION PARA CONECTAR CON BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            string stringConexion = "datasource=localhost;username=root;DataBase=bdsistemadereparto3";  
            MySqlConnection Conn = new MySqlConnection(stringConexion);
            return Conn;
        }
    }
}
