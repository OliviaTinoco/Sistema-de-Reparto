﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class mant_usuarios : Form
    {
        public mant_usuarios()
        {
            InitializeComponent();
        }

        public usuario UsuarioActual { get; set; }
        public usuario UsuarioSeleccionado { get; set; }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Btn_buscar_Click(object sender, EventArgs e)
        {
            frmbuscar_usuario frm = new frmbuscar_usuario();
            frm.ShowDialog();
            if (frm.UsuarioSeleccionado != null)
            {
                UsuarioActual = frm.UsuarioSeleccionado;
                txt_usuario.Text = frm.UsuarioSeleccionado.username_user;
                txt_contraseña.Text = frm.UsuarioSeleccionado.password_user;
                comboBox1.Text = frm.UsuarioSeleccionado.tipo_user;
            }
        }

        private void Btn_guardar_Click(object sender, EventArgs e)
        {
            usuario usu = new usuario();
            usu.username_user = txt_usuario.Text.Trim();
            usu.password_user = txt_contraseña.Text.Trim();
            usu.tipo_user = comboBox1.Text.Trim();

            int resultado = usuariodal.Agregar(usu);
            if (resultado > 0)
            {
                MessageBox.Show("Usuario Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se pudo guardar el usuario", "Fallo!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            //usuariodal.obtenerBitacora(usuariodal.coduser, "Editar", sTabla);
            txt_usuario.Clear();
            txt_contraseña.Clear();
            comboBox1.ResetText();

            //txt_tipousuario.Clear();
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Insertar", "usuario");
        }

        private void Btn_registro_Click(object sender, EventArgs e)
        {
            txt_usuario.Enabled = true;
            txt_contraseña.Enabled = true;
            //txt_tipousuario.Enabled = true;
        }

        private void Btn_modificar_Click(object sender, EventArgs e)
        {

            usuario usu = new usuario();
            usu.username_user = txt_usuario.Text.Trim();
            usu.password_user = txt_contraseña.Text.Trim();            
            usu.tipo_user = comboBox1.Text.Trim();
            usu.pk_coduser = UsuarioActual.pk_coduser;                
            if (usuariodal.Actualizar(usu) >= 0)
            {
                MessageBox.Show("Los datos del usuario se actualizaron", "Datos Actualizados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se pudo actualizar", "Error al Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

            }
            //txt_tipousuario.Clear();
            txt_contraseña.Clear();
            txt_usuario.Clear();
            comboBox1.ResetText();
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Modificar", "usuario");
            /*try
            {
                if (string.IsNullOrWhiteSpace(txt_usuario.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }
                else
                {

                    usuario usu = new usuario();

                    usu.username_user = txt_usuario.Text.Trim();
                    usu.password_user = txt_contraseña.Text.Trim();
                    usu.tipo_user = comboBox1.Text.Trim();



                    int iresultado = usuariodal.Actualizar(usu);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Usuario actualizado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Modificar", "Usuario");
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar el usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }*/
                }


                //mostradatos();
            
            


        private void dgv_usuarios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            MySqlConnection cn = Bdcomun.ObtenerConexion();
            DataTable dt = new DataTable();
            String query = "Select pk_coduser, username_user, tipo_user from usuario";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            da.Fill(dt);
            dgv_usuarios.DataSource = dt;
        }

        private void Btn_aceptar_Click(object sender, EventArgs e)
        {
            MySqlConnection cn = Bdcomun.ObtenerConexion();
            DataTable dt = new DataTable();
            String query = "Select pk_coduser, username_user, tipo_user from usuario";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            da.Fill(dt);
            dgv_usuarios.DataSource = dt;
        }

        private void Btn_eliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar el Usuario Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {

                if (usuariodal.Eliminar(UsuarioActual.pk_coduser) > 0)

                {

                    MessageBox.Show("Usuario Eliminado Correctamente!", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

                else

                {

                    MessageBox.Show("No se pudo eliminar el Usuario", "Usuario No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);




                }
            }
            else

                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            txt_usuario.Clear();
            txt_contraseña.Clear();
            comboBox1.ResetText();
            //txt_tipousuario.Clear();
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "usuario");
        }

        private void txt_usuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void Btn_cancelar_Click(object sender, EventArgs e)
        {

            this.Close();
        }

        private void mant_usuarios_Load(object sender, EventArgs e)
        {

        }
    }
}        