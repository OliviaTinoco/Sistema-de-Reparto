﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class usuario
    {
        public int pk_coduser { get; set; }
        public string username_user { get; set; }
        public string password_user { get; set; }
        public string tipo_user { get; set; }

        public usuario() { }

        public usuario(int pk_coduser, string username_user, string password_user, string tipo_user)

        {
            this.pk_coduser = pk_coduser;
            this.username_user = username_user;
            this.password_user = password_user;
            this.tipo_user = tipo_user;
            
        }
        /*public usuario()
        {
            pk_coduser = 0;
            username_user = "";
            password_user = "";
            tipo_user = "";
        }*/
    }
}
