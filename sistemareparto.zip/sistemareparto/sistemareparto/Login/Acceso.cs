﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    class Acceso
    {
        //SqlConnection miconexion = new SqlConnection(Conexion.conexion);

        private string mensaje;
        private string username_user;
        private string password_user;
        private string tipo_user;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }
        public string Username_user
        {
            get { return username_user; }
            set { username_user = value; }
        }
        public string Password_user
        {
            get { return password_user; }
            set { password_user = value; }
        }

        public string Tipo_user
        {
            get { return tipo_user; }
            set { tipo_user = value; }
        }

        public bool Verificar()
        {
            bool resultado = false;
            MySqlCommand comando = new MySqlCommand("select * from usuario where username_user='" + username_user + "'and password_user='" + password_user + "'and tipo_user='" + tipo_user + "'", Bdcomun.ObtenerConexion());
            MySqlDataReader ejecuta = comando.ExecuteReader();
            if (ejecuta.Read())
            {
                resultado = true;
                mensaje = "Su Logueo Fue Ingresado Correctamente \n \n               Bienvenido al Sistema \n \n de Tarjetas de Banco";
            }
            else
            {
                mensaje = "         Excedio el Limite de Intentos al Sistema \n \nEspere unos Minutos y Ingrese Su Logueo Otra Vez";
            }
            return resultado;
        }
    }
}

