﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Net;
using System.Threading;
using System.Windows.Forms;

namespace sistemareparto
{
    public class usuariodal
    {
        public static string varibaleUsuario;
        public static MySqlCommand _comando;
        public static MySqlDataReader _reader;

        public static void timeCursor()
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                Thread.Sleep(5000);  // wait for a while
            }
            finally
            {
                Cursor.Current = Cursors.Default;
            }
        }
        public static int Agregar(usuario usu)  // procesode insertar un nuevo usuario al sistema
        {

            int retorno = 0;

            MySqlCommand comando = new MySqlCommand(string.Format("Insert into usuario (pk_coduser, username_user, password_user, tipo_user) values ('{0}','{1}','{2}', '{3}')",
                usu.pk_coduser, usu.username_user, usu.password_user, usu.tipo_user), Bdcomun.ObtenerConexion());
            retorno = comando.ExecuteNonQuery();
            return retorno;
        }

        public static void obtenerBitacora(String txtUsuario, String Accion, String table)
        {
            //int retorno = 0;
            string ip = ObtenerIP();
            string coduser = "";
            string username_user = "";
            MySqlCommand _comando = new MySqlCommand(String.Format("select pk_coduser,username_user  from usuario where username_user = '{0}'", txtUsuario), Bdcomun.ObtenerConexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            if (_reader.Read())
            {
                coduser = _reader.GetString(0);
                username_user = _reader.GetString(1);
            }
            _comando = new MySqlCommand(String.Format("INSERT INTO bitacora (accion, tabla, fecha, hora, ip, pk_coduser, username_user) VALUES('{0}','{1}',CURDATE(),DATE_FORMAT(CURTIME(), '%h:%i:%s'), '{2}','{3}','{4}')", Accion, table, ip, coduser, username_user), Bdcomun.ObtenerConexion());
            _reader = _comando.ExecuteReader();
            //return retorno;
        }

        public static string ObtenerIP()
        {
            IPHostEntry host;
            string localIP = "?";
            host = Dns.GetHostEntry(Dns.GetHostName());
            foreach (IPAddress ip in host.AddressList)
            {
                if (ip.AddressFamily.ToString() == "InterNetwork")
                {
                    localIP = ip.ToString();
                }
            }
            return localIP;
        }

        
        public static List<usuario> Buscar(string username_user)

        {

            List<usuario> _lista = new List<usuario>();
     
            MySqlCommand _comando = new MySqlCommand(String.Format(
           "SELECT pk_coduser, username_user, password_user, tipo_user FROM usuario  where username_user ='{0}'", username_user), Bdcomun.ObtenerConexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                usuario usu = new usuario();
                usu.pk_coduser = _reader.GetInt32(0);
                usu.username_user = _reader.GetString(1);
                usu.password_user = _reader.GetString(2);
                usu.tipo_user = _reader.GetString(3);
              
                _lista.Add(usu);

            }
            return _lista;
        }

        public static usuario ObtenerUsuario(int pk_coduser)

        {
            usuario usu = new usuario();
            MySqlConnection conexion = Bdcomun.ObtenerConexion();
            MySqlCommand _comando = new MySqlCommand(String.Format("SELECT pk_coduser, username_user, password_user, tipo_user FROM usuario where pk_coduser={0}", pk_coduser), conexion);
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                usu.pk_coduser = _reader.GetInt32(0);
                usu.username_user = _reader.GetString(1);
                usu.password_user = _reader.GetString(2);               
                usu.tipo_user = _reader.GetString(3);
            }

            conexion.Close();
            return usu;
        }

        public static int Actualizar(usuario usu)
        {
            int retorno = 0;
            MySqlConnection conexion = Bdcomun.ObtenerConexion();           
            MySqlCommand comando = new MySqlCommand(string.Format("Update usuario set username_user='{0}', password_user='{1}', tipo_user='{2}' where pk_coduser={3}",
            usu.username_user, usu.password_user, usu.tipo_user, usu.pk_coduser), conexion);
            retorno = comando.ExecuteNonQuery();
            conexion.Close();
            return retorno;        
        }
        public static int Eliminar(int usu)

        {

            int retorno = 0;
            MySqlConnection conexion = Bdcomun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format(" DELETE FROM usuario where pk_coduser = {0}", usu),conexion);     
            retorno = comando.ExecuteNonQuery();
            conexion.Close();
    
            return retorno;
        }


    }
}

