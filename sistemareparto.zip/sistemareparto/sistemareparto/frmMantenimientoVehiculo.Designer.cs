﻿namespace sistemareparto
{
    partial class frmMantenimientoVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMantenimientoVehiculo));
            this.Ltp2 = new System.Windows.Forms.DateTimePicker();
            this.Ltp1 = new System.Windows.Forms.DateTimePicker();
            this.cbo = new System.Windows.Forms.ComboBox();
            this.Lbl8 = new System.Windows.Forms.Label();
            this.Lbl7 = new System.Windows.Forms.Label();
            this.Lbl6 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.Lbl14 = new System.Windows.Forms.Label();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.Lbl13 = new System.Windows.Forms.Label();
            this.Lbl12 = new System.Windows.Forms.Label();
            this.Lbl11 = new System.Windows.Forms.Label();
            this.Lbl10 = new System.Windows.Forms.Label();
            this.Lbl9 = new System.Windows.Forms.Label();
            this.Lbl5 = new System.Windows.Forms.Label();
            this.Lbl4 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.acpt_btn = new System.Windows.Forms.Button();
            this.busc_btn = new System.Windows.Forms.Button();
            this.cncl_btn = new System.Windows.Forms.Button();
            this.new_btn = new System.Windows.Forms.Button();
            this.del_btn = new System.Windows.Forms.Button();
            this.mod_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // Ltp2
            // 
            this.Ltp2.Location = new System.Drawing.Point(253, 245);
            this.Ltp2.Name = "Ltp2";
            this.Ltp2.Size = new System.Drawing.Size(150, 20);
            this.Ltp2.TabIndex = 88;
            // 
            // Ltp1
            // 
            this.Ltp1.Location = new System.Drawing.Point(253, 210);
            this.Ltp1.Name = "Ltp1";
            this.Ltp1.Size = new System.Drawing.Size(150, 20);
            this.Ltp1.TabIndex = 87;
            // 
            // cbo
            // 
            this.cbo.FormattingEnabled = true;
            this.cbo.Location = new System.Drawing.Point(252, 171);
            this.cbo.Name = "cbo";
            this.cbo.Size = new System.Drawing.Size(150, 21);
            this.cbo.TabIndex = 86;
            // 
            // Lbl8
            // 
            this.Lbl8.AutoSize = true;
            this.Lbl8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl8.Location = new System.Drawing.Point(40, 171);
            this.Lbl8.Name = "Lbl8";
            this.Lbl8.Size = new System.Drawing.Size(77, 21);
            this.Lbl8.TabIndex = 85;
            this.Lbl8.Text = "Vehiculo";
            // 
            // Lbl7
            // 
            this.Lbl7.AutoSize = true;
            this.Lbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl7.Location = new System.Drawing.Point(475, 115);
            this.Lbl7.Name = "Lbl7";
            this.Lbl7.Size = new System.Drawing.Size(48, 15);
            this.Lbl7.TabIndex = 84;
            this.Lbl7.Text = "Aceptar";
            // 
            // Lbl6
            // 
            this.Lbl6.AutoSize = true;
            this.Lbl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl6.Location = new System.Drawing.Point(563, 115);
            this.Lbl6.Name = "Lbl6";
            this.Lbl6.Size = new System.Drawing.Size(56, 15);
            this.Lbl6.TabIndex = 82;
            this.Lbl6.Text = "Cancelar";
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(9, 295);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(800, 150);
            this.dgv.TabIndex = 80;
            // 
            // Lbl14
            // 
            this.Lbl14.AutoSize = true;
            this.Lbl14.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl14.Location = new System.Drawing.Point(243, 11);
            this.Lbl14.Name = "Lbl14";
            this.Lbl14.Size = new System.Drawing.Size(292, 24);
            this.Lbl14.TabIndex = 79;
            this.Lbl14.Text = "MANTENIMIENTO VEHICULO";
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(580, 246);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(150, 20);
            this.txt5.TabIndex = 78;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(580, 171);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(150, 20);
            this.txt3.TabIndex = 77;
            // 
            // txt4
            // 
            this.txt4.Location = new System.Drawing.Point(580, 210);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(150, 20);
            this.txt4.TabIndex = 76;
            // 
            // Lbl13
            // 
            this.Lbl13.AutoSize = true;
            this.Lbl13.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl13.Location = new System.Drawing.Point(427, 245);
            this.Lbl13.Name = "Lbl13";
            this.Lbl13.Size = new System.Drawing.Size(126, 21);
            this.Lbl13.TabIndex = 75;
            this.Lbl13.Text = "Observaciones";
            // 
            // Lbl12
            // 
            this.Lbl12.AutoSize = true;
            this.Lbl12.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl12.Location = new System.Drawing.Point(432, 207);
            this.Lbl12.Name = "Lbl12";
            this.Lbl12.Size = new System.Drawing.Size(121, 21);
            this.Lbl12.TabIndex = 74;
            this.Lbl12.Text = "Kilometro Final";
            // 
            // Lbl11
            // 
            this.Lbl11.AutoSize = true;
            this.Lbl11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl11.Location = new System.Drawing.Point(432, 168);
            this.Lbl11.Name = "Lbl11";
            this.Lbl11.Size = new System.Drawing.Size(142, 21);
            this.Lbl11.TabIndex = 73;
            this.Lbl11.Text = "Kilometro Record";
            // 
            // Lbl10
            // 
            this.Lbl10.AutoSize = true;
            this.Lbl10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl10.Location = new System.Drawing.Point(40, 244);
            this.Lbl10.Name = "Lbl10";
            this.Lbl10.Size = new System.Drawing.Size(207, 21);
            this.Lbl10.TabIndex = 72;
            this.Lbl10.Text = "Siguiente Mantenimiento";
            // 
            // Lbl9
            // 
            this.Lbl9.AutoSize = true;
            this.Lbl9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl9.Location = new System.Drawing.Point(40, 207);
            this.Lbl9.Name = "Lbl9";
            this.Lbl9.Size = new System.Drawing.Size(184, 21);
            this.Lbl9.TabIndex = 71;
            this.Lbl9.Text = "Ultimo Mantenimiento";
            // 
            // Lbl5
            // 
            this.Lbl5.AutoSize = true;
            this.Lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl5.Location = new System.Drawing.Point(659, 115);
            this.Lbl5.Name = "Lbl5";
            this.Lbl5.Size = new System.Drawing.Size(45, 15);
            this.Lbl5.TabIndex = 70;
            this.Lbl5.Text = "Buscar";
            // 
            // Lbl4
            // 
            this.Lbl4.AutoSize = true;
            this.Lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl4.Location = new System.Drawing.Point(398, 115);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(53, 15);
            this.Lbl4.TabIndex = 69;
            this.Lbl4.Text = "Eliminar";
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl2.Location = new System.Drawing.Point(218, 115);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(52, 15);
            this.Lbl2.TabIndex = 68;
            this.Lbl2.Text = "Guardar";
            // 
            // Lbl3
            // 
            this.Lbl3.AutoSize = true;
            this.Lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl3.Location = new System.Drawing.Point(300, 115);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(60, 15);
            this.Lbl3.TabIndex = 67;
            this.Lbl3.Text = "Actualizar";
            // 
            // acpt_btn
            // 
            this.acpt_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("acpt_btn.BackgroundImage")));
            this.acpt_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.acpt_btn.Location = new System.Drawing.Point(467, 47);
            this.acpt_btn.Name = "acpt_btn";
            this.acpt_btn.Size = new System.Drawing.Size(65, 65);
            this.acpt_btn.TabIndex = 95;
            this.acpt_btn.UseVisualStyleBackColor = true;
            // 
            // busc_btn
            // 
            this.busc_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("busc_btn.BackgroundImage")));
            this.busc_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.busc_btn.Location = new System.Drawing.Point(648, 47);
            this.busc_btn.Name = "busc_btn";
            this.busc_btn.Size = new System.Drawing.Size(65, 65);
            this.busc_btn.TabIndex = 94;
            this.busc_btn.UseVisualStyleBackColor = true;
            this.busc_btn.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // cncl_btn
            // 
            this.cncl_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cncl_btn.BackgroundImage")));
            this.cncl_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cncl_btn.Location = new System.Drawing.Point(554, 47);
            this.cncl_btn.Name = "cncl_btn";
            this.cncl_btn.Size = new System.Drawing.Size(65, 65);
            this.cncl_btn.TabIndex = 93;
            this.cncl_btn.UseVisualStyleBackColor = true;
            // 
            // new_btn
            // 
            this.new_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("new_btn.BackgroundImage")));
            this.new_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.new_btn.Location = new System.Drawing.Point(115, 47);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(65, 65);
            this.new_btn.TabIndex = 92;
            this.new_btn.UseVisualStyleBackColor = true;
            // 
            // del_btn
            // 
            this.del_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("del_btn.BackgroundImage")));
            this.del_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.del_btn.Location = new System.Drawing.Point(386, 47);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(65, 65);
            this.del_btn.TabIndex = 91;
            this.del_btn.UseVisualStyleBackColor = true;
            // 
            // mod_btn
            // 
            this.mod_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mod_btn.BackgroundImage")));
            this.mod_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mod_btn.Location = new System.Drawing.Point(295, 47);
            this.mod_btn.Name = "mod_btn";
            this.mod_btn.Size = new System.Drawing.Size(65, 65);
            this.mod_btn.TabIndex = 90;
            this.mod_btn.UseVisualStyleBackColor = true;
            // 
            // save_btn
            // 
            this.save_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("save_btn.BackgroundImage")));
            this.save_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.save_btn.Location = new System.Drawing.Point(205, 47);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(65, 65);
            this.save_btn.TabIndex = 89;
            this.save_btn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(128, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 96;
            this.label1.Text = "Nuevo";
            // 
            // frmMantenimientoVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(819, 456);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.acpt_btn);
            this.Controls.Add(this.busc_btn);
            this.Controls.Add(this.cncl_btn);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.mod_btn);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.Ltp2);
            this.Controls.Add(this.Ltp1);
            this.Controls.Add(this.cbo);
            this.Controls.Add(this.Lbl8);
            this.Controls.Add(this.Lbl7);
            this.Controls.Add(this.Lbl6);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.Lbl14);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.Lbl13);
            this.Controls.Add(this.Lbl12);
            this.Controls.Add(this.Lbl11);
            this.Controls.Add(this.Lbl10);
            this.Controls.Add(this.Lbl9);
            this.Controls.Add(this.Lbl5);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Lbl3);
            this.Name = "frmMantenimientoVehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMantenimientoVehiculo";
            this.Load += new System.EventHandler(this.frmMantenimientoVehiculo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker Ltp2;
        private System.Windows.Forms.DateTimePicker Ltp1;
        private System.Windows.Forms.ComboBox cbo;
        private System.Windows.Forms.Label Lbl8;
        private System.Windows.Forms.Label Lbl7;
        private System.Windows.Forms.Label Lbl6;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label Lbl14;
        private System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.Label Lbl13;
        private System.Windows.Forms.Label Lbl12;
        private System.Windows.Forms.Label Lbl11;
        private System.Windows.Forms.Label Lbl10;
        private System.Windows.Forms.Label Lbl9;
        private System.Windows.Forms.Label Lbl5;
        private System.Windows.Forms.Label Lbl4;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.Button acpt_btn;
        private System.Windows.Forms.Button busc_btn;
        private System.Windows.Forms.Button cncl_btn;
        private System.Windows.Forms.Button new_btn;
        private System.Windows.Forms.Button del_btn;
        private System.Windows.Forms.Button mod_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Label label1;
    }
}