﻿namespace sistemareparto
{
    partial class frmMantenimientoVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMantenimientoVehiculo));
            this.cbo_siguiente = new System.Windows.Forms.DateTimePicker();
            this.cbo_ultimo = new System.Windows.Forms.DateTimePicker();
            this.cbo_vehiculo = new System.Windows.Forms.ComboBox();
            this.lbl_vehiculo = new System.Windows.Forms.Label();
            this.lbl_aceptar = new System.Windows.Forms.Label();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.dgv_vehiculo = new System.Windows.Forms.DataGridView();
            this.lbl_mantenimiento = new System.Windows.Forms.Label();
            this.txt_observaciones = new System.Windows.Forms.TextBox();
            this.txt_record = new System.Windows.Forms.TextBox();
            this.txt_final = new System.Windows.Forms.TextBox();
            this.lbl_observaciones = new System.Windows.Forms.Label();
            this.lbl_final = new System.Windows.Forms.Label();
            this.lbl_record = new System.Windows.Forms.Label();
            this.lbl_siguiente = new System.Windows.Forms.Label();
            this.lbl_ultimo = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_actualizar = new System.Windows.Forms.Label();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_actualizar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_vehiculo)).BeginInit();
            this.SuspendLayout();
            // 
            // cbo_siguiente
            // 
            this.cbo_siguiente.Location = new System.Drawing.Point(253, 245);
            this.cbo_siguiente.Name = "cbo_siguiente";
            this.cbo_siguiente.Size = new System.Drawing.Size(150, 20);
            this.cbo_siguiente.TabIndex = 88;
            // 
            // cbo_ultimo
            // 
            this.cbo_ultimo.Location = new System.Drawing.Point(253, 210);
            this.cbo_ultimo.Name = "cbo_ultimo";
            this.cbo_ultimo.Size = new System.Drawing.Size(150, 20);
            this.cbo_ultimo.TabIndex = 87;
            // 
            // cbo_vehiculo
            // 
            this.cbo_vehiculo.FormattingEnabled = true;
            this.cbo_vehiculo.Location = new System.Drawing.Point(252, 171);
            this.cbo_vehiculo.Name = "cbo_vehiculo";
            this.cbo_vehiculo.Size = new System.Drawing.Size(150, 21);
            this.cbo_vehiculo.TabIndex = 86;
            // 
            // lbl_vehiculo
            // 
            this.lbl_vehiculo.AutoSize = true;
            this.lbl_vehiculo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_vehiculo.Location = new System.Drawing.Point(40, 171);
            this.lbl_vehiculo.Name = "lbl_vehiculo";
            this.lbl_vehiculo.Size = new System.Drawing.Size(77, 21);
            this.lbl_vehiculo.TabIndex = 85;
            this.lbl_vehiculo.Text = "Vehiculo";
            // 
            // lbl_aceptar
            // 
            this.lbl_aceptar.AutoSize = true;
            this.lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_aceptar.Location = new System.Drawing.Point(465, 115);
            this.lbl_aceptar.Name = "lbl_aceptar";
            this.lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.lbl_aceptar.TabIndex = 84;
            this.lbl_aceptar.Text = "Aceptar";
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_cancelar.Location = new System.Drawing.Point(550, 115);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 82;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // dgv_vehiculo
            // 
            this.dgv_vehiculo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_vehiculo.Location = new System.Drawing.Point(9, 295);
            this.dgv_vehiculo.Name = "dgv_vehiculo";
            this.dgv_vehiculo.Size = new System.Drawing.Size(800, 150);
            this.dgv_vehiculo.TabIndex = 80;
            // 
            // lbl_mantenimiento
            // 
            this.lbl_mantenimiento.AutoSize = true;
            this.lbl_mantenimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_mantenimiento.Location = new System.Drawing.Point(243, 11);
            this.lbl_mantenimiento.Name = "lbl_mantenimiento";
            this.lbl_mantenimiento.Size = new System.Drawing.Size(292, 24);
            this.lbl_mantenimiento.TabIndex = 79;
            this.lbl_mantenimiento.Text = "MANTENIMIENTO VEHICULO";
            // 
            // txt_observaciones
            // 
            this.txt_observaciones.Location = new System.Drawing.Point(580, 246);
            this.txt_observaciones.Name = "txt_observaciones";
            this.txt_observaciones.Size = new System.Drawing.Size(150, 20);
            this.txt_observaciones.TabIndex = 78;
            // 
            // txt_record
            // 
            this.txt_record.Location = new System.Drawing.Point(580, 171);
            this.txt_record.Name = "txt_record";
            this.txt_record.Size = new System.Drawing.Size(150, 20);
            this.txt_record.TabIndex = 77;
            // 
            // txt_final
            // 
            this.txt_final.Location = new System.Drawing.Point(580, 210);
            this.txt_final.Name = "txt_final";
            this.txt_final.Size = new System.Drawing.Size(150, 20);
            this.txt_final.TabIndex = 76;
            // 
            // lbl_observaciones
            // 
            this.lbl_observaciones.AutoSize = true;
            this.lbl_observaciones.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_observaciones.Location = new System.Drawing.Point(427, 245);
            this.lbl_observaciones.Name = "lbl_observaciones";
            this.lbl_observaciones.Size = new System.Drawing.Size(126, 21);
            this.lbl_observaciones.TabIndex = 75;
            this.lbl_observaciones.Text = "Observaciones";
            // 
            // lbl_final
            // 
            this.lbl_final.AutoSize = true;
            this.lbl_final.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_final.Location = new System.Drawing.Point(432, 207);
            this.lbl_final.Name = "lbl_final";
            this.lbl_final.Size = new System.Drawing.Size(121, 21);
            this.lbl_final.TabIndex = 74;
            this.lbl_final.Text = "Kilometro Final";
            // 
            // lbl_record
            // 
            this.lbl_record.AutoSize = true;
            this.lbl_record.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_record.Location = new System.Drawing.Point(432, 168);
            this.lbl_record.Name = "lbl_record";
            this.lbl_record.Size = new System.Drawing.Size(142, 21);
            this.lbl_record.TabIndex = 73;
            this.lbl_record.Text = "Kilometro Record";
            // 
            // lbl_siguiente
            // 
            this.lbl_siguiente.AutoSize = true;
            this.lbl_siguiente.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_siguiente.Location = new System.Drawing.Point(40, 244);
            this.lbl_siguiente.Name = "lbl_siguiente";
            this.lbl_siguiente.Size = new System.Drawing.Size(207, 21);
            this.lbl_siguiente.TabIndex = 72;
            this.lbl_siguiente.Text = "Siguiente Mantenimiento";
            // 
            // lbl_ultimo
            // 
            this.lbl_ultimo.AutoSize = true;
            this.lbl_ultimo.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ultimo.Location = new System.Drawing.Point(40, 207);
            this.lbl_ultimo.Name = "lbl_ultimo";
            this.lbl_ultimo.Size = new System.Drawing.Size(184, 21);
            this.lbl_ultimo.TabIndex = 71;
            this.lbl_ultimo.Text = "Ultimo Mantenimiento";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_buscar.Location = new System.Drawing.Point(655, 115);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 70;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_eliminar.Location = new System.Drawing.Point(388, 115);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 69;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_guardar.Location = new System.Drawing.Point(201, 115);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 68;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_actualizar
            // 
            this.lbl_actualizar.AutoSize = true;
            this.lbl_actualizar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_actualizar.Location = new System.Drawing.Point(291, 115);
            this.lbl_actualizar.Name = "lbl_actualizar";
            this.lbl_actualizar.Size = new System.Drawing.Size(81, 20);
            this.lbl_actualizar.TabIndex = 67;
            this.lbl_actualizar.Text = "Actualizar";
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_aceptar.BackgroundImage")));
            this.btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_aceptar.Location = new System.Drawing.Point(467, 47);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.btn_aceptar.TabIndex = 95;
            this.btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(648, 47);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 94;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelar.BackgroundImage")));
            this.btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelar.Location = new System.Drawing.Point(554, 47);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelar.TabIndex = 93;
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(115, 47);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 92;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Location = new System.Drawing.Point(386, 47);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 91;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_actualizar
            // 
            this.btn_actualizar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_actualizar.BackgroundImage")));
            this.btn_actualizar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_actualizar.Location = new System.Drawing.Point(295, 47);
            this.btn_actualizar.Name = "btn_actualizar";
            this.btn_actualizar.Size = new System.Drawing.Size(65, 65);
            this.btn_actualizar.TabIndex = 90;
            this.btn_actualizar.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(205, 47);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 89;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(121, 115);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 96;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // frmMantenimientoVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(819, 456);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_actualizar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.cbo_siguiente);
            this.Controls.Add(this.cbo_ultimo);
            this.Controls.Add(this.cbo_vehiculo);
            this.Controls.Add(this.lbl_vehiculo);
            this.Controls.Add(this.lbl_aceptar);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.dgv_vehiculo);
            this.Controls.Add(this.lbl_mantenimiento);
            this.Controls.Add(this.txt_observaciones);
            this.Controls.Add(this.txt_record);
            this.Controls.Add(this.txt_final);
            this.Controls.Add(this.lbl_observaciones);
            this.Controls.Add(this.lbl_final);
            this.Controls.Add(this.lbl_record);
            this.Controls.Add(this.lbl_siguiente);
            this.Controls.Add(this.lbl_ultimo);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_actualizar);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMantenimientoVehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmMantenimientoVehiculo";
            this.Load += new System.EventHandler(this.frmMantenimientoVehiculo_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_vehiculo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DateTimePicker cbo_siguiente;
        private System.Windows.Forms.DateTimePicker cbo_ultimo;
        private System.Windows.Forms.ComboBox cbo_vehiculo;
        private System.Windows.Forms.Label lbl_vehiculo;
        private System.Windows.Forms.Label lbl_aceptar;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.DataGridView dgv_vehiculo;
        private System.Windows.Forms.Label lbl_mantenimiento;
        private System.Windows.Forms.TextBox txt_observaciones;
        private System.Windows.Forms.TextBox txt_record;
        private System.Windows.Forms.TextBox txt_final;
        private System.Windows.Forms.Label lbl_observaciones;
        private System.Windows.Forms.Label lbl_final;
        private System.Windows.Forms.Label lbl_record;
        private System.Windows.Forms.Label lbl_siguiente;
        private System.Windows.Forms.Label lbl_ultimo;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_actualizar;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_actualizar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Label lbl_nuevo;
    }
}