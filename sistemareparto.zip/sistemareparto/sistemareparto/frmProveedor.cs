﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace sistemareparto
{
    public partial class frmProveedor : Form
    {
        public frmProveedor()
        {
            InitializeComponent();
        }

        void ayudar()
        {
            string ruta = @"C:\Users\ale_\Desktop\Repositorio.pdf";
            ProcessStartInfo startinfo = new ProcessStartInfo();
            startinfo.FileName = "AcroRd32.exe";
            startinfo.Arguments = ruta;
            Process.Start(startinfo);
        }

        public Proveedor ProveedorActual { get; set; }
        public usuario UsuarioSeleccionado { get; set; }

        private void Btn_buscar_Click(object sender, EventArgs e)
        {
            frmbuscar_proveedor frm = new frmbuscar_proveedor();
            frm.ShowDialog();

            if (frm.ProveedorSeleccionado != null)
            {
                ProveedorActual = frm.ProveedorSeleccionado;
                txt_nombre.Text = frm.ProveedorSeleccionado.nombre_prov;
                txt_direccion.Text = frm.ProveedorSeleccionado.direc_prov;
                //txt_telefono.Text = frm.ProveedorSeleccionado.
                txt_razon.Text = frm.ProveedorSeleccionado.razon_social_prov;
                txt_observaciones.Text = frm.ProveedorSeleccionado.observ_prov;
                txt_nit.Text = frm.ProveedorSeleccionado.nit_prov;


            }
        }

        private void Proveedor_Load(object sender, EventArgs e)
        {

        }

        private void btn_agregar_Click(object sender, EventArgs e)
        {


        }

        private void btn_actualizar_Click(object sender, EventArgs e)
        {
            Proveedor proveedor = new Proveedor();
            proveedor.nombre_prov = txt_nombre.Text.Trim();
            proveedor.direc_prov = txt_direccion.Text.Trim();
            proveedor.razon_social_prov = txt_razon.Text.Trim();
            proveedor.observ_prov = txt_observaciones.Text.Trim();
            proveedor.nit_prov = txt_nit.Text.Trim();
            proveedor.codprov = ProveedorActual.codprov;

            if (proveedordal.Actualizar(proveedor) > 0)
            {
                MessageBox.Show("Los datos del proveedor se actualizaron", "Datos Actualizados", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No se pudo actualizar", "Error al Actualizar", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);


            }
            txt_nombre.Clear();
            txt_direccion.Clear();
            txt_nit.Clear();
            txt_observaciones.Clear();
            txt_razon.Clear();
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Modificar", "proveedor");
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar el Proveedor Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)

            {

                if (proveedordal.Eliminar(ProveedorActual.codprov) > 0)

                {

                    MessageBox.Show("Proveedor Eliminado Correctamente!", "Cliente Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);

                }

                else

                {

                    MessageBox.Show("No se pudo eliminar el Proveedor", "Proveedor No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                }

            }

            else
            {

                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            txt_nombre.Clear();
            txt_direccion.Clear();
            txt_nit.Clear();
            txt_observaciones.Clear();
            txt_razon.Clear();
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "proveedor");
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            Proveedor proveedor = new Proveedor();
            proveedor.nombre_prov = txt_nombre.Text.Trim();
            proveedor.direc_prov = txt_direccion.Text.Trim();
            proveedor.observ_prov = txt_observaciones.Text.Trim();
            proveedor.razon_social_prov = txt_razon.Text.Trim();
            proveedor.nit_prov = txt_nit.Text.Trim();

            clsTelefonoProveedor telefono = new clsTelefonoProveedor();            //---------inserta telefono
            telefono.telefono = txt_telefono1.Text.Trim();
            //telefono.telefono2 = txt_telefono2.Text.Trim();

            clsTelefonoProveedor telefono2 = new clsTelefonoProveedor();            //---------inserta telefono
            telefono2.telefono = txt_telefono2.Text.Trim();


            int resultado = proveedordal.Agregar(proveedor);
            if (resultado > 0)
            {
                
                int resultado1 = telefonodal.AgregarTelefono(telefono);
                int resultado2 = telefonodal.AgregarTelefono(telefono2);
                if (resultado > 0 && resultado1 > 0 && resultado2 > 0)
                {

                    /*clsTelefonoProveedor telefono2 = new clsTelefonoProveedor();
                    telefono.telefono = txt_telefono2.Text.Trim();*/
                    MySqlConnection conectar = clsBdComun.ObtenerConexion();

                    MySqlCommand _comando = new MySqlCommand(String.Format("SELECT codprov FROM proveedor  where nombre_prov = '{0}' ", txt_nombre.Text), conectar);
                    MySqlDataReader _reader = _comando.ExecuteReader();
                    while (_reader.Read())
                    {
                        telefono.codprov = _reader.GetInt32(0);                                
                        telefono2.codprov = _reader.GetInt32(0);
                        telefonodal.AgregarTelefono(telefono);
                        //telefonodal.AgregarTelefono(telefono2);
                        //telefonodal.AgregarTelefono(telefono2);
                        ///pDircliente2.idc = _reader.GetInt16(0);

                    }
                    MessageBox.Show("Proveedor Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No se pudo guardar el Proveedor", "Fallo!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
                txt_nombre.Clear();
                txt_direccion.Clear();
                txt_nit.Clear();
                txt_observaciones.Clear();
                txt_razon.Clear();
                txt_telefono1.Clear();
                txt_telefono2.Clear();
                usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Insertar", "proveedor");
                MessageBox.Show("Bitacora almacenada");

            }

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            MySqlConnection cn = Bdcomun.ObtenerConexion();
            DataTable dt = new DataTable();
            String query = "Select * from proveedor_telefono3";
            MySqlCommand cmd = new MySqlCommand(query, cn);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);

            da.Fill(dt);
            dgv_proveedor.DataSource = dt;
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            ayudar();
        }
    }



}

