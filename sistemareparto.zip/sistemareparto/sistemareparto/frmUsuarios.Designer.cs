﻿namespace sistemareparto
{
    partial class mant_usuarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mant_usuarios));
            this.txt_usuario = new System.Windows.Forms.TextBox();
            this.Btn_buscar = new System.Windows.Forms.Button();
            this.dgv_usuarios = new System.Windows.Forms.DataGridView();
            this.Btn_guardar = new System.Windows.Forms.Button();
            this.Btn_modificar = new System.Windows.Forms.Button();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Lbl_usuario2 = new System.Windows.Forms.Label();
            this.Lbl_contraseña = new System.Windows.Forms.Label();
            this.Lbl_tipousu = new System.Windows.Forms.Label();
            this.txt_contraseña = new System.Windows.Forms.TextBox();
            this.Btn_registro = new System.Windows.Forms.Button();
            this.Lbl_modificar = new System.Windows.Forms.Label();
            this.Lbl_eliminar = new System.Windows.Forms.Label();
            this.Lbl_guardar = new System.Windows.Forms.Label();
            this.Lbl_buscar = new System.Windows.Forms.Label();
            this.Lbl_nuevo = new System.Windows.Forms.Label();
            this.Lbl_titulo = new System.Windows.Forms.Label();
            this.Lbl_aceptar = new System.Windows.Forms.Label();
            this.Lbl_cancelar = new System.Windows.Forms.Label();
            this.Btn_aceptar = new System.Windows.Forms.Button();
            this.Btn_cancelar = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_usuarios)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_usuario
            // 
            this.txt_usuario.AcceptsReturn = true;
            this.txt_usuario.AcceptsTab = true;
            this.txt_usuario.Location = new System.Drawing.Point(146, 167);
            this.txt_usuario.Name = "txt_usuario";
            this.txt_usuario.Size = new System.Drawing.Size(150, 20);
            this.txt_usuario.TabIndex = 0;
            this.txt_usuario.TextChanged += new System.EventHandler(this.txt_usuario_TextChanged);
            // 
            // Btn_buscar
            // 
            this.Btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar.BackgroundImage")));
            this.Btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar.Location = new System.Drawing.Point(146, 48);
            this.Btn_buscar.Name = "Btn_buscar";
            this.Btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscar.TabIndex = 5;
            this.Btn_buscar.UseVisualStyleBackColor = true;
            this.Btn_buscar.Click += new System.EventHandler(this.Btn_buscar_Click);
            // 
            // dgv_usuarios
            // 
            this.dgv_usuarios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_usuarios.Location = new System.Drawing.Point(30, 287);
            this.dgv_usuarios.Name = "dgv_usuarios";
            this.dgv_usuarios.Size = new System.Drawing.Size(800, 150);
            this.dgv_usuarios.TabIndex = 4;
            this.dgv_usuarios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_usuarios_CellContentClick);
            // 
            // Btn_guardar
            // 
            this.Btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_guardar.BackgroundImage")));
            this.Btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_guardar.Location = new System.Drawing.Point(487, 48);
            this.Btn_guardar.Name = "Btn_guardar";
            this.Btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.Btn_guardar.TabIndex = 4;
            this.Btn_guardar.UseVisualStyleBackColor = true;
            this.Btn_guardar.Click += new System.EventHandler(this.Btn_guardar_Click);
            // 
            // Btn_modificar
            // 
            this.Btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_modificar.BackgroundImage")));
            this.Btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_modificar.Location = new System.Drawing.Point(231, 48);
            this.Btn_modificar.Name = "Btn_modificar";
            this.Btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.Btn_modificar.TabIndex = 6;
            this.Btn_modificar.UseVisualStyleBackColor = true;
            this.Btn_modificar.Click += new System.EventHandler(this.Btn_modificar_Click);
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_eliminar.BackgroundImage")));
            this.Btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_eliminar.Location = new System.Drawing.Point(317, 48);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.Btn_eliminar.TabIndex = 7;
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            this.Btn_eliminar.Click += new System.EventHandler(this.Btn_eliminar_Click);
            // 
            // Lbl_usuario2
            // 
            this.Lbl_usuario2.AutoSize = true;
            this.Lbl_usuario2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_usuario2.Location = new System.Drawing.Point(67, 169);
            this.Lbl_usuario2.Name = "Lbl_usuario2";
            this.Lbl_usuario2.Size = new System.Drawing.Size(63, 20);
            this.Lbl_usuario2.TabIndex = 8;
            this.Lbl_usuario2.Text = "Usuario";
            // 
            // Lbl_contraseña
            // 
            this.Lbl_contraseña.AutoSize = true;
            this.Lbl_contraseña.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_contraseña.Location = new System.Drawing.Point(301, 169);
            this.Lbl_contraseña.Name = "Lbl_contraseña";
            this.Lbl_contraseña.Size = new System.Drawing.Size(95, 20);
            this.Lbl_contraseña.TabIndex = 9;
            this.Lbl_contraseña.Text = "Contraseña";
            // 
            // Lbl_tipousu
            // 
            this.Lbl_tipousu.AutoSize = true;
            this.Lbl_tipousu.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_tipousu.Location = new System.Drawing.Point(571, 167);
            this.Lbl_tipousu.Name = "Lbl_tipousu";
            this.Lbl_tipousu.Size = new System.Drawing.Size(99, 20);
            this.Lbl_tipousu.TabIndex = 10;
            this.Lbl_tipousu.Text = "Tipo_Usuario";
            // 
            // txt_contraseña
            // 
            this.txt_contraseña.Location = new System.Drawing.Point(402, 167);
            this.txt_contraseña.Name = "txt_contraseña";
            this.txt_contraseña.PasswordChar = '*';
            this.txt_contraseña.Size = new System.Drawing.Size(150, 20);
            this.txt_contraseña.TabIndex = 1;
            // 
            // Btn_registro
            // 
            this.Btn_registro.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_registro.BackgroundImage")));
            this.Btn_registro.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_registro.Location = new System.Drawing.Point(402, 48);
            this.Btn_registro.Name = "Btn_registro";
            this.Btn_registro.Size = new System.Drawing.Size(65, 65);
            this.Btn_registro.TabIndex = 3;
            this.Btn_registro.UseVisualStyleBackColor = true;
            this.Btn_registro.Click += new System.EventHandler(this.Btn_registro_Click);
            // 
            // Lbl_modificar
            // 
            this.Lbl_modificar.AutoSize = true;
            this.Lbl_modificar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_modificar.Location = new System.Drawing.Point(227, 124);
            this.Lbl_modificar.Name = "Lbl_modificar";
            this.Lbl_modificar.Size = new System.Drawing.Size(80, 20);
            this.Lbl_modificar.TabIndex = 14;
            this.Lbl_modificar.Text = "Modificar";
            // 
            // Lbl_eliminar
            // 
            this.Lbl_eliminar.AutoSize = true;
            this.Lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_eliminar.Location = new System.Drawing.Point(319, 124);
            this.Lbl_eliminar.Name = "Lbl_eliminar";
            this.Lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.Lbl_eliminar.TabIndex = 15;
            this.Lbl_eliminar.Text = "Eliminar";
            // 
            // Lbl_guardar
            // 
            this.Lbl_guardar.AutoSize = true;
            this.Lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_guardar.Location = new System.Drawing.Point(483, 124);
            this.Lbl_guardar.Name = "Lbl_guardar";
            this.Lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.Lbl_guardar.TabIndex = 16;
            this.Lbl_guardar.Text = "Guardar";
            // 
            // Lbl_buscar
            // 
            this.Lbl_buscar.AutoSize = true;
            this.Lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_buscar.Location = new System.Drawing.Point(153, 124);
            this.Lbl_buscar.Name = "Lbl_buscar";
            this.Lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.Lbl_buscar.TabIndex = 17;
            this.Lbl_buscar.Text = "Buscar";
            // 
            // Lbl_nuevo
            // 
            this.Lbl_nuevo.AutoSize = true;
            this.Lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nuevo.Location = new System.Drawing.Point(400, 124);
            this.Lbl_nuevo.Name = "Lbl_nuevo";
            this.Lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.Lbl_nuevo.TabIndex = 18;
            this.Lbl_nuevo.Text = "Nuevo";
            // 
            // Lbl_titulo
            // 
            this.Lbl_titulo.AutoSize = true;
            this.Lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_titulo.Location = new System.Drawing.Point(251, 9);
            this.Lbl_titulo.Name = "Lbl_titulo";
            this.Lbl_titulo.Size = new System.Drawing.Size(351, 36);
            this.Lbl_titulo.TabIndex = 19;
            this.Lbl_titulo.Text = "Mantenimiento Usuarios";
            this.Lbl_titulo.Click += new System.EventHandler(this.label1_Click);
            // 
            // Lbl_aceptar
            // 
            this.Lbl_aceptar.AutoSize = true;
            this.Lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_aceptar.Location = new System.Drawing.Point(667, 124);
            this.Lbl_aceptar.Name = "Lbl_aceptar";
            this.Lbl_aceptar.Size = new System.Drawing.Size(81, 20);
            this.Lbl_aceptar.TabIndex = 103;
            this.Lbl_aceptar.Text = "Actualizar";
            // 
            // Lbl_cancelar
            // 
            this.Lbl_cancelar.AutoSize = true;
            this.Lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cancelar.Location = new System.Drawing.Point(571, 124);
            this.Lbl_cancelar.Name = "Lbl_cancelar";
            this.Lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.Lbl_cancelar.TabIndex = 102;
            this.Lbl_cancelar.Text = "Cancelar";
            // 
            // Btn_aceptar
            // 
            this.Btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_aceptar.BackgroundImage")));
            this.Btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_aceptar.Location = new System.Drawing.Point(671, 50);
            this.Btn_aceptar.Name = "Btn_aceptar";
            this.Btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.Btn_aceptar.TabIndex = 8;
            this.Btn_aceptar.UseVisualStyleBackColor = true;
            this.Btn_aceptar.Click += new System.EventHandler(this.Btn_aceptar_Click);
            // 
            // Btn_cancelar
            // 
            this.Btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_cancelar.BackgroundImage")));
            this.Btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cancelar.Location = new System.Drawing.Point(575, 48);
            this.Btn_cancelar.Name = "Btn_cancelar";
            this.Btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.Btn_cancelar.TabIndex = 9;
            this.Btn_cancelar.UseVisualStyleBackColor = true;
            this.Btn_cancelar.Click += new System.EventHandler(this.Btn_cancelar_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "administrador",
            "usuario",
            "empleado bodega",
            "empleado carga",
            "empleado repartidor",
            "empleado piloto"});
            this.comboBox1.Location = new System.Drawing.Point(677, 167);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 2;
            // 
            // mant_usuarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(854, 449);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.Lbl_aceptar);
            this.Controls.Add(this.Lbl_cancelar);
            this.Controls.Add(this.Btn_aceptar);
            this.Controls.Add(this.Btn_cancelar);
            this.Controls.Add(this.Lbl_titulo);
            this.Controls.Add(this.Lbl_nuevo);
            this.Controls.Add(this.Lbl_buscar);
            this.Controls.Add(this.Lbl_guardar);
            this.Controls.Add(this.Lbl_eliminar);
            this.Controls.Add(this.Lbl_modificar);
            this.Controls.Add(this.Btn_registro);
            this.Controls.Add(this.txt_contraseña);
            this.Controls.Add(this.Lbl_tipousu);
            this.Controls.Add(this.Lbl_contraseña);
            this.Controls.Add(this.Lbl_usuario2);
            this.Controls.Add(this.Btn_eliminar);
            this.Controls.Add(this.Btn_modificar);
            this.Controls.Add(this.Btn_guardar);
            this.Controls.Add(this.dgv_usuarios);
            this.Controls.Add(this.Btn_buscar);
            this.Controls.Add(this.txt_usuario);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "mant_usuarios";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "mant_usuarios";
            this.Load += new System.EventHandler(this.mant_usuarios_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_usuarios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Btn_buscar;
        private System.Windows.Forms.DataGridView dgv_usuarios;
        private System.Windows.Forms.Button Btn_guardar;
        private System.Windows.Forms.Button Btn_modificar;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Label Lbl_usuario2;
        private System.Windows.Forms.Label Lbl_contraseña;
        private System.Windows.Forms.Label Lbl_tipousu;
        private System.Windows.Forms.Button Btn_registro;
        private System.Windows.Forms.Label Lbl_modificar;
        private System.Windows.Forms.Label Lbl_eliminar;
        private System.Windows.Forms.Label Lbl_guardar;
        private System.Windows.Forms.Label Lbl_buscar;
        private System.Windows.Forms.Label Lbl_nuevo;
        private System.Windows.Forms.Label Lbl_titulo;
        private System.Windows.Forms.Label Lbl_aceptar;
        private System.Windows.Forms.Label Lbl_cancelar;
        private System.Windows.Forms.Button Btn_aceptar;
        private System.Windows.Forms.Button Btn_cancelar;
        public System.Windows.Forms.TextBox txt_usuario;
        public System.Windows.Forms.TextBox txt_contraseña;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}