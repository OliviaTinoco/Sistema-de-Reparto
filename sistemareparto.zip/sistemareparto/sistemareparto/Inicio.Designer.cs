﻿namespace sistemareparto
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            this.label1 = new System.Windows.Forms.Label();
            this.pic_login = new System.Windows.Forms.PictureBox();
            this.pic_administrador = new System.Windows.Forms.PictureBox();
            this.pic_usuario = new System.Windows.Forms.PictureBox();
            this.Btn_administrador = new System.Windows.Forms.Button();
            this.Btn_usuario = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_administrador)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_usuario)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(260, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 36);
            this.label1.TabIndex = 0;
            this.label1.Text = "Login";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // pic_login
            // 
            this.pic_login.Image = ((System.Drawing.Image)(resources.GetObject("pic_login.Image")));
            this.pic_login.Location = new System.Drawing.Point(212, 73);
            this.pic_login.Name = "pic_login";
            this.pic_login.Size = new System.Drawing.Size(185, 187);
            this.pic_login.TabIndex = 1;
            this.pic_login.TabStop = false;
            // 
            // pic_administrador
            // 
            this.pic_administrador.Image = ((System.Drawing.Image)(resources.GetObject("pic_administrador.Image")));
            this.pic_administrador.Location = new System.Drawing.Point(89, 161);
            this.pic_administrador.Name = "pic_administrador";
            this.pic_administrador.Size = new System.Drawing.Size(65, 65);
            this.pic_administrador.TabIndex = 2;
            this.pic_administrador.TabStop = false;
            // 
            // pic_usuario
            // 
            this.pic_usuario.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pic_usuario.BackgroundImage")));
            this.pic_usuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pic_usuario.Location = new System.Drawing.Point(482, 161);
            this.pic_usuario.Name = "pic_usuario";
            this.pic_usuario.Size = new System.Drawing.Size(65, 65);
            this.pic_usuario.TabIndex = 3;
            this.pic_usuario.TabStop = false;
            // 
            // Btn_administrador
            // 
            this.Btn_administrador.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_administrador.Location = new System.Drawing.Point(65, 256);
            this.Btn_administrador.Name = "Btn_administrador";
            this.Btn_administrador.Size = new System.Drawing.Size(119, 32);
            this.Btn_administrador.TabIndex = 4;
            this.Btn_administrador.Text = "Administador";
            this.Btn_administrador.UseVisualStyleBackColor = true;
            this.Btn_administrador.Click += new System.EventHandler(this.Btn_administrador_Click);
            // 
            // Btn_usuario
            // 
            this.Btn_usuario.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_usuario.Location = new System.Drawing.Point(482, 256);
            this.Btn_usuario.Name = "Btn_usuario";
            this.Btn_usuario.Size = new System.Drawing.Size(75, 32);
            this.Btn_usuario.TabIndex = 5;
            this.Btn_usuario.Text = "Usuario";
            this.Btn_usuario.UseVisualStyleBackColor = true;
            this.Btn_usuario.Click += new System.EventHandler(this.Btn_usuario_Click);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(590, 382);
            this.Controls.Add(this.Btn_usuario);
            this.Controls.Add(this.Btn_administrador);
            this.Controls.Add(this.pic_usuario);
            this.Controls.Add(this.pic_administrador);
            this.Controls.Add(this.pic_login);
            this.Controls.Add(this.label1);
            this.Name = "Inicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Inicio";
            ((System.ComponentModel.ISupportInitialize)(this.pic_login)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_administrador)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_usuario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pic_login;
        private System.Windows.Forms.PictureBox pic_administrador;
        private System.Windows.Forms.PictureBox pic_usuario;
        private System.Windows.Forms.Button Btn_administrador;
        private System.Windows.Forms.Button Btn_usuario;
    }
}

