﻿using System;
using MySql.Data.MySqlClient;
using System.Data;
using System.Windows.Forms;

namespace sistemareparto.Modelo
{
    public class clsModeloVehiclo
    {
        public bool fun_guardarVehiculo(clsVehiculo pVehiculo)
        {
            /*FUNCION PARA INSERTAR EN BASE DE DATOS EL VEHICULO
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA INSERCIÓN
            try
            {
                //SE CREA SCRIPT DE INSERCIÓN
                string Query = "INSERT INTO vehiculo(placa_vehi,chasis_vehi,color_vehi,linea_vehi,marca_vehi, estado_vehi) VALUES('" + pVehiculo.sPlaca + "','" + pVehiculo.sChasis + "','" + pVehiculo.sColor + "','" + pVehiculo.sLinea + "','" + pVehiculo.sMarca + "','" + pVehiculo.sEstado + "');";

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool fun_actualizarVehiculo(clsVehiculo pVehiculo)
        {
            /*FUNCION PARA ACTUALIZAR DATOS DEL VEHICULO EN BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA INSERCIÓN
            try
            {
                //SE CREA SCRIPT DE INSERCIÓN
                string Query = "UPDATE vehiculo SET ";
                Query +="placa_vehi = '"+pVehiculo.sPlaca+"', ";
                Query += "chasis_vehi = '"+pVehiculo.sChasis+"', ";
                Query += "color_vehi = '"+pVehiculo.sColor+"', ";
                Query += "linea_vehi = '"+pVehiculo.sLinea+"', ";
                Query += "marca_vehi = '"+pVehiculo.sMarca+"', ";
                Query += "estado_vehi = '"+pVehiculo.sEstado+"' ";
                Query += "WHERE pk_codvehi = " + pVehiculo.iId.ToString();

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public bool fun_eliminarVehiculo(int pIdVehiculo)
        {
            /*FUNCION PARA ELIMINAR DATOS DEL VEHICULO EN BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }

            //INICIA INSERCIÓN
            try
            {
                //SE CREA SCRIPT DE ELIMINACION
                string Query = "UPDATE vehiculo SET ";
                Query += "estado_vehi = 'ELIMINADO' ";
                Query += "WHERE pk_codvehi = " + pIdVehiculo.ToString();

                MySqlCommand command = conn.CreateCommand();
                command.CommandText = Query;
                command.ExecuteNonQuery();
                return true;
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return false;
            }
            finally
            {
                conn.Close();
            }
        }

        public BindingSource fun_getAllVehiculos()
        {
            /*FUNCION PARA OBTENER LISTADO COMPLETO DE VEHICULOS DE BASE DE DATOS
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return null;
            }

            try
            {
                //SCRIPT PARA OBTENER TODOS LOS VEHICULOS DE LA BASE DE DATOS
                MySqlDataAdapter MyDA = new MySqlDataAdapter();
                string sqlSelectAll = "SELECT pk_codvehi, placa_vehi, chasis_vehi, color_vehi, linea_vehi, marca_vehi, estado_vehi FROM vehiculo WHERE estado_vehi != 'ELIMINADO'";
                MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, conn);

                DataTable table = new DataTable();
                MyDA.Fill(table);

                BindingSource bSource = new BindingSource();
                bSource.DataSource = table;

                return bSource;
            }
            catch (MySqlException ex)
            {
                return null;
            }
            finally
            {
                conn.Close();
            } 
        }

        public BindingSource fun_getAllVehiculosFiltrado(String pPlaca, String pChasis)
        {
            /*FUNCION PARA OBTENER LISTADO DE VEHICULOS QUE CUMPLAN CON LAS RESTRICCIONES DE BASE DE DATOS 
             * Autor: Merlyn Franco
             * Fecha: 06/08/2016*/

            MySqlConnection conn;

            try
            {
                //SE CREA CONEXION
                clsConexion mclsConexion = new clsConexion();
                conn = mclsConexion.fun_Conectar();
                conn.Open();
            }
            catch (MySqlException ex)
            {
                System.Diagnostics.Debug.Write(ex.InnerException.ToString());
                return null;
            }

            try
            {
                //SCRIPT PARA OBTENER TODOS LOS VEHICULOS DE LA BASE DE DATOS
                MySqlDataAdapter MyDA = new MySqlDataAdapter();
                string sqlSelectAll = "SELECT pk_codvehi AS Codigo, placa_vehi AS Placa, chasis_vehi AS Chasis, color_vehi AS Color, linea_vehi AS Linea, marca_vehi AS Marca, estado_vehi AS Estado FROM vehiculo WHERE estado_vehi != 'ELIMINADO' AND (placa_vehi = '" + pPlaca+"' OR '" + pPlaca+ "' = '') AND chasis_vehi LIKE '%"+pChasis+"%'";
                MyDA.SelectCommand = new MySqlCommand(sqlSelectAll, conn);

                DataTable table = new DataTable();
                MyDA.Fill(table);

                BindingSource bSource = new BindingSource();
                bSource.DataSource = table;

                return bSource;
            }
            catch (MySqlException ex)
            {
                return null;
            }
            finally
            {
                conn.Close();
            }
        }
    }
}
