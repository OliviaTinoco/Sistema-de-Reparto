﻿namespace sistemareparto
{
    partial class frmBuscarVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBuscarVehiculo));
            this.Lbl2 = new System.Windows.Forms.Label();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.Lbl1 = new System.Windows.Forms.Label();
            this.Lbl4 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.busc_btn = new System.Windows.Forms.Button();
            this.acpt_btn = new System.Windows.Forms.Button();
            this.cncl_btn = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.dgv_inventario = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inventario)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl2.Location = new System.Drawing.Point(108, 123);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(125, 21);
            this.Lbl2.TabIndex = 133;
            this.Lbl2.Text = "Placa Vehiculo";
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(239, 123);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(150, 20);
            this.txt2.TabIndex = 132;
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(239, 83);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(150, 20);
            this.txt1.TabIndex = 131;
            // 
            // Lbl1
            // 
            this.Lbl1.AutoSize = true;
            this.Lbl1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl1.Location = new System.Drawing.Point(143, 83);
            this.Lbl1.Name = "Lbl1";
            this.Lbl1.Size = new System.Drawing.Size(77, 21);
            this.Lbl1.TabIndex = 130;
            this.Lbl1.Text = "Vehiculo";
            // 
            // Lbl4
            // 
            this.Lbl4.AutoSize = true;
            this.Lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl4.Location = new System.Drawing.Point(447, 131);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(45, 15);
            this.Lbl4.TabIndex = 129;
            this.Lbl4.Text = "Buscar";
            // 
            // Lbl3
            // 
            this.Lbl3.AutoSize = true;
            this.Lbl3.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl3.Location = new System.Drawing.Point(209, 19);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(292, 36);
            this.Lbl3.TabIndex = 124;
            this.Lbl3.Text = "BUSCAR VEHICULOS";
            // 
            // busc_btn
            // 
            this.busc_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("busc_btn.BackgroundImage")));
            this.busc_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.busc_btn.Location = new System.Drawing.Point(436, 63);
            this.busc_btn.Name = "busc_btn";
            this.busc_btn.Size = new System.Drawing.Size(65, 65);
            this.busc_btn.TabIndex = 134;
            this.busc_btn.UseVisualStyleBackColor = true;
            // 
            // acpt_btn
            // 
            this.acpt_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("acpt_btn.BackgroundImage")));
            this.acpt_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.acpt_btn.Location = new System.Drawing.Point(261, 332);
            this.acpt_btn.Name = "acpt_btn";
            this.acpt_btn.Size = new System.Drawing.Size(65, 65);
            this.acpt_btn.TabIndex = 136;
            this.acpt_btn.UseVisualStyleBackColor = true;
            // 
            // cncl_btn
            // 
            this.cncl_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cncl_btn.BackgroundImage")));
            this.cncl_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cncl_btn.Location = new System.Drawing.Point(371, 332);
            this.cncl_btn.Name = "cncl_btn";
            this.cncl_btn.Size = new System.Drawing.Size(65, 65);
            this.cncl_btn.TabIndex = 135;
            this.cncl_btn.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(257, 400);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(70, 20);
            this.label13.TabIndex = 138;
            this.label13.Text = "Aceptar";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(367, 397);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(78, 20);
            this.label12.TabIndex = 137;
            this.label12.Text = "Cancelar";
            // 
            // dgv_inventario
            // 
            this.dgv_inventario.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_inventario.Location = new System.Drawing.Point(18, 158);
            this.dgv_inventario.Name = "dgv_inventario";
            this.dgv_inventario.Size = new System.Drawing.Size(710, 150);
            this.dgv_inventario.TabIndex = 139;
            // 
            // frmBuscarVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(759, 426);
            this.Controls.Add(this.dgv_inventario);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.acpt_btn);
            this.Controls.Add(this.cncl_btn);
            this.Controls.Add(this.busc_btn);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.Lbl1);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl3);
            this.Name = "frmBuscarVehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "frmBuscarVehiculo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_inventario)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label Lbl1;
        private System.Windows.Forms.Label Lbl4;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.Button busc_btn;
        private System.Windows.Forms.Button acpt_btn;
        private System.Windows.Forms.Button cncl_btn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.DataGridView dgv_inventario;
    }
}