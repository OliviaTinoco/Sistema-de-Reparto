﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistemareparto
{
    public class clsPedido
    {

        public int id { get; set; }
        public string pnom_clte { get; set; }
        public string fec_pedi { get; set; }
        public string pnom_prod { get; set; }
        public string cant_prod { get; set; }
        public string pnom2_prod { get; set; }
        public string cant2_prod { get; set; }
        public string pnom3_prod { get; set; }
        public string cant3_prod { get; set; }

        public clsPedido() { }

        public clsPedido(int pid, string nom_cte, string fecha, string nom_pr, string cantidad, string nom_pr2, string cant_pr2, string nom_pr3, string cant_pr3)

        {
            this.id = pid;
            this.pnom_clte = nom_cte;
            this.fec_pedi = fecha;
            this.pnom_prod = nom_pr;
            this.cant_prod = cantidad;
            this.pnom2_prod = nom_pr2;
            this.cant2_prod = cant_pr2;
            this.pnom3_prod = nom_pr3;
            this.cant3_prod = cant_pr3;
        }

    }
}
