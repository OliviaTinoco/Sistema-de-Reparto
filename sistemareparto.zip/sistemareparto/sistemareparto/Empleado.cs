﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class Empleado : Form
    {
        public Empleado()
        {
            InitializeComponent();
        }

        private void busc_btn_Click(object sender, EventArgs e)
        {
            Buscar_empleado fin = new Buscar_empleado();
            fin.ShowDialog();
        }

        private void mdir_btn_Click(object sender, EventArgs e)
        {
            DireccionEmp dir = new DireccionEmp();
            dir.ShowDialog();
        }

        private void mtel_btn_Click(object sender, EventArgs e)
        {
            TelefonoEmp tel = new TelefonoEmp();
            tel.ShowDialog();
        }

        private void mmail_btn_Click(object sender, EventArgs e)
        {
            CorreoEmp corre = new CorreoEmp();
            corre.ShowDialog();
        }

        private void puesto_btn_Click(object sender, EventArgs e)
        {
            PuestEmp pues = new PuestEmp();
            pues.ShowDialog();
        }

        private void busc_btndir_Click(object sender, EventArgs e)
        {
            PuestEmp pues = new PuestEmp();
            pues.ShowDialog();
        }

        private void Btn_btel_Click(object sender, EventArgs e)
        {
            CorreoEmp tel = new CorreoEmp();
            tel.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            TelefonoEmp tel = new TelefonoEmp();
            tel.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            DireccionEmp dir = new DireccionEmp();
            dir.ShowDialog();
        }
    }
}
