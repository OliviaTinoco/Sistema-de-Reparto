﻿namespace sistemareparto
{
    partial class frmPedidoProveedores
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPedidoProveedores));
            this.btn_agregarlista = new System.Windows.Forms.Button();
            this.lbl_pago = new System.Windows.Forms.Label();
            this.txt_tpago = new System.Windows.Forms.TextBox();
            this.ltp_fecha = new System.Windows.Forms.DateTimePicker();
            this.cbo_producto = new System.Windows.Forms.ComboBox();
            this.cbo_cantidad = new System.Windows.Forms.ComboBox();
            this.btn_agregar = new System.Windows.Forms.Button();
            this.cbo_proveedor = new System.Windows.Forms.ComboBox();
            this.dgv_listaProducto = new System.Windows.Forms.DataGridView();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_Modificar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.dgv_pedidos = new System.Windows.Forms.DataGridView();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_cantidad = new System.Windows.Forms.Label();
            this.lbl_producto = new System.Windows.Forms.Label();
            this.lbl_proveedor = new System.Windows.Forms.Label();
            this.lbl_PedidoProveedor = new System.Windows.Forms.Label();
            this.btn_aceptar = new System.Windows.Forms.Button();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.btn_cancelar = new System.Windows.Forms.Button();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.btn_modificar = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.lbl_aceptar = new System.Windows.Forms.Label();
            this.btn_buscarproducto = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_listaProducto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_agregarlista
            // 
            this.btn_agregarlista.Location = new System.Drawing.Point(534, 493);
            this.btn_agregarlista.Name = "btn_agregarlista";
            this.btn_agregarlista.Size = new System.Drawing.Size(157, 23);
            this.btn_agregarlista.TabIndex = 118;
            this.btn_agregarlista.Text = "Agregar Lista Productos";
            this.btn_agregarlista.UseVisualStyleBackColor = true;
            // 
            // lbl_pago
            // 
            this.lbl_pago.AutoSize = true;
            this.lbl_pago.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pago.Location = new System.Drawing.Point(75, 255);
            this.lbl_pago.Name = "lbl_pago";
            this.lbl_pago.Size = new System.Drawing.Size(114, 21);
            this.lbl_pago.TabIndex = 116;
            this.lbl_pago.Text = "Tipo de pago";
            // 
            // txt_tpago
            // 
            this.txt_tpago.Location = new System.Drawing.Point(199, 256);
            this.txt_tpago.Name = "txt_tpago";
            this.txt_tpago.Size = new System.Drawing.Size(150, 20);
            this.txt_tpago.TabIndex = 115;
            // 
            // ltp_fecha
            // 
            this.ltp_fecha.Location = new System.Drawing.Point(199, 302);
            this.ltp_fecha.Name = "ltp_fecha";
            this.ltp_fecha.Size = new System.Drawing.Size(150, 20);
            this.ltp_fecha.TabIndex = 114;
            // 
            // cbo_producto
            // 
            this.cbo_producto.FormattingEnabled = true;
            this.cbo_producto.Location = new System.Drawing.Point(534, 242);
            this.cbo_producto.Name = "cbo_producto";
            this.cbo_producto.Size = new System.Drawing.Size(150, 21);
            this.cbo_producto.TabIndex = 113;
            // 
            // cbo_cantidad
            // 
            this.cbo_cantidad.FormattingEnabled = true;
            this.cbo_cantidad.Location = new System.Drawing.Point(618, 195);
            this.cbo_cantidad.Name = "cbo_cantidad";
            this.cbo_cantidad.Size = new System.Drawing.Size(42, 21);
            this.cbo_cantidad.TabIndex = 112;
            // 
            // btn_agregar
            // 
            this.btn_agregar.Location = new System.Drawing.Point(558, 299);
            this.btn_agregar.Name = "btn_agregar";
            this.btn_agregar.Size = new System.Drawing.Size(102, 23);
            this.btn_agregar.TabIndex = 111;
            this.btn_agregar.Text = "Agregar Producto";
            this.btn_agregar.UseVisualStyleBackColor = true;
            // 
            // cbo_proveedor
            // 
            this.cbo_proveedor.FormattingEnabled = true;
            this.cbo_proveedor.Location = new System.Drawing.Point(199, 198);
            this.cbo_proveedor.Name = "cbo_proveedor";
            this.cbo_proveedor.Size = new System.Drawing.Size(150, 21);
            this.cbo_proveedor.TabIndex = 110;
            // 
            // dgv_listaProducto
            // 
            this.dgv_listaProducto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_listaProducto.Location = new System.Drawing.Point(469, 340);
            this.dgv_listaProducto.Name = "dgv_listaProducto";
            this.dgv_listaProducto.Size = new System.Drawing.Size(260, 136);
            this.dgv_listaProducto.TabIndex = 109;
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_cancelar.Location = new System.Drawing.Point(543, 155);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 108;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_buscar.Location = new System.Drawing.Point(637, 155);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.lbl_buscar.TabIndex = 107;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_eliminar.Location = new System.Drawing.Point(381, 154);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 106;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_Modificar
            // 
            this.lbl_Modificar.AutoSize = true;
            this.lbl_Modificar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_Modificar.Location = new System.Drawing.Point(287, 155);
            this.lbl_Modificar.Name = "lbl_Modificar";
            this.lbl_Modificar.Size = new System.Drawing.Size(80, 20);
            this.lbl_Modificar.TabIndex = 105;
            this.lbl_Modificar.Text = "Modificar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_guardar.Location = new System.Drawing.Point(195, 155);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 104;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(114, 155);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 103;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // dgv_pedidos
            // 
            this.dgv_pedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pedidos.Location = new System.Drawing.Point(87, 340);
            this.dgv_pedidos.Name = "dgv_pedidos";
            this.dgv_pedidos.Size = new System.Drawing.Size(280, 160);
            this.dgv_pedidos.TabIndex = 97;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(83, 301);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(59, 21);
            this.lbl_fecha.TabIndex = 96;
            this.lbl_fecha.Text = "Fecha";
            // 
            // lbl_cantidad
            // 
            this.lbl_cantidad.AutoSize = true;
            this.lbl_cantidad.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cantidad.Location = new System.Drawing.Point(440, 195);
            this.lbl_cantidad.Name = "lbl_cantidad";
            this.lbl_cantidad.Size = new System.Drawing.Size(87, 21);
            this.lbl_cantidad.TabIndex = 95;
            this.lbl_cantidad.Text = "Cantidad";
            // 
            // lbl_producto
            // 
            this.lbl_producto.AutoSize = true;
            this.lbl_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_producto.Location = new System.Drawing.Point(440, 242);
            this.lbl_producto.Name = "lbl_producto";
            this.lbl_producto.Size = new System.Drawing.Size(82, 21);
            this.lbl_producto.TabIndex = 94;
            this.lbl_producto.Text = "Producto";
            // 
            // lbl_proveedor
            // 
            this.lbl_proveedor.AutoSize = true;
            this.lbl_proveedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proveedor.Location = new System.Drawing.Point(83, 198);
            this.lbl_proveedor.Name = "lbl_proveedor";
            this.lbl_proveedor.Size = new System.Drawing.Size(90, 21);
            this.lbl_proveedor.TabIndex = 93;
            this.lbl_proveedor.Text = "Proveedor";
            // 
            // lbl_PedidoProveedor
            // 
            this.lbl_PedidoProveedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_PedidoProveedor.AutoSize = true;
            this.lbl_PedidoProveedor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_PedidoProveedor.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PedidoProveedor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_PedidoProveedor.Location = new System.Drawing.Point(258, 35);
            this.lbl_PedidoProveedor.Name = "lbl_PedidoProveedor";
            this.lbl_PedidoProveedor.Size = new System.Drawing.Size(280, 32);
            this.lbl_PedidoProveedor.TabIndex = 91;
            this.lbl_PedidoProveedor.Text = "PEDIDO PROVEEDOR";
            this.lbl_PedidoProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // btn_aceptar
            // 
            this.btn_aceptar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_aceptar.BackgroundImage")));
            this.btn_aceptar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_aceptar.Location = new System.Drawing.Point(460, 86);
            this.btn_aceptar.Name = "btn_aceptar";
            this.btn_aceptar.Size = new System.Drawing.Size(65, 65);
            this.btn_aceptar.TabIndex = 125;
            this.btn_aceptar.UseVisualStyleBackColor = true;
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Location = new System.Drawing.Point(641, 86);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 124;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // btn_cancelar
            // 
            this.btn_cancelar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelar.BackgroundImage")));
            this.btn_cancelar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelar.Location = new System.Drawing.Point(547, 86);
            this.btn_cancelar.Name = "btn_cancelar";
            this.btn_cancelar.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelar.TabIndex = 123;
            this.btn_cancelar.UseVisualStyleBackColor = true;
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(108, 86);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 122;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Location = new System.Drawing.Point(379, 86);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 121;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // btn_modificar
            // 
            this.btn_modificar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_modificar.BackgroundImage")));
            this.btn_modificar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_modificar.Location = new System.Drawing.Point(288, 86);
            this.btn_modificar.Name = "btn_modificar";
            this.btn_modificar.Size = new System.Drawing.Size(65, 65);
            this.btn_modificar.TabIndex = 120;
            this.btn_modificar.UseVisualStyleBackColor = true;
            // 
            // btn_guardar
            // 
            this.btn_guardar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardar.BackgroundImage")));
            this.btn_guardar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardar.Location = new System.Drawing.Point(198, 86);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(65, 65);
            this.btn_guardar.TabIndex = 119;
            this.btn_guardar.UseVisualStyleBackColor = true;
            // 
            // lbl_aceptar
            // 
            this.lbl_aceptar.AutoSize = true;
            this.lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F);
            this.lbl_aceptar.Location = new System.Drawing.Point(457, 154);
            this.lbl_aceptar.Name = "lbl_aceptar";
            this.lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.lbl_aceptar.TabIndex = 126;
            this.lbl_aceptar.Text = "Aceptar";
            // 
            // btn_buscarproducto
            // 
            this.btn_buscarproducto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscarproducto.BackgroundImage")));
            this.btn_buscarproducto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscarproducto.Location = new System.Drawing.Point(689, 234);
            this.btn_buscarproducto.Name = "btn_buscarproducto";
            this.btn_buscarproducto.Size = new System.Drawing.Size(40, 34);
            this.btn_buscarproducto.TabIndex = 127;
            this.btn_buscarproducto.UseVisualStyleBackColor = true;
            this.btn_buscarproducto.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmPedidoProveedores
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(804, 551);
            this.Controls.Add(this.btn_buscarproducto);
            this.Controls.Add(this.lbl_aceptar);
            this.Controls.Add(this.btn_aceptar);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.btn_cancelar);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.btn_modificar);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.btn_agregarlista);
            this.Controls.Add(this.lbl_pago);
            this.Controls.Add(this.txt_tpago);
            this.Controls.Add(this.ltp_fecha);
            this.Controls.Add(this.cbo_producto);
            this.Controls.Add(this.cbo_cantidad);
            this.Controls.Add(this.btn_agregar);
            this.Controls.Add(this.cbo_proveedor);
            this.Controls.Add(this.dgv_listaProducto);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_Modificar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.dgv_pedidos);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_cantidad);
            this.Controls.Add(this.lbl_producto);
            this.Controls.Add(this.lbl_proveedor);
            this.Controls.Add(this.lbl_PedidoProveedor);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmPedidoProveedores";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmPedidoProveedores";
            this.Load += new System.EventHandler(this.frmPedidoProveedores_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_listaProducto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_agregarlista;
        private System.Windows.Forms.Label lbl_pago;
        private System.Windows.Forms.TextBox txt_tpago;
        private System.Windows.Forms.DateTimePicker ltp_fecha;
        private System.Windows.Forms.ComboBox cbo_producto;
        private System.Windows.Forms.ComboBox cbo_cantidad;
        private System.Windows.Forms.Button btn_agregar;
        private System.Windows.Forms.ComboBox cbo_proveedor;
        private System.Windows.Forms.DataGridView dgv_listaProducto;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_Modificar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.DataGridView dgv_pedidos;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_cantidad;
        private System.Windows.Forms.Label lbl_producto;
        private System.Windows.Forms.Label lbl_proveedor;
        private System.Windows.Forms.Label lbl_PedidoProveedor;
        private System.Windows.Forms.Button btn_aceptar;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Button btn_cancelar;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Button btn_modificar;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Label lbl_aceptar;
        private System.Windows.Forms.Button btn_buscarproducto;
    }
}