﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmBuscarProducto : Form
    {
        public frmBuscarProducto()
        {
            InitializeComponent();
        }

        private void frmBuscarProducto_Load(object sender, EventArgs e)
        {
            //Llenando datagrid con la consulta a los datos de producto

            MySqlConnection cn = clsBdComun.ObtenerConexion();
            DataTable dt = new DataTable();                         //Objeto DataTable
            String query = "Select pk_codprod, nom_prod, mac_prod, desc_prod from producto"; //consulta Mysql en un String
            MySqlCommand cmd = new MySqlCommand(query, cn);                         //Ejecuta consulta
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);                //Trae los datos de la consulta

            da.Fill(dt);                                    //Se llena el datagrid de datos
            dgv_prod.DataSource = dt;

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            dgv_prod.DataSource = clsProductoOp.Buscar(txt_nombre.Text);   //Llenando datagrid con el resultado de la busqueda
        }


        public clsProducto ProdSelec { get; set; }                  //clase para obtener y guardar variables de la clase clsProducto
        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_prod.SelectedRows.Count == 1)       //condicion para cuando se seleccione una fila
            {
                int id = Convert.ToInt32(dgv_prod.CurrentRow.Cells[0].Value);   //Se toma el primer valor del datagrid
                ProdSelec = clsProductoOp.ObtenerProd(id);                      //Se manda como parametro id

                this.Close();
            }
            else
                MessageBox.Show("debe de seleccionar una fila");        //Si no hay fila seleccionada, se manda el mensaje

        }

        private void dgv_prod_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
