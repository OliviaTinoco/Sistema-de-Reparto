﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Diagnostics;

namespace sistemareparto
{
    public partial class FrmProducto : Form
    {
        public FrmProducto()
        {
            InitializeComponent();
        }

        void ayudar()
        {
            string ruta = @"C:\Users\ale_\Desktop\Repositorio.pdf";
            ProcessStartInfo startinfo = new ProcessStartInfo();
            startinfo.FileName = "AcroRd32.exe";
            startinfo.Arguments = ruta;
            Process.Start(startinfo);
        }


        private void mostradatos() //Para mostrar dado en el DataGried
        {

            MySqlConnection conexion = clsBdComun.ObtenerConexion();
            MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM producto", conexion);
            DataSet dsuario = new DataSet();
            dausuario.Fill(dsuario, "producto");
            dgv_producto.DataSource = dsuario;
            dgv_producto.DataMember = "producto";

        }
        public clsProducto ProdAct { get; set; }

        public ClsExistencia ExisAct1 { get; set; }
       public Proveedor procAct1 { get; set; }

        private void btn_buscar_Click(object sender, EventArgs e) //Boton qye abre formulario para abrir formulario
        {
            try
            {
                frmBuscarProducto buscprod = new frmBuscarProducto();
                buscprod.ShowDialog();

                if (buscprod.ProdSelec != null)
                {


                    ProdAct = buscprod.ProdSelec;
                     txt_desc.Text = buscprod.ProdSelec.sdesc;
                    //txt_exist.Text = Convert.ToString(buscprod.ProdSelec.icodexist);
                    txt_marc.Text = buscprod.ProdSelec.smarc;
                   // txt_proveedor.Text = Convert.ToString(buscprod.ProdSelec.icodprov);
                    txt_nom.Text = buscprod.ProdSelec.snom;

                    int cod =Convert.ToInt16( buscprod.ProdSelec.icodexist);
                    ExisAct1 = clsExistenciaOp.ObtenerExistencia(cod);

                    int codprov = Convert.ToInt16(buscprod.ProdSelec.icodprov);
                    procAct1 = proveedordal.ObtenerProveedor(codprov);
                    //MessageBox.Show(Convert.ToString(ExisAct1.icantidad));
                    txt_exist.Text = Convert.ToString(ExisAct1.icantidad);
                    txt_exist.Enabled = false;
                    txt_proveedor.Text = Convert.ToString(procAct1.nombre_prov);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }




        }

        private void btn_buscubicacion_Click(object sender, EventArgs e) 
        {
            frmBuscarUbicacion buscubi = new frmBuscarUbicacion();
            buscubi.ShowDialog();
        }

        private void FrmProducto_Load(object sender, EventArgs e)
        {
            mostradatos();
        }


        public ClsExistencia ExisAct { get; set; }
        public Proveedor ProveedorActual { get; set; }
        private void btn_buscprov_Click(object sender, EventArgs e) //Boton que abre formulario, para buscar el de proveedor
        {
       

            try
            {

                frmInventario businv = new frmInventario();
                businv.ShowDialog();

                if (businv.InvSelec != null)
                {

                    ExisAct = businv.InvSelec;
                    txt_exist.Text = Convert.ToString(ExisAct.icantidad);


                }
                //mostradatos();
                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }


        }

        private void btn_guardar_Click(object sender, EventArgs e) //Guarda el registro
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_marc.Text) || string.IsNullOrWhiteSpace(txt_nom.Text) ||
                           string.IsNullOrWhiteSpace(txt_proveedor.Text) || string.IsNullOrWhiteSpace(txt_exist.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                }
                else
                {


                    clsProducto pProd = new clsProducto();
                    pProd.icodexist = ExisAct.icod;
                    pProd.icodprov = Convert.ToInt16(ProveedorActual.codprov);
                    pProd.snom = txt_nom.Text.Trim();
                    pProd.smarc = txt_marc.Text.Trim();
                    pProd.sdesc = txt_desc.Text.Trim();



                    int iresultado = clsProductoOp.Agregar(pProd);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Producto Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                        txt_desc.Clear();
                        txt_exist.Clear();
                        txt_marc.Clear();
                        txt_nom.Clear();
                        txt_proveedor.Clear();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Insertar", "Producto");
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar el producto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                 mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_modificar_Click(object sender, EventArgs e) //Modifica el registro
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_marc.Text) || string.IsNullOrWhiteSpace(txt_nom.Text) ||
                           string.IsNullOrWhiteSpace(txt_proveedor.Text) || string.IsNullOrWhiteSpace(txt_exist.Text))
                {
                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    
                }
                else
                {


                    clsProducto pProd = new clsProducto();
                    pProd.icodexist = Convert.ToInt16(txt_exist.Text.Trim());
                    pProd.icodprov = Convert.ToInt16(txt_proveedor.Text.Trim());
                    pProd.snom = txt_nom.Text.Trim();
                    pProd.smarc = txt_marc.Text.Trim();
                    pProd.sdesc = txt_desc.Text.Trim();
                    pProd.icod = ProdAct.icod;



                    int iresultado = clsProductoOp.Actualizar(pProd);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Producto Actualizado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Modificar", "Producto");
                    }
                    else
                    {
                        MessageBox.Show("No se actualizar el prodcuto", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                 mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_eliminar_Click(object sender, EventArgs e) //Elimina el registroa actual
        {
            try
            {
                if (MessageBox.Show("Esta Seguro que desea eliminar el producto Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    if (clsProductoOp.Eliminar(ProdAct.icod) > 0 && clsExistenciaOp.Eliminar(ExisAct1.icod) > 0)
                    {
                        MessageBox.Show("Producto Eliminado Correctamente!", "Ruta Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                        mostradatos();
                        usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Eliminar", "Producto");

                    }
                    else
                    {
                        MessageBox.Show("No se pudo eliminar el producto", "Ruta No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }
                else
                    MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_cancelar_Click(object sender, EventArgs e) //Cancela todas las operaciones
        {
            try
            {
                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            try
            {
                mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_buscprov_Click_1(object sender, EventArgs e)
        {
            frmbuscar_proveedor frm = new frmbuscar_proveedor();
            frm.ShowDialog();

            if (frm.ProveedorSeleccionado != null)
            {
                ProveedorActual = frm.ProveedorSeleccionado;
                txt_proveedor.Text = frm.ProveedorSeleccionado.nombre_prov;
               


            }
        }

        private void btn_ayuda_Click(object sender, EventArgs e)
        {
            ayudar();
        }
    }
}
