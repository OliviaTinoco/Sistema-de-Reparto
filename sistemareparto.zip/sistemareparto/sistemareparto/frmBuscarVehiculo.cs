﻿using sistemareparto.Modelo;
using System;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmBuscarVehiculo : Form
    {
        
        public clsVehiculo Vehiculo;
        public clsVehiculo VehiculoActivo;

        #region Procedimientos

        private void pro_loadVehiculos()
        {
            clsModeloVehiclo mclsModeloVehiclo = new clsModeloVehiclo();
            dgv_vehiculo.DataSource = mclsModeloVehiclo.fun_getAllVehiculosFiltrado(txt_placa.Text, txt_chasis.Text);
        }

        #endregion

        #region Eventos
        public frmBuscarVehiculo()
        {
            InitializeComponent();

            
        }

        private void btn_buscar_Click(object sender, System.EventArgs e)
        {
            pro_loadVehiculos();
        }

        private void btn_cancelar_Click(object sender, System.EventArgs e)
        {
            this.Close();
        }


        #endregion

        private void btn_aceptar_Click(object sender, System.EventArgs e)
        {
            DataGridViewRow dgvrFila = dgv_vehiculo.SelectedRows[0];
            String estado = "Activo";
            if ((dgv_vehiculo.SelectedRows.Count == 1)&&(dgvrFila.Cells[6].Value.ToString() == estado) )
            {
                VehiculoActivo = new clsVehiculo();
                VehiculoActivo.iId = Convert.ToInt32(dgvrFila.Cells[0].Value.ToString());
                VehiculoActivo.sPlaca = dgvrFila.Cells[1].Value.ToString();
                VehiculoActivo.sChasis = dgvrFila.Cells[2].Value.ToString();
                VehiculoActivo.sColor = dgvrFila.Cells[3].Value.ToString();
                VehiculoActivo.sLinea = dgvrFila.Cells[4].Value.ToString();
                VehiculoActivo.sMarca = dgvrFila.Cells[5].Value.ToString();
                VehiculoActivo.sEstado= dgvrFila.Cells[6].Value.ToString();
                this.Close();
            }else
                if (dgv_vehiculo.SelectedRows.Count == 1)
                {
                Vehiculo = new clsVehiculo();
                Vehiculo.iId = Convert.ToInt32(dgvrFila.Cells[0].Value.ToString());
                Vehiculo.sPlaca = dgvrFila.Cells[1].Value.ToString();
                Vehiculo.sChasis = dgvrFila.Cells[2].Value.ToString();
                Vehiculo.sColor = dgvrFila.Cells[3].Value.ToString();
                Vehiculo.sLinea = dgvrFila.Cells[4].Value.ToString();
                Vehiculo.sMarca = dgvrFila.Cells[5].Value.ToString();
                Vehiculo.sEstado = dgvrFila.Cells[6].Value.ToString();

                this.Close();
            }
            else
            {
                MessageBox.Show("Debe seleccionar un vehiculo");
            }
        }

        private void lbl_aceptar_Click(object sender, EventArgs e)
        {

        }

        private void lbl_cancelar_Click(object sender, EventArgs e)
        {

        }

        private void dgv_vehiculo_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lbl_placa_Click(object sender, EventArgs e)
        {

        }

        private void txt_chasis_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_placa_TextChanged(object sender, EventArgs e)
        {

        }

        private void lbl_vehiculo_Click(object sender, EventArgs e)
        {

        }

        private void lbl_buscar_Click(object sender, EventArgs e)
        {

        }

        private void lbl_titulo_Click(object sender, EventArgs e)
        {

        }

        private void frmBuscarVehiculo_Load(object sender, EventArgs e)
        {

        }
    }
}
