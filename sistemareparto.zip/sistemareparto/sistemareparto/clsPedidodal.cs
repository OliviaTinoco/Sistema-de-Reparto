﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    class clsPedidodal
    {

        public static int Agregar(clsPedido pPedido)
        {

            int retorno = 0;

            MySqlConnection conectar = clsBdComun.ObtenerConexion();
            MySqlCommand comando = new MySqlCommand(string.Format("insert into pedidoclte (pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod) values ('{0}','{1}','{2}', '{3}', '{4}', '{5}', '{6}', '{7}')",
                pPedido.pnom_clte, pPedido.fec_pedi, pPedido.pnom_prod, pPedido.cant_prod, pPedido.pnom2_prod, pPedido.cant2_prod, pPedido.pnom3_prod, pPedido.cant3_prod), conectar);
            retorno = comando.ExecuteNonQuery();
            conectar.Close();
            return retorno;

      

    }

        public static List<clsPedido> Buscar(string cliente, string producto)
        {
            List<clsPedido> _lista = new List<clsPedido>();

            MySqlConnection conectar = clsBdComun.ObtenerConexion();
            MySqlCommand _comando = new MySqlCommand(String.Format(
           "select pk_pclte, pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod FROM pedidoclte where pnom_clte ='{0}' or pnom_prod='{1}'", cliente, producto), conectar);
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                clsPedido pPedido = new clsPedido();
                pPedido.id = _reader.GetInt32(0);
                pPedido.pnom_clte = _reader.GetString(1);
                pPedido.fec_pedi = _reader.GetString(2);
                pPedido.pnom_prod = _reader.GetString(3);
                pPedido.cant_prod = _reader.GetString(4);
                pPedido.pnom2_prod = _reader.GetString(5);
                pPedido.cant2_prod = _reader.GetString(6);
                pPedido.pnom3_prod = _reader.GetString(7);
                pPedido.cant3_prod = _reader.GetString(8);


                _lista.Add(pPedido);
            }
            conectar.Close();
            return _lista;
        }

        public static clsPedido ObtenerPedido(int pId)
        {
            clsPedido pPedido = new clsPedido();
            MySqlConnection conexion = clsBdComun.ObtenerConexion();

            MySqlCommand _comando = new MySqlCommand(String.Format("SELECT pk_pclte, pnom_clte, fec_pedi, pnom_prod, cant_prod, pnom2_prod, cant2_prod, pnom3_prod, cant3_prod FROM pedidoclte where pk_pclte={0}", pId), conexion);
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                pPedido.id = _reader.GetInt32(0);
                pPedido.pnom_clte = _reader.GetString(1);
                pPedido.fec_pedi = _reader.GetString(2);
                pPedido.pnom_prod = _reader.GetString(3);
                pPedido.cant_prod = _reader.GetString(4);
                pPedido.pnom2_prod = _reader.GetString(5);
                pPedido.cant2_prod = _reader.GetString(6);
                pPedido.pnom3_prod = _reader.GetString(7);
                pPedido.cant3_prod = _reader.GetString(8);

            }

            conexion.Close();
            return pPedido;

        }

        public static int Actualizar(clsPedido pPedido)
        {
            int retorno = 0;
            MySqlConnection conexion = clsBdComun.ObtenerConexion();

            MySqlCommand comando = new MySqlCommand(string.Format("Update pedidoclte set pnom_clte='{0}', pnom_prod='{1}', cant_prod='{2}', pnom2_prod='{3}', cant2_prod='{4}', pnom3_prod='{5}', cant3_prod='{6}'  where pk_pclte='{7}'",
                  pPedido.pnom_clte, pPedido.pnom_prod, pPedido.cant_prod, pPedido.pnom2_prod, pPedido.cant2_prod, pPedido.pnom3_prod, pPedido.cant3_prod, pPedido.id), conexion);

            retorno = comando.ExecuteNonQuery();
            conexion.Close();

            return retorno;


        }

        public static int Eliminar(int pId)
        {
            int retorno = 0;
            MySqlConnection conexion = clsBdComun.ObtenerConexion();

            MySqlCommand comando = new MySqlCommand(string.Format("delete from pedidoclte where pk_pclte ={0}", pId), conexion);

            retorno = comando.ExecuteNonQuery();
            conexion.Close();

            return retorno;

        }

    }
}
