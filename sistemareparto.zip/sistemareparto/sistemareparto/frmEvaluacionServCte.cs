﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmEvaluacionServCte : Form
    {
        public frmEvaluacionServCte()
        {
            InitializeComponent();
        }

        private void frmEvaluacionServCte_Load(object sender, EventArgs e)
        {
            mostradatos();
            txt_fec.Enabled = false;
            txt_nom.Enabled = false;
            txt_numpedi.Enabled = false;
            txt_obs.Enabled = false;
            cbo_calientre.Enabled = false;
            cbo_caliserv.Enabled = false;
            btn_guardar.Enabled = false;
        }
        private void mostradatos() //Para mostrar dado en el DataGried
        {

            try
            {
                MySqlConnection conexion = clsBdComun.ObtenerConexion();
                MySqlDataAdapter dausuario = new MySqlDataAdapter("SELECT * FROM evaluacion_servicio", conexion);
                DataSet dsuario = new DataSet();
                dausuario.Fill(dsuario, "evaluacion_servicio");
                dgv_serv.DataSource = dsuario;
                dgv_serv.DataMember = "evaluacion_servicio";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_nuevo_Click(object sender, EventArgs e)
        {
            btn_buscar.Enabled = true;
            //btn_aceptar.Enabled = true;
            txt_fec.Enabled = true;
            txt_nom.Enabled = true;
            txt_numpedi.Enabled = true;
            txt_obs.Enabled = true;
            cbo_calientre.Enabled = true;
            cbo_caliserv.Enabled = true;
            btn_guardar.Enabled = true;


            cbo_calientre.Items.Add("Muy Bueno");
            cbo_calientre.Items.Add("Bueno");
            cbo_calientre.Items.Add("Regular");
            cbo_calientre.Items.Add("Malo");
            cbo_calientre.Items.Add("Muy Malo");


            cbo_caliserv.Items.Add("Muy Bueno");
            cbo_caliserv.Items.Add("Bueno");
            cbo_caliserv.Items.Add("Regular");
            cbo_caliserv.Items.Add("Malo");
            cbo_caliserv.Items.Add("Muy Malo");

            mostradatos();


        }

        public clsPedido pedidoactual { get; set; }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            try
            {
                frmBuscar_pedido bus = new frmBuscar_pedido();      //Mandar a llamar el formulario Buscar pedido
                bus.ShowDialog();                                   //Mandar la pantalla

                if (bus.PedidoSeleccionado != null)                  //Condicion de cuando se realice mas de una busqueda
                {
                    /* --------------------------------------Llenando campos de formulario con resultados --------------- */
                    pedidoactual = bus.PedidoSeleccionado;
                    txt_nom.Text = bus.PedidoSeleccionado.pnom_clte;
                    txt_numpedi.Text = Convert.ToString(bus.PedidoSeleccionado.id);

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_numpedi.Text) || string.IsNullOrWhiteSpace(txt_nom.Text) ||
                           string.IsNullOrWhiteSpace(txt_fec.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                { 

                    ClsEvaluaServ sver = new ClsEvaluaServ();
                    sver.id =Convert.ToInt16( txt_numpedi.Text);
                    sver.pfecha = txt_fec.Text;
                    sver.sobsv = txt_obs.Text;
                    sver.scalientrega = cbo_calientre.Text;
                    sver.scaliserv = cbo_caliserv.Text;


                    int iresultado = ClsEvaluaServOp.Agregar(sver);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Evaluación guardada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        mostradatos();
                        txt_fec.Clear();
                        txt_nom.Clear();
                        txt_numpedi.Clear();
                        txt_obs.Clear();
                        btn_guardar.Enabled = false;
                        btn_nuevo.Enabled = true;
                        btn_buscar.Enabled = false;
                       
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar la evaluacion", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            mostradatos();
            txt_fec.Enabled = false;
            txt_nom.Enabled = false;
            txt_numpedi.Enabled = false;
            txt_obs.Enabled = false;
            cbo_calientre.Enabled = false;
            cbo_caliserv.Enabled = false;
            btn_guardar.Enabled = false;
        }
    }
}
