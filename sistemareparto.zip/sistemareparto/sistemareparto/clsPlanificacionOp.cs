﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    class clsPlanificacionOp
    {

        public static List<clsPlanificacion> Buscar(string pPlan) //Método tipo lista, que retornar el resultado dela busqueda
        {
            List<clsPlanificacion> _lista = new List<clsPlanificacion>();

            //MySqlCommand _comando = new MySqlCommand(String.Format(
            //"Select PLA.pk_codplan, P.pnom_clte, P.fec_pedi, PL.fec_planif, P.pnom_prod, P.cant_prod, VE.chasis_vehi, DIR.zona_dir_clte, DIR.calle_dir_clte, DIR.aven_dir_clte from pedidoclte P, plan PLA, planificacion_pedidos PL, vehiculo VE, asignacion_ruta AR, direccion_clte DIR, cliente CL where PLA.pk_codpedi = P.pk_pclte and PL.pk_codplanif = PLA.pk_codplanif and PL.fec_planif = '{0}' and VE.pk_codvehi = AR.pk_codvehi and AR.pk_codasigruta = PLA.pk_codasigruta and P.pnom_clte = CL.pnom_clte", pPlan), clsBdComun.ObtenerConexion());
            MySqlCommand _comando = new MySqlCommand(String.Format(
            "Select PLA.pk_codplan, P.pnom_clte, P.fec_pedi, PL.fec_planif, P.pnom_prod, P.cant_prod, VE.chasis_vehi, PLA.zona_plan, PLA.calle_plan, PLA.avenida_plan from pedidoclte P, plan PLA, planificacion_pedidos PL, vehiculo VE, asignacion_ruta AR, direccion_clte DIR, cliente CL where PLA.pk_pclte = P.pk_pclte and PL.pk_codplanif = PLA.pk_codplanif and PL.fec_planif = '{0}' and VE.pk_codvehi = AR.pk_codvehi and AR.pk_codasigruta = PLA.pk_codasigruta and P.pnom_clte = CL.pnom_clte", pPlan), clsBdComun.ObtenerConexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                clsPlanificacion pPlanificacion = new clsPlanificacion();

                pPlanificacion.id = _reader.GetInt32(0);
                pPlanificacion.cliente = _reader.GetString(1);
                pPlanificacion.fecha = _reader.GetString(2);
                pPlanificacion.fecha2 = _reader.GetString(3);
                pPlanificacion.producto = _reader.GetString(4);
                pPlanificacion.cantidad = _reader.GetString(5);
                pPlanificacion.vehiculo = _reader.GetString(6);
                pPlanificacion.zona = _reader.GetString(7);
                pPlanificacion.calle = _reader.GetString(8);
                pPlanificacion.avenida = _reader.GetString(9);


                _lista.Add(pPlanificacion);
            }

            return _lista;
        }

      
    }
}
