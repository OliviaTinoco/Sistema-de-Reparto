﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public partial class frmUsuario : Form
    {
        public frmUsuario()
        {
            InitializeComponent();
        }

        private void InitializeMyControl()
        {
            // Set to no text.
            txt_contraseña.Text = "";
            // The password character is an asterisk.
            txt_contraseña.PasswordChar = '*';
            // The control will allow no more than 14 characters.
            txt_contraseña.MaxLength = 14;
        }

        private void Btn_login_Click(object sender, EventArgs e)
        {

            /*MySqlConnection conexion = Bdcomun.ObtenerConexion();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM usuario WHERE username_user='" + txt_usuario.Text + "'AND password_user='" + txt_contraseña.Text + "' ", conexion); //Realizamos una selecion de la tabla usuarios.
            MySqlDataReader leer = cmd.ExecuteReader();
            if (leer.Read()) //Si el usuario es correcto nos abrira la otra ventana.
            {
                this.Hide();
                MessageBox.Show("Bienvenido"+"   "+Convert.ToString(txt_usuario.Text));
                string adm = "administrador";            
                MySqlCommand cdm = new MySqlCommand("SELECT *FROM usuario tipo_user", conexion);
                MySqlDataAdapter da = new MySqlDataAdapter(cdm);
                //if(da = "administrador")
                {

                }
                string tipo_user;
                //tipo_user =
                //if ((tipo_user = "administrador"))
                {

                }
                frmmdiMenuPrincipal fin = new frmmdiMenuPrincipal();
                fin.WindowState = FormWindowState.Normal;
                //fin.MdiParent = this;
                fin.Show();

            }
            else //Si no lo es mostrara este mensaje.
                MessageBox.Show("Error - Ingrese sus datos correctamente");
            conexion.Close(); //Cerramos la conexion.          
            /*mant_usuarios frm = new mant_usuarios();
            frm.Show();*/
            usuariodal.varibaleUsuario = txt_usuario.Text;
            usuariodal.obtenerBitacora(usuariodal.varibaleUsuario, "Inicio Secion", "Usuario");
            if (this.comboBox1.Text == "SELECCIONAR")
            {
                MessageBox.Show("Seleccione Tipo de Usuario", "Mensaje de Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Acceso ace = new Acceso();
            ace.Username_user = txt_usuario.Text;
            ace.Password_user = (txt_contraseña.Text);
            ace.Tipo_user = comboBox1.Text;

            if (txt_usuario.Text == "")
            {
                MessageBox.Show("Digite Usuario para Continuar", "Sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txt_usuario.Focus();
            }
            else if (txt_contraseña.Text == "")
            {
                MessageBox.Show("Digite Clave para Continuar", "Sistema", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                txt_contraseña.Focus();
            }
            else if (ace.Verificar() == true)
            {
                if (comboBox1.Text == "administrador")
                {
                    frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                    menu_principal.Show();
                    this.Hide();
                    menu_principal.usuarioToolStripMenuItem2.Enabled = true;
                    menu_principal.archivoToolStripMenuItem.Enabled = true;
                    //menu_principal.mantenimientosToolStripMenuItem.Enabled = true;
                    menu_principal.clienteToolStripMenuItem.Enabled = true;
                    menu_principal.proveedoresToolStripMenuItem.Enabled = true;
                    menu_principal.empleadoToolStripMenuItem.Enabled = true;
                    menu_principal.productoToolStripMenuItem.Enabled = true;
                    menu_principal.vehiculoToolStripMenuItem1.Enabled = true;
                    menu_principal.ubicacionToolStripMenuItem.Enabled = true;
                    menu_principal.rutaToolStripMenuItem.Enabled = true;
                    menu_principal.pedidoClienteToolStripMenuItem1.Enabled = true;
                    menu_principal.proveedorToolStripMenuItem2.Enabled = true;
                    menu_principal.inventarioToolStripMenuItem2.Enabled = true;
                    menu_principal.vehiculoToolStripMenuItem.Enabled = true;
                    menu_principal.pilotosToolStripMenuItem.Enabled = true;
                    menu_principal.repartidoresToolStripMenuItem.Enabled = true;
                    menu_principal.ordenesToolStripMenuItem.Enabled = true;
                    //inicia.toolStripStatusLabel2.Text = "Usuario: " + textBox1.Text + "  *** " + " Cargo: " + comboBox1.Text.ToString();
                    //inicia.cONDIFENCIALToolStripMenuItem.Enabled = false;
                    //inicia.aGREGARUSUARIOSToolStripMenuItem.Enabled = false;
                }
                else
                {
                    if (comboBox1.Text == "usuario")
                    {
                        frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                        menu_principal.Show();
                        this.Hide();
                        //menu_principal.archivoToolStripMenuItem.Enabled = true;
                        //menu_principal.mantenimientosToolStripMenuItem.Enabled = true;
                        //menu_principal.pedidoClienteToolStripMenuItem1.Enabled = true;
                        //menu_principal.proveedorToolStripMenuItem2.Enabled = true;
                        //menu_principal.inventarioToolStripMenuItem2.Enabled = true;
                        //menu_principal.vehiculoToolStripMenuItem.Enabled = true;
                        menu_principal.vehiculoToolStripMenuItem1.Enabled = true;
                        menu_principal.proveedoresToolStripMenuItem.Enabled = true;
                        menu_principal.proveedorToolStripMenuItem2.Enabled = true;
                        menu_principal.productoToolStripMenuItem.Enabled = true;
                        menu_principal.pilotosToolStripMenuItem.Enabled = true;
                        menu_principal.repartidoresToolStripMenuItem.Enabled = true;
                        menu_principal.ordenesToolStripMenuItem.Enabled = true;
                        menu_principal.pedidoClienteToolStripMenuItem1.Enabled = true;
                        menu_principal.rutaToolStripMenuItem.Enabled = true;
                        menu_principal.vehiculoToolStripMenuItem.Enabled = true;
                        menu_principal.clienteToolStripMenuItem.Enabled = true;

                    }
                    else
                    {
                        if (comboBox1.Text == "empleado bodega")
                        {
                            frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                            menu_principal.Show();
                            this.Hide();
                            menu_principal.productoToolStripMenuItem.Enabled = true;
                            menu_principal.ubicacionToolStripMenuItem.Enabled = true;
                            menu_principal.inventarioToolStripMenuItem2.Enabled = true;
                            menu_principal.pilotosToolStripMenuItem.Enabled = true;
                            menu_principal.repartidoresToolStripMenuItem.Enabled = true;
                            menu_principal.ordenesToolStripMenuItem.Enabled = true;
                            menu_principal.pedidoClienteToolStripMenuItem1.Enabled = true;
                            menu_principal.rutaToolStripMenuItem.Enabled = true;
                        }
                        else
                        {
                            if(comboBox1.Text == "empleado carga")
                            {
                                frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                                menu_principal.Show();
                                this.Hide();
                                menu_principal.rutaToolStripMenuItem.Enabled = true;
                                menu_principal.vehiculoToolStripMenuItem.Enabled = true;
                                menu_principal.pedidoClienteToolStripMenuItem1.Enabled = true;
                                menu_principal.pilotosToolStripMenuItem.Enabled = true;
                                menu_principal.repartidoresToolStripMenuItem.Enabled = true;
                                menu_principal.ordenesToolStripMenuItem.Enabled = true;

                            }
                            else
                            {
                                if (comboBox1.Text == "empleado piloto")
                                {
                                    frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                                    menu_principal.Show();
                                    this.Hide();
                                    menu_principal.pilotosToolStripMenuItem.Enabled = true;
                                    menu_principal.repartidoresToolStripMenuItem.Enabled = true;
                                    menu_principal.ordenesToolStripMenuItem.Enabled = true;
                                }
                                else
                                {
                                    if(comboBox1.Text == "empleado repartidor")
                                    {
                                        frmmdiMenuPrincipal menu_principal = new frmmdiMenuPrincipal();
                                        menu_principal.Show();
                                        this.Hide();
                                        menu_principal.ordenesToolStripMenuItem.Enabled = true;

                                    }
                                }
                                {

                                }
                            }
                        }
                    }
                }
            }
            else
            {
                int veces = 0;
                int intentos = 2;
                if (veces == 2)
                {
                    MessageBox.Show(ace.Mensaje, "Banco", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Su Usuario o Contraseña o Tipo NO Coinciden o son Erroneas \n \n        Le Quedan " + (intentos - veces) + " Intento(s)", "CompuBinario", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txt_usuario.Clear();
                    txt_contraseña.Clear();
                    veces = veces + 1;
                }
            }
        }

        private void Btn_salir_Click(object sender, EventArgs e)
        {
            frmplanificacionpedido busc = new frmplanificacionpedido ();
            busc.ShowDialog();

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}

        /*private void txt_contraseña_TextChanged(object sender, EventArgs e)
        {
            
            
        }*/

        /*private void Btn_salir_Click(object sender, EventArgs e)
        {
            this.Hide();
        }*/
    


