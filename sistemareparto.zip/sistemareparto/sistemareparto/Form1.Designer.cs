﻿namespace sistemareparto
{
    partial class Form_registro_pedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_registro_pedido));
            this.Lbl_pedido_cliente = new System.Windows.Forms.Label();
            this.Btn_modificar_pedido = new System.Windows.Forms.Button();
            this.dgv_pedido_cliente = new System.Windows.Forms.DataGridView();
            this.Btn_cancelar_pedido = new System.Windows.Forms.Button();
            this.cbo_nombre_producto = new System.Windows.Forms.ComboBox();
            this.Lbl_nombre = new System.Windows.Forms.Label();
            this.Lbl_marca = new System.Windows.Forms.Label();
            this.Lbl_cantidad = new System.Windows.Forms.Label();
            this.txt_cantidad = new System.Windows.Forms.TextBox();
            this.Lbl_fecha = new System.Windows.Forms.Label();
            this.txt_fecha = new System.Windows.Forms.TextBox();
            this.Lbl_cliente = new System.Windows.Forms.Label();
            this.Btn_guardar_pedido = new System.Windows.Forms.Button();
            this.Lbl_guardar = new System.Windows.Forms.Label();
            this.Lbl_cancelar = new System.Windows.Forms.Label();
            this.Btn_eliminar = new System.Windows.Forms.Button();
            this.Lbl_eliminar = new System.Windows.Forms.Label();
            this.Lbl_modificar = new System.Windows.Forms.Label();
            this.dgv_producto = new System.Windows.Forms.DataGridView();
            this.Btn_buscar = new System.Windows.Forms.Button();
            this.txt_buscar_producto = new System.Windows.Forms.TextBox();
            this.Btn_buscar_producto = new System.Windows.Forms.Button();
            this.Lbl_pedido = new System.Windows.Forms.Label();
            this.Lbl_buscar_producto = new System.Windows.Forms.Label();
            this.cbo_marca_producto = new System.Windows.Forms.ComboBox();
            this.Lbl_pedidos = new System.Windows.Forms.Label();
            this.Btn_cliente = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.new_btn = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.acpt_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedido_cliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_pedido_cliente
            // 
            this.Lbl_pedido_cliente.AutoSize = true;
            this.Lbl_pedido_cliente.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_pedido_cliente.Location = new System.Drawing.Point(240, 11);
            this.Lbl_pedido_cliente.Name = "Lbl_pedido_cliente";
            this.Lbl_pedido_cliente.Size = new System.Drawing.Size(354, 32);
            this.Lbl_pedido_cliente.TabIndex = 0;
            this.Lbl_pedido_cliente.Text = "REGISTRO PEDIDO CLIENTE";
            this.Lbl_pedido_cliente.Click += new System.EventHandler(this.label1_Click);
            // 
            // Btn_modificar_pedido
            // 
            this.Btn_modificar_pedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_modificar_pedido.BackgroundImage")));
            this.Btn_modificar_pedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_modificar_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_modificar_pedido.Location = new System.Drawing.Point(352, 47);
            this.Btn_modificar_pedido.Name = "Btn_modificar_pedido";
            this.Btn_modificar_pedido.Size = new System.Drawing.Size(65, 65);
            this.Btn_modificar_pedido.TabIndex = 1;
            this.Btn_modificar_pedido.UseVisualStyleBackColor = true;
            this.Btn_modificar_pedido.Click += new System.EventHandler(this.Btn_modificar_pedido_Click);
            // 
            // dgv_pedido_cliente
            // 
            this.dgv_pedido_cliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pedido_cliente.Location = new System.Drawing.Point(31, 369);
            this.dgv_pedido_cliente.Name = "dgv_pedido_cliente";
            this.dgv_pedido_cliente.Size = new System.Drawing.Size(397, 150);
            this.dgv_pedido_cliente.TabIndex = 4;
            // 
            // Btn_cancelar_pedido
            // 
            this.Btn_cancelar_pedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_cancelar_pedido.BackgroundImage")));
            this.Btn_cancelar_pedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cancelar_pedido.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.Btn_cancelar_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cancelar_pedido.Location = new System.Drawing.Point(440, 47);
            this.Btn_cancelar_pedido.Name = "Btn_cancelar_pedido";
            this.Btn_cancelar_pedido.Size = new System.Drawing.Size(65, 65);
            this.Btn_cancelar_pedido.TabIndex = 5;
            this.Btn_cancelar_pedido.UseVisualStyleBackColor = true;
            this.Btn_cancelar_pedido.Click += new System.EventHandler(this.Btn_cancelar_pedido_Click);
            // 
            // cbo_nombre_producto
            // 
            this.cbo_nombre_producto.FormattingEnabled = true;
            this.cbo_nombre_producto.Location = new System.Drawing.Point(186, 230);
            this.cbo_nombre_producto.Name = "cbo_nombre_producto";
            this.cbo_nombre_producto.Size = new System.Drawing.Size(150, 21);
            this.cbo_nombre_producto.TabIndex = 7;
            // 
            // Lbl_nombre
            // 
            this.Lbl_nombre.AutoSize = true;
            this.Lbl_nombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nombre.Location = new System.Drawing.Point(27, 231);
            this.Lbl_nombre.Name = "Lbl_nombre";
            this.Lbl_nombre.Size = new System.Drawing.Size(144, 20);
            this.Lbl_nombre.TabIndex = 8;
            this.Lbl_nombre.Text = "Nombre Producto:";
            // 
            // Lbl_marca
            // 
            this.Lbl_marca.AutoSize = true;
            this.Lbl_marca.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_marca.Location = new System.Drawing.Point(27, 265);
            this.Lbl_marca.Name = "Lbl_marca";
            this.Lbl_marca.Size = new System.Drawing.Size(135, 20);
            this.Lbl_marca.TabIndex = 9;
            this.Lbl_marca.Text = "Marca Producto:";
            this.Lbl_marca.Click += new System.EventHandler(this.label2_Click);
            // 
            // Lbl_cantidad
            // 
            this.Lbl_cantidad.AutoSize = true;
            this.Lbl_cantidad.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cantidad.Location = new System.Drawing.Point(395, 231);
            this.Lbl_cantidad.Name = "Lbl_cantidad";
            this.Lbl_cantidad.Size = new System.Drawing.Size(82, 20);
            this.Lbl_cantidad.TabIndex = 11;
            this.Lbl_cantidad.Text = "Cantidad:";
            this.Lbl_cantidad.Click += new System.EventHandler(this.label3_Click);
            // 
            // txt_cantidad
            // 
            this.txt_cantidad.Location = new System.Drawing.Point(187, 186);
            this.txt_cantidad.Name = "txt_cantidad";
            this.txt_cantidad.Size = new System.Drawing.Size(150, 20);
            this.txt_cantidad.TabIndex = 12;
            // 
            // Lbl_fecha
            // 
            this.Lbl_fecha.AutoSize = true;
            this.Lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_fecha.Location = new System.Drawing.Point(395, 265);
            this.Lbl_fecha.Name = "Lbl_fecha";
            this.Lbl_fecha.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_fecha.Size = new System.Drawing.Size(59, 20);
            this.Lbl_fecha.TabIndex = 13;
            this.Lbl_fecha.Text = "Fecha:";
            this.Lbl_fecha.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txt_fecha
            // 
            this.txt_fecha.Location = new System.Drawing.Point(519, 265);
            this.txt_fecha.Name = "txt_fecha";
            this.txt_fecha.Size = new System.Drawing.Size(150, 20);
            this.txt_fecha.TabIndex = 14;
            // 
            // Lbl_cliente
            // 
            this.Lbl_cliente.AutoSize = true;
            this.Lbl_cliente.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cliente.Location = new System.Drawing.Point(27, 186);
            this.Lbl_cliente.Name = "Lbl_cliente";
            this.Lbl_cliente.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_cliente.Size = new System.Drawing.Size(156, 20);
            this.Lbl_cliente.TabIndex = 15;
            this.Lbl_cliente.Text = "Seleccionar Cliente:";
            this.Lbl_cliente.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // Btn_guardar_pedido
            // 
            this.Btn_guardar_pedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_guardar_pedido.BackgroundImage")));
            this.Btn_guardar_pedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_guardar_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_guardar_pedido.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.Btn_guardar_pedido.Location = new System.Drawing.Point(188, 47);
            this.Btn_guardar_pedido.Name = "Btn_guardar_pedido";
            this.Btn_guardar_pedido.Size = new System.Drawing.Size(65, 65);
            this.Btn_guardar_pedido.TabIndex = 18;
            this.Btn_guardar_pedido.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.Btn_guardar_pedido.UseVisualStyleBackColor = true;
            // 
            // Lbl_guardar
            // 
            this.Lbl_guardar.AutoSize = true;
            this.Lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_guardar.Location = new System.Drawing.Point(184, 115);
            this.Lbl_guardar.Name = "Lbl_guardar";
            this.Lbl_guardar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.Lbl_guardar.TabIndex = 19;
            this.Lbl_guardar.Text = "Guardar";
            // 
            // Lbl_cancelar
            // 
            this.Lbl_cancelar.AutoSize = true;
            this.Lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cancelar.Location = new System.Drawing.Point(436, 115);
            this.Lbl_cancelar.Name = "Lbl_cancelar";
            this.Lbl_cancelar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.Lbl_cancelar.TabIndex = 20;
            this.Lbl_cancelar.Text = "Cancelar";
            // 
            // Btn_eliminar
            // 
            this.Btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_eliminar.BackgroundImage")));
            this.Btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_eliminar.Location = new System.Drawing.Point(271, 47);
            this.Btn_eliminar.Name = "Btn_eliminar";
            this.Btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.Btn_eliminar.TabIndex = 21;
            this.Btn_eliminar.UseVisualStyleBackColor = true;
            // 
            // Lbl_eliminar
            // 
            this.Lbl_eliminar.AutoSize = true;
            this.Lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_eliminar.Location = new System.Drawing.Point(273, 115);
            this.Lbl_eliminar.Name = "Lbl_eliminar";
            this.Lbl_eliminar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.Lbl_eliminar.TabIndex = 39;
            this.Lbl_eliminar.Text = "Eliminar";
            // 
            // Lbl_modificar
            // 
            this.Lbl_modificar.AutoSize = true;
            this.Lbl_modificar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_modificar.Location = new System.Drawing.Point(354, 115);
            this.Lbl_modificar.Name = "Lbl_modificar";
            this.Lbl_modificar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.Lbl_modificar.Size = new System.Drawing.Size(80, 20);
            this.Lbl_modificar.TabIndex = 40;
            this.Lbl_modificar.Text = "Modificar";
            // 
            // dgv_producto
            // 
            this.dgv_producto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_producto.Location = new System.Drawing.Point(463, 369);
            this.dgv_producto.Name = "dgv_producto";
            this.dgv_producto.Size = new System.Drawing.Size(397, 150);
            this.dgv_producto.TabIndex = 41;
            // 
            // Btn_buscar
            // 
            this.Btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar.BackgroundImage")));
            this.Btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_buscar.Location = new System.Drawing.Point(529, 47);
            this.Btn_buscar.Name = "Btn_buscar";
            this.Btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscar.TabIndex = 43;
            this.Btn_buscar.UseVisualStyleBackColor = true;
            this.Btn_buscar.Click += new System.EventHandler(this.Btn_buscar_Click);
            // 
            // txt_buscar_producto
            // 
            this.txt_buscar_producto.Location = new System.Drawing.Point(637, 342);
            this.txt_buscar_producto.Name = "txt_buscar_producto";
            this.txt_buscar_producto.Size = new System.Drawing.Size(150, 20);
            this.txt_buscar_producto.TabIndex = 44;
            // 
            // Btn_buscar_producto
            // 
            this.Btn_buscar_producto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscar_producto.BackgroundImage")));
            this.Btn_buscar_producto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscar_producto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_buscar_producto.Location = new System.Drawing.Point(793, 333);
            this.Btn_buscar_producto.Name = "Btn_buscar_producto";
            this.Btn_buscar_producto.Size = new System.Drawing.Size(28, 29);
            this.Btn_buscar_producto.TabIndex = 45;
            this.Btn_buscar_producto.UseVisualStyleBackColor = true;
            this.Btn_buscar_producto.Click += new System.EventHandler(this.Btn_buscar_producto_Click);
            // 
            // Lbl_pedido
            // 
            this.Lbl_pedido.AutoSize = true;
            this.Lbl_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_pedido.Location = new System.Drawing.Point(514, 115);
            this.Lbl_pedido.Name = "Lbl_pedido";
            this.Lbl_pedido.Size = new System.Drawing.Size(114, 20);
            this.Lbl_pedido.TabIndex = 46;
            this.Lbl_pedido.Text = "Buscar Pedido";
            this.Lbl_pedido.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // Lbl_buscar_producto
            // 
            this.Lbl_buscar_producto.AutoSize = true;
            this.Lbl_buscar_producto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_buscar_producto.Location = new System.Drawing.Point(630, 319);
            this.Lbl_buscar_producto.Name = "Lbl_buscar_producto";
            this.Lbl_buscar_producto.Size = new System.Drawing.Size(130, 20);
            this.Lbl_buscar_producto.TabIndex = 47;
            this.Lbl_buscar_producto.Text = "Buscar Producto";
            // 
            // cbo_marca_producto
            // 
            this.cbo_marca_producto.FormattingEnabled = true;
            this.cbo_marca_producto.Location = new System.Drawing.Point(186, 267);
            this.cbo_marca_producto.Name = "cbo_marca_producto";
            this.cbo_marca_producto.Size = new System.Drawing.Size(150, 21);
            this.cbo_marca_producto.TabIndex = 49;
            // 
            // Lbl_pedidos
            // 
            this.Lbl_pedidos.AutoSize = true;
            this.Lbl_pedidos.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_pedidos.Location = new System.Drawing.Point(31, 341);
            this.Lbl_pedidos.Name = "Lbl_pedidos";
            this.Lbl_pedidos.Size = new System.Drawing.Size(150, 20);
            this.Lbl_pedidos.TabIndex = 50;
            this.Lbl_pedidos.Text = "Listado de Pedidos:";
            // 
            // Btn_cliente
            // 
            this.Btn_cliente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_cliente.BackgroundImage")));
            this.Btn_cliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_cliente.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_cliente.Location = new System.Drawing.Point(343, 178);
            this.Btn_cliente.Name = "Btn_cliente";
            this.Btn_cliente.Size = new System.Drawing.Size(27, 30);
            this.Btn_cliente.TabIndex = 51;
            this.Btn_cliente.UseVisualStyleBackColor = true;
            this.Btn_cliente.Click += new System.EventHandler(this.Btn_cliente_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(112, 115);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 20);
            this.label21.TabIndex = 95;
            this.label21.Text = "Nuevo";
            // 
            // new_btn
            // 
            this.new_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("new_btn.BackgroundImage")));
            this.new_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.new_btn.Location = new System.Drawing.Point(106, 47);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(65, 65);
            this.new_btn.TabIndex = 94;
            this.new_btn.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(630, 115);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(70, 20);
            this.label15.TabIndex = 101;
            this.label15.Text = "Aceptar";
            // 
            // acpt_btn
            // 
            this.acpt_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("acpt_btn.BackgroundImage")));
            this.acpt_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.acpt_btn.Location = new System.Drawing.Point(634, 47);
            this.acpt_btn.Name = "acpt_btn";
            this.acpt_btn.Size = new System.Drawing.Size(65, 65);
            this.acpt_btn.TabIndex = 100;
            this.acpt_btn.UseVisualStyleBackColor = true;
            // 
            // Form_registro_pedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.acpt_btn);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.Btn_cliente);
            this.Controls.Add(this.Lbl_pedidos);
            this.Controls.Add(this.cbo_marca_producto);
            this.Controls.Add(this.Lbl_buscar_producto);
            this.Controls.Add(this.Lbl_pedido);
            this.Controls.Add(this.Btn_buscar_producto);
            this.Controls.Add(this.txt_buscar_producto);
            this.Controls.Add(this.Btn_buscar);
            this.Controls.Add(this.dgv_producto);
            this.Controls.Add(this.Lbl_modificar);
            this.Controls.Add(this.Lbl_eliminar);
            this.Controls.Add(this.Btn_eliminar);
            this.Controls.Add(this.Lbl_cancelar);
            this.Controls.Add(this.Btn_modificar_pedido);
            this.Controls.Add(this.Lbl_guardar);
            this.Controls.Add(this.Btn_guardar_pedido);
            this.Controls.Add(this.Lbl_cliente);
            this.Controls.Add(this.Btn_cancelar_pedido);
            this.Controls.Add(this.txt_fecha);
            this.Controls.Add(this.Lbl_fecha);
            this.Controls.Add(this.txt_cantidad);
            this.Controls.Add(this.Lbl_cantidad);
            this.Controls.Add(this.Lbl_marca);
            this.Controls.Add(this.Lbl_nombre);
            this.Controls.Add(this.cbo_nombre_producto);
            this.Controls.Add(this.dgv_pedido_cliente);
            this.Controls.Add(this.Lbl_pedido_cliente);
            this.Name = "Form_registro_pedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "REGISTRO PEDIDO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedido_cliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_pedido_cliente;
        private System.Windows.Forms.Button Btn_modificar_pedido;
        private System.Windows.Forms.DataGridView dgv_pedido_cliente;
        private System.Windows.Forms.Button Btn_cancelar_pedido;
        private System.Windows.Forms.ComboBox cbo_nombre_producto;
        private System.Windows.Forms.Label Lbl_nombre;
        private System.Windows.Forms.Label Lbl_marca;
        private System.Windows.Forms.Label Lbl_cantidad;
        private System.Windows.Forms.TextBox txt_cantidad;
        private System.Windows.Forms.Label Lbl_fecha;
        private System.Windows.Forms.TextBox txt_fecha;
        private System.Windows.Forms.Label Lbl_cliente;
        private System.Windows.Forms.Button Btn_guardar_pedido;
        private System.Windows.Forms.Label Lbl_guardar;
        private System.Windows.Forms.Label Lbl_cancelar;
        private System.Windows.Forms.Button Btn_eliminar;
        private System.Windows.Forms.Label Lbl_eliminar;
        private System.Windows.Forms.Label Lbl_modificar;
        private System.Windows.Forms.DataGridView dgv_producto;
        private System.Windows.Forms.Button Btn_buscar;
        private System.Windows.Forms.TextBox txt_buscar_producto;
        private System.Windows.Forms.Button Btn_buscar_producto;
        private System.Windows.Forms.Label Lbl_pedido;
        private System.Windows.Forms.Label Lbl_buscar_producto;
        private System.Windows.Forms.ComboBox cbo_marca_producto;
        private System.Windows.Forms.Label Lbl_pedidos;
        private System.Windows.Forms.Button Btn_cliente;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button new_btn;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button acpt_btn;
    }
}

