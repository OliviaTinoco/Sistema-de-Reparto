﻿namespace sistemareparto
{
    partial class buscar_proveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(buscar_proveedor));
            this.Lbl_titulo = new System.Windows.Forms.Label();
            this.Lbl_nombre = new System.Windows.Forms.Label();
            this.Lbl_buscar = new System.Windows.Forms.Label();
            this.dgv_buscarprov = new System.Windows.Forms.DataGridView();
            this.txt_buscar = new System.Windows.Forms.TextBox();
            this.Btn_buscarprov = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.Lbl_aceptar = new System.Windows.Forms.Label();
            this.Lbl_cancelar = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_buscarprov)).BeginInit();
            this.SuspendLayout();
            // 
            // Lbl_titulo
            // 
            this.Lbl_titulo.AutoSize = true;
            this.Lbl_titulo.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_titulo.Location = new System.Drawing.Point(273, 9);
            this.Lbl_titulo.Name = "Lbl_titulo";
            this.Lbl_titulo.Size = new System.Drawing.Size(262, 36);
            this.Lbl_titulo.TabIndex = 0;
            this.Lbl_titulo.Text = "Buscar Proveedor";
            // 
            // Lbl_nombre
            // 
            this.Lbl_nombre.AutoSize = true;
            this.Lbl_nombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_nombre.Location = new System.Drawing.Point(68, 90);
            this.Lbl_nombre.Name = "Lbl_nombre";
            this.Lbl_nombre.Size = new System.Drawing.Size(68, 20);
            this.Lbl_nombre.TabIndex = 1;
            this.Lbl_nombre.Text = "Nombre";
            // 
            // Lbl_buscar
            // 
            this.Lbl_buscar.AutoSize = true;
            this.Lbl_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_buscar.Location = new System.Drawing.Point(426, 137);
            this.Lbl_buscar.Name = "Lbl_buscar";
            this.Lbl_buscar.Size = new System.Drawing.Size(58, 20);
            this.Lbl_buscar.TabIndex = 2;
            this.Lbl_buscar.Text = "Buscar";
            // 
            // dgv_buscarprov
            // 
            this.dgv_buscarprov.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_buscarprov.Location = new System.Drawing.Point(25, 137);
            this.dgv_buscarprov.Name = "dgv_buscarprov";
            this.dgv_buscarprov.Size = new System.Drawing.Size(800, 150);
            this.dgv_buscarprov.TabIndex = 3;
            // 
            // txt_buscar
            // 
            this.txt_buscar.Location = new System.Drawing.Point(171, 90);
            this.txt_buscar.Name = "txt_buscar";
            this.txt_buscar.Size = new System.Drawing.Size(150, 20);
            this.txt_buscar.TabIndex = 5;
            // 
            // Btn_buscarprov
            // 
            this.Btn_buscarprov.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btn_buscarprov.BackgroundImage")));
            this.Btn_buscarprov.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_buscarprov.Location = new System.Drawing.Point(337, 48);
            this.Btn_buscarprov.Name = "Btn_buscarprov";
            this.Btn_buscarprov.Size = new System.Drawing.Size(65, 65);
            this.Btn_buscarprov.TabIndex = 7;
            this.Btn_buscarprov.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(318, 316);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(65, 65);
            this.button1.TabIndex = 8;
            this.button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button2.BackgroundImage")));
            this.button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button2.Location = new System.Drawing.Point(419, 316);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(65, 65);
            this.button2.TabIndex = 9;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // Lbl_aceptar
            // 
            this.Lbl_aceptar.AutoSize = true;
            this.Lbl_aceptar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_aceptar.Location = new System.Drawing.Point(314, 384);
            this.Lbl_aceptar.Name = "Lbl_aceptar";
            this.Lbl_aceptar.Size = new System.Drawing.Size(70, 20);
            this.Lbl_aceptar.TabIndex = 10;
            this.Lbl_aceptar.Text = "Aceptar";
            // 
            // Lbl_cancelar
            // 
            this.Lbl_cancelar.AutoSize = true;
            this.Lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl_cancelar.Location = new System.Drawing.Point(415, 384);
            this.Lbl_cancelar.Name = "Lbl_cancelar";
            this.Lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.Lbl_cancelar.TabIndex = 11;
            this.Lbl_cancelar.Text = "Cancelar";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(333, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Buscar";
            // 
            // buscar_proveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(837, 418);
            this.Controls.Add(this.Lbl_cancelar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Lbl_aceptar);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Btn_buscarprov);
            this.Controls.Add(this.txt_buscar);
            this.Controls.Add(this.dgv_buscarprov);
            this.Controls.Add(this.Lbl_buscar);
            this.Controls.Add(this.Lbl_nombre);
            this.Controls.Add(this.Lbl_titulo);
            this.Name = "buscar_proveedor";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "buscar_proveedor";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_buscarprov)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Lbl_titulo;
        private System.Windows.Forms.Label Lbl_nombre;
        private System.Windows.Forms.Label Lbl_buscar;
        private System.Windows.Forms.DataGridView dgv_buscarprov;
        private System.Windows.Forms.TextBox txt_buscar;
        private System.Windows.Forms.Button Btn_buscarprov;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label Lbl_aceptar;
        private System.Windows.Forms.Label Lbl_cancelar;
        private System.Windows.Forms.Label label1;
    }
}