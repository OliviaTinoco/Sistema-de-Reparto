﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
    public class clsBdComun
    {
        public static MySqlConnection ObtenerConexion()
        {
            MySqlConnection conectar = new MySqlConnection("server=127.0.0.1; database=bdsistemadereparto3; Uid=root; pwd=;");
            //MySqlConnection conectar = new MySqlConnection("server=192.168.30.1; database=bdsistemadereparto3; Uid=sammy; pwd=soa1234;");
            conectar.Open();
            return conectar;
        }
    }
}
