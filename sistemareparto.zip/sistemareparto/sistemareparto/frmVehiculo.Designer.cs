﻿namespace sistemareparto
{
    partial class frmVehiculo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmVehiculo));
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.Lbl15 = new System.Windows.Forms.Label();
            this.Lbl14 = new System.Windows.Forms.Label();
            this.Lbl13 = new System.Windows.Forms.Label();
            this.dgv = new System.Windows.Forms.DataGridView();
            this.Lbl12 = new System.Windows.Forms.Label();
            this.txt5 = new System.Windows.Forms.TextBox();
            this.txt6 = new System.Windows.Forms.TextBox();
            this.txt2 = new System.Windows.Forms.TextBox();
            this.txt3 = new System.Windows.Forms.TextBox();
            this.txt4 = new System.Windows.Forms.TextBox();
            this.Lbl11 = new System.Windows.Forms.Label();
            this.Lbl10 = new System.Windows.Forms.Label();
            this.Lbl9 = new System.Windows.Forms.Label();
            this.Lbl8 = new System.Windows.Forms.Label();
            this.Lbl7 = new System.Windows.Forms.Label();
            this.Lbl6 = new System.Windows.Forms.Label();
            this.txt1 = new System.Windows.Forms.TextBox();
            this.Lbl5 = new System.Windows.Forms.Label();
            this.Lbl4 = new System.Windows.Forms.Label();
            this.Lbl2 = new System.Windows.Forms.Label();
            this.Lbl3 = new System.Windows.Forms.Label();
            this.acpt_btn = new System.Windows.Forms.Button();
            this.busc_btn = new System.Windows.Forms.Button();
            this.cncl_btn = new System.Windows.Forms.Button();
            this.new_btn = new System.Windows.Forms.Button();
            this.del_btn = new System.Windows.Forms.Button();
            this.mod_btn = new System.Windows.Forms.Button();
            this.save_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).BeginInit();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(506, 278);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(150, 20);
            this.textBox1.TabIndex = 59;
            // 
            // Lbl15
            // 
            this.Lbl15.AutoSize = true;
            this.Lbl15.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl15.Location = new System.Drawing.Point(436, 278);
            this.Lbl15.Name = "Lbl15";
            this.Lbl15.Size = new System.Drawing.Size(48, 21);
            this.Lbl15.TabIndex = 58;
            this.Lbl15.Text = "Ruta";
            // 
            // Lbl14
            // 
            this.Lbl14.AutoSize = true;
            this.Lbl14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl14.Location = new System.Drawing.Point(504, 122);
            this.Lbl14.Name = "Lbl14";
            this.Lbl14.Size = new System.Drawing.Size(48, 15);
            this.Lbl14.TabIndex = 57;
            this.Lbl14.Text = "Aceptar";
            // 
            // Lbl13
            // 
            this.Lbl13.AutoSize = true;
            this.Lbl13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl13.Location = new System.Drawing.Point(582, 122);
            this.Lbl13.Name = "Lbl13";
            this.Lbl13.Size = new System.Drawing.Size(60, 15);
            this.Lbl13.TabIndex = 55;
            this.Lbl13.Text = "Cancerlar";
            // 
            // dgv
            // 
            this.dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv.Location = new System.Drawing.Point(9, 320);
            this.dgv.Name = "dgv";
            this.dgv.Size = new System.Drawing.Size(800, 150);
            this.dgv.TabIndex = 53;
            // 
            // Lbl12
            // 
            this.Lbl12.AutoSize = true;
            this.Lbl12.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl12.Location = new System.Drawing.Point(315, 7);
            this.Lbl12.Name = "Lbl12";
            this.Lbl12.Size = new System.Drawing.Size(113, 24);
            this.Lbl12.TabIndex = 52;
            this.Lbl12.Text = "VEHICULO";
            // 
            // txt5
            // 
            this.txt5.Location = new System.Drawing.Point(504, 207);
            this.txt5.Name = "txt5";
            this.txt5.Size = new System.Drawing.Size(150, 20);
            this.txt5.TabIndex = 51;
            // 
            // txt6
            // 
            this.txt6.Location = new System.Drawing.Point(504, 240);
            this.txt6.Name = "txt6";
            this.txt6.Size = new System.Drawing.Size(150, 20);
            this.txt6.TabIndex = 50;
            // 
            // txt2
            // 
            this.txt2.Location = new System.Drawing.Point(196, 207);
            this.txt2.Name = "txt2";
            this.txt2.Size = new System.Drawing.Size(150, 20);
            this.txt2.TabIndex = 49;
            // 
            // txt3
            // 
            this.txt3.Location = new System.Drawing.Point(196, 243);
            this.txt3.Name = "txt3";
            this.txt3.Size = new System.Drawing.Size(150, 20);
            this.txt3.TabIndex = 48;
            // 
            // txt4
            // 
            this.txt4.Location = new System.Drawing.Point(504, 173);
            this.txt4.Name = "txt4";
            this.txt4.Size = new System.Drawing.Size(150, 20);
            this.txt4.TabIndex = 47;
            // 
            // Lbl11
            // 
            this.Lbl11.AutoSize = true;
            this.Lbl11.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl11.Location = new System.Drawing.Point(439, 240);
            this.Lbl11.Name = "Lbl11";
            this.Lbl11.Size = new System.Drawing.Size(64, 21);
            this.Lbl11.TabIndex = 46;
            this.Lbl11.Text = "Estado";
            // 
            // Lbl10
            // 
            this.Lbl10.AutoSize = true;
            this.Lbl10.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl10.Location = new System.Drawing.Point(436, 207);
            this.Lbl10.Name = "Lbl10";
            this.Lbl10.Size = new System.Drawing.Size(62, 21);
            this.Lbl10.TabIndex = 45;
            this.Lbl10.Text = "Marca";
            // 
            // Lbl9
            // 
            this.Lbl9.AutoSize = true;
            this.Lbl9.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl9.Location = new System.Drawing.Point(441, 172);
            this.Lbl9.Name = "Lbl9";
            this.Lbl9.Size = new System.Drawing.Size(51, 21);
            this.Lbl9.TabIndex = 44;
            this.Lbl9.Text = "Linea";
            // 
            // Lbl8
            // 
            this.Lbl8.AutoSize = true;
            this.Lbl8.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl8.Location = new System.Drawing.Point(136, 240);
            this.Lbl8.Name = "Lbl8";
            this.Lbl8.Size = new System.Drawing.Size(51, 21);
            this.Lbl8.TabIndex = 43;
            this.Lbl8.Text = "Color";
            // 
            // Lbl7
            // 
            this.Lbl7.AutoSize = true;
            this.Lbl7.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl7.Location = new System.Drawing.Point(131, 204);
            this.Lbl7.Name = "Lbl7";
            this.Lbl7.Size = new System.Drawing.Size(59, 21);
            this.Lbl7.TabIndex = 42;
            this.Lbl7.Text = "Chasis";
            // 
            // Lbl6
            // 
            this.Lbl6.AutoSize = true;
            this.Lbl6.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl6.Location = new System.Drawing.Point(131, 170);
            this.Lbl6.Name = "Lbl6";
            this.Lbl6.Size = new System.Drawing.Size(54, 21);
            this.Lbl6.TabIndex = 41;
            this.Lbl6.Text = "Placa";
            // 
            // txt1
            // 
            this.txt1.Location = new System.Drawing.Point(196, 171);
            this.txt1.Name = "txt1";
            this.txt1.Size = new System.Drawing.Size(150, 20);
            this.txt1.TabIndex = 40;
            // 
            // Lbl5
            // 
            this.Lbl5.AutoSize = true;
            this.Lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl5.Location = new System.Drawing.Point(675, 122);
            this.Lbl5.Name = "Lbl5";
            this.Lbl5.Size = new System.Drawing.Size(45, 15);
            this.Lbl5.TabIndex = 39;
            this.Lbl5.Text = "Buscar";
            // 
            // Lbl4
            // 
            this.Lbl4.AutoSize = true;
            this.Lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl4.Location = new System.Drawing.Point(418, 122);
            this.Lbl4.Name = "Lbl4";
            this.Lbl4.Size = new System.Drawing.Size(53, 15);
            this.Lbl4.TabIndex = 38;
            this.Lbl4.Text = "Eliminar";
            // 
            // Lbl2
            // 
            this.Lbl2.AutoSize = true;
            this.Lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl2.Location = new System.Drawing.Point(238, 122);
            this.Lbl2.Name = "Lbl2";
            this.Lbl2.Size = new System.Drawing.Size(52, 15);
            this.Lbl2.TabIndex = 37;
            this.Lbl2.Text = "Guardar";
            // 
            // Lbl3
            // 
            this.Lbl3.AutoSize = true;
            this.Lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Lbl3.Location = new System.Drawing.Point(320, 122);
            this.Lbl3.Name = "Lbl3";
            this.Lbl3.Size = new System.Drawing.Size(60, 15);
            this.Lbl3.TabIndex = 36;
            this.Lbl3.Text = "Actualizar";
            // 
            // acpt_btn
            // 
            this.acpt_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("acpt_btn.BackgroundImage")));
            this.acpt_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.acpt_btn.Location = new System.Drawing.Point(487, 54);
            this.acpt_btn.Name = "acpt_btn";
            this.acpt_btn.Size = new System.Drawing.Size(65, 65);
            this.acpt_btn.TabIndex = 76;
            this.acpt_btn.UseVisualStyleBackColor = true;
            // 
            // busc_btn
            // 
            this.busc_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("busc_btn.BackgroundImage")));
            this.busc_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.busc_btn.Location = new System.Drawing.Point(668, 54);
            this.busc_btn.Name = "busc_btn";
            this.busc_btn.Size = new System.Drawing.Size(65, 65);
            this.busc_btn.TabIndex = 75;
            this.busc_btn.UseVisualStyleBackColor = true;
            this.busc_btn.Click += new System.EventHandler(this.busc_btn_Click);
            // 
            // cncl_btn
            // 
            this.cncl_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("cncl_btn.BackgroundImage")));
            this.cncl_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.cncl_btn.Location = new System.Drawing.Point(574, 54);
            this.cncl_btn.Name = "cncl_btn";
            this.cncl_btn.Size = new System.Drawing.Size(65, 65);
            this.cncl_btn.TabIndex = 74;
            this.cncl_btn.UseVisualStyleBackColor = true;
            // 
            // new_btn
            // 
            this.new_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("new_btn.BackgroundImage")));
            this.new_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.new_btn.Location = new System.Drawing.Point(135, 54);
            this.new_btn.Name = "new_btn";
            this.new_btn.Size = new System.Drawing.Size(65, 65);
            this.new_btn.TabIndex = 73;
            this.new_btn.UseVisualStyleBackColor = true;
            // 
            // del_btn
            // 
            this.del_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("del_btn.BackgroundImage")));
            this.del_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.del_btn.Location = new System.Drawing.Point(406, 54);
            this.del_btn.Name = "del_btn";
            this.del_btn.Size = new System.Drawing.Size(65, 65);
            this.del_btn.TabIndex = 72;
            this.del_btn.UseVisualStyleBackColor = true;
            // 
            // mod_btn
            // 
            this.mod_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("mod_btn.BackgroundImage")));
            this.mod_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.mod_btn.Location = new System.Drawing.Point(315, 54);
            this.mod_btn.Name = "mod_btn";
            this.mod_btn.Size = new System.Drawing.Size(65, 65);
            this.mod_btn.TabIndex = 71;
            this.mod_btn.UseVisualStyleBackColor = true;
            // 
            // save_btn
            // 
            this.save_btn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("save_btn.BackgroundImage")));
            this.save_btn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.save_btn.Location = new System.Drawing.Point(225, 54);
            this.save_btn.Name = "save_btn";
            this.save_btn.Size = new System.Drawing.Size(65, 65);
            this.save_btn.TabIndex = 70;
            this.save_btn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(138, 122);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 15);
            this.label1.TabIndex = 77;
            this.label1.Text = "Nuevo";
            // 
            // button1
            // 
            this.button1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button1.BackgroundImage")));
            this.button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.button1.Location = new System.Drawing.Point(668, 268);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(37, 31);
            this.button1.TabIndex = 78;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // frmVehiculo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(819, 476);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.acpt_btn);
            this.Controls.Add(this.busc_btn);
            this.Controls.Add(this.cncl_btn);
            this.Controls.Add(this.new_btn);
            this.Controls.Add(this.del_btn);
            this.Controls.Add(this.mod_btn);
            this.Controls.Add(this.save_btn);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.Lbl15);
            this.Controls.Add(this.Lbl14);
            this.Controls.Add(this.Lbl13);
            this.Controls.Add(this.dgv);
            this.Controls.Add(this.Lbl12);
            this.Controls.Add(this.txt5);
            this.Controls.Add(this.txt6);
            this.Controls.Add(this.txt2);
            this.Controls.Add(this.txt3);
            this.Controls.Add(this.txt4);
            this.Controls.Add(this.Lbl11);
            this.Controls.Add(this.Lbl10);
            this.Controls.Add(this.Lbl9);
            this.Controls.Add(this.Lbl8);
            this.Controls.Add(this.Lbl7);
            this.Controls.Add(this.Lbl6);
            this.Controls.Add(this.txt1);
            this.Controls.Add(this.Lbl5);
            this.Controls.Add(this.Lbl4);
            this.Controls.Add(this.Lbl2);
            this.Controls.Add(this.Lbl3);
            this.Name = "frmVehiculo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmVehiculo";
            ((System.ComponentModel.ISupportInitialize)(this.dgv)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label Lbl15;
        private System.Windows.Forms.Label Lbl14;
        private System.Windows.Forms.Label Lbl13;
        private System.Windows.Forms.DataGridView dgv;
        private System.Windows.Forms.Label Lbl12;
        private System.Windows.Forms.TextBox txt5;
        private System.Windows.Forms.TextBox txt6;
        private System.Windows.Forms.TextBox txt2;
        private System.Windows.Forms.TextBox txt3;
        private System.Windows.Forms.TextBox txt4;
        private System.Windows.Forms.Label Lbl11;
        private System.Windows.Forms.Label Lbl10;
        private System.Windows.Forms.Label Lbl9;
        private System.Windows.Forms.Label Lbl8;
        private System.Windows.Forms.Label Lbl7;
        private System.Windows.Forms.Label Lbl6;
        private System.Windows.Forms.TextBox txt1;
        private System.Windows.Forms.Label Lbl5;
        private System.Windows.Forms.Label Lbl4;
        private System.Windows.Forms.Label Lbl2;
        private System.Windows.Forms.Label Lbl3;
        private System.Windows.Forms.Button acpt_btn;
        private System.Windows.Forms.Button busc_btn;
        private System.Windows.Forms.Button cncl_btn;
        private System.Windows.Forms.Button new_btn;
        private System.Windows.Forms.Button del_btn;
        private System.Windows.Forms.Button mod_btn;
        private System.Windows.Forms.Button save_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
    }
}