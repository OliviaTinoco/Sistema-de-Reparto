﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sistemareparto.Modelo;

namespace sistemareparto
{
    public partial class frmBuscarGestion : Form
    {

        private clsGestionVehiculo gestion;

        #region Procedimiento

        private void pro_loadGestion()
        {
            clsModeloGestion mModeloGestion = new clsModeloGestion();
            dgv_vehiculo.DataSource = mModeloGestion.fun_getAllGestiones();

        }

        #endregion
        public frmBuscarGestion()
        {
            InitializeComponent();
            pro_loadGestion();
        }
       
        private void lbl_titulo_Click(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {

        }

        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_vehiculo.SelectedRows.Count == 1)
            {
                DataGridViewRow dgvrFila = dgv_vehiculo.SelectedRows[0];

                gestion = new clsGestionVehiculo();
                gestion.iIdGest = Convert.ToInt32(dgvrFila.Cells[0].Value.ToString());
                gestion.iVehi = Convert.ToInt32(dgvrFila.Cells[1].Value.ToString());
                gestion.dFechaSale = Convert.ToDateTime(dgvrFila.Cells[2].Value.ToString());
                gestion.dFechaIngre = Convert.ToDateTime(dgvrFila.Cells[3].Value.ToString());
                gestion.sEstadoIngre = dgvrFila.Cells[5].ToString();
                gestion.sEstadoSale = dgvrFila.Cells[6].ToString();
                gestion.sEstadoGestion = dgvrFila.Cells[7].ToString();

                this.Close();

            }

            else
            {

                MessageBox.Show("Debe de Seleccionar una Gestion de Vehiculo");

            }
                



            }

        private void btn_cancelar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
