﻿namespace sistemareparto
{
    partial class Form_registro_pedido
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_registro_pedido));
            this.lbl_pedido_cliente = new System.Windows.Forms.Label();
            this.btn_modificarpedido = new System.Windows.Forms.Button();
            this.dgv_pedidocliente = new System.Windows.Forms.DataGridView();
            this.btn_cancelarpedido = new System.Windows.Forms.Button();
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.lbl_producto2 = new System.Windows.Forms.Label();
            this.lbl_cantidad = new System.Windows.Forms.Label();
            this.txt_cliente = new System.Windows.Forms.TextBox();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.txt_fecha = new System.Windows.Forms.TextBox();
            this.lbl_cliente = new System.Windows.Forms.Label();
            this.btn_guardarpedido = new System.Windows.Forms.Button();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.btn_eliminar = new System.Windows.Forms.Button();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_modificar = new System.Windows.Forms.Label();
            this.dgv_producto = new System.Windows.Forms.DataGridView();
            this.btn_buscar = new System.Windows.Forms.Button();
            this.lbl_pedido = new System.Windows.Forms.Label();
            this.lbl_buscar_producto = new System.Windows.Forms.Label();
            this.lbl_pedidos = new System.Windows.Forms.Label();
            this.btn_cliente = new System.Windows.Forms.Button();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.btn_nuevo = new System.Windows.Forms.Button();
            this.txt_cant = new System.Windows.Forms.TextBox();
            this.txt_producto = new System.Windows.Forms.TextBox();
            this.txt_producto2 = new System.Windows.Forms.TextBox();
            this.btn_producto = new System.Windows.Forms.Button();
            this.btn_producto2 = new System.Windows.Forms.Button();
            this.lbl_cantidad2 = new System.Windows.Forms.Label();
            this.txt_cantidad2 = new System.Windows.Forms.TextBox();
            this.lbl_producto3 = new System.Windows.Forms.Label();
            this.txt_producto3 = new System.Windows.Forms.TextBox();
            this.btn_producto3 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_cantidad3 = new System.Windows.Forms.TextBox();
            this.lbl_refrescar = new System.Windows.Forms.Label();
            this.btn_refrescar = new System.Windows.Forms.Button();
            this.Ayuda = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidocliente)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_pedido_cliente
            // 
            this.lbl_pedido_cliente.AutoSize = true;
            this.lbl_pedido_cliente.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedido_cliente.Location = new System.Drawing.Point(240, 11);
            this.lbl_pedido_cliente.Name = "lbl_pedido_cliente";
            this.lbl_pedido_cliente.Size = new System.Drawing.Size(354, 32);
            this.lbl_pedido_cliente.TabIndex = 0;
            this.lbl_pedido_cliente.Text = "REGISTRO PEDIDO CLIENTE";
            this.lbl_pedido_cliente.Click += new System.EventHandler(this.label1_Click);
            // 
            // btn_modificarpedido
            // 
            this.btn_modificarpedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_modificarpedido.BackgroundImage")));
            this.btn_modificarpedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_modificarpedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_modificarpedido.Location = new System.Drawing.Point(356, 46);
            this.btn_modificarpedido.Name = "btn_modificarpedido";
            this.btn_modificarpedido.Size = new System.Drawing.Size(65, 65);
            this.btn_modificarpedido.TabIndex = 15;
            this.btn_modificarpedido.UseVisualStyleBackColor = true;
            this.btn_modificarpedido.Click += new System.EventHandler(this.Btn_modificar_pedido_Click);
            // 
            // dgv_pedidocliente
            // 
            this.dgv_pedidocliente.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pedidocliente.Location = new System.Drawing.Point(31, 369);
            this.dgv_pedidocliente.Name = "dgv_pedidocliente";
            this.dgv_pedidocliente.Size = new System.Drawing.Size(397, 150);
            this.dgv_pedidocliente.TabIndex = 19;
            this.dgv_pedidocliente.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_pedidocliente_CellContentClick);
            // 
            // btn_cancelarpedido
            // 
            this.btn_cancelarpedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cancelarpedido.BackgroundImage")));
            this.btn_cancelarpedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cancelarpedido.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.btn_cancelarpedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cancelarpedido.Location = new System.Drawing.Point(442, 46);
            this.btn_cancelarpedido.Name = "btn_cancelarpedido";
            this.btn_cancelarpedido.Size = new System.Drawing.Size(65, 65);
            this.btn_cancelarpedido.TabIndex = 16;
            this.btn_cancelarpedido.UseVisualStyleBackColor = true;
            this.btn_cancelarpedido.Click += new System.EventHandler(this.Btn_cancelar_pedido_Click);
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nombre.Location = new System.Drawing.Point(27, 210);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(146, 20);
            this.lbl_nombre.TabIndex = 8;
            this.lbl_nombre.Text = "Nombre Producto*";
            // 
            // lbl_producto2
            // 
            this.lbl_producto2.AutoSize = true;
            this.lbl_producto2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_producto2.Location = new System.Drawing.Point(27, 247);
            this.lbl_producto2.Name = "lbl_producto2";
            this.lbl_producto2.Size = new System.Drawing.Size(89, 20);
            this.lbl_producto2.TabIndex = 9;
            this.lbl_producto2.Text = "Producto 2";
            this.lbl_producto2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl_cantidad
            // 
            this.lbl_cantidad.AutoSize = true;
            this.lbl_cantidad.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cantidad.Location = new System.Drawing.Point(395, 210);
            this.lbl_cantidad.Name = "lbl_cantidad";
            this.lbl_cantidad.Size = new System.Drawing.Size(84, 20);
            this.lbl_cantidad.TabIndex = 11;
            this.lbl_cantidad.Text = "Cantidad*";
            this.lbl_cantidad.Click += new System.EventHandler(this.label3_Click);
            // 
            // txt_cliente
            // 
            this.txt_cliente.Location = new System.Drawing.Point(187, 165);
            this.txt_cliente.Name = "txt_cliente";
            this.txt_cliente.Size = new System.Drawing.Size(150, 20);
            this.txt_cliente.TabIndex = 0;
            this.txt_cliente.TextChanged += new System.EventHandler(this.txt_cantidad_TextChanged);
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(395, 167);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_fecha.Size = new System.Drawing.Size(61, 20);
            this.lbl_fecha.TabIndex = 13;
            this.lbl_fecha.Text = "Fecha*";
            this.lbl_fecha.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // txt_fecha
            // 
            this.txt_fecha.Location = new System.Drawing.Point(518, 169);
            this.txt_fecha.Name = "txt_fecha";
            this.txt_fecha.Size = new System.Drawing.Size(150, 20);
            this.txt_fecha.TabIndex = 2;
            this.txt_fecha.TextChanged += new System.EventHandler(this.txt_fecha_TextChanged);
            // 
            // lbl_cliente
            // 
            this.lbl_cliente.AutoSize = true;
            this.lbl_cliente.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cliente.Location = new System.Drawing.Point(27, 165);
            this.lbl_cliente.Name = "lbl_cliente";
            this.lbl_cliente.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_cliente.Size = new System.Drawing.Size(158, 20);
            this.lbl_cliente.TabIndex = 15;
            this.lbl_cliente.Text = "Seleccionar Cliente*";
            this.lbl_cliente.Click += new System.EventHandler(this.label2_Click_1);
            // 
            // btn_guardarpedido
            // 
            this.btn_guardarpedido.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_guardarpedido.BackgroundImage")));
            this.btn_guardarpedido.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_guardarpedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_guardarpedido.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btn_guardarpedido.Location = new System.Drawing.Point(190, 46);
            this.btn_guardarpedido.Name = "btn_guardarpedido";
            this.btn_guardarpedido.Size = new System.Drawing.Size(65, 65);
            this.btn_guardarpedido.TabIndex = 13;
            this.btn_guardarpedido.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.btn_guardarpedido.UseVisualStyleBackColor = true;
            this.btn_guardarpedido.Click += new System.EventHandler(this.btn_guardarpedido_Click);
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_guardar.Location = new System.Drawing.Point(186, 114);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_guardar.Size = new System.Drawing.Size(71, 20);
            this.lbl_guardar.TabIndex = 19;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cancelar.Location = new System.Drawing.Point(438, 114);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_cancelar.Size = new System.Drawing.Size(78, 20);
            this.lbl_cancelar.TabIndex = 20;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // btn_eliminar
            // 
            this.btn_eliminar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_eliminar.BackgroundImage")));
            this.btn_eliminar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_eliminar.Location = new System.Drawing.Point(273, 46);
            this.btn_eliminar.Name = "btn_eliminar";
            this.btn_eliminar.Size = new System.Drawing.Size(65, 65);
            this.btn_eliminar.TabIndex = 14;
            this.btn_eliminar.UseVisualStyleBackColor = true;
            this.btn_eliminar.Click += new System.EventHandler(this.btn_eliminar_Click);
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_eliminar.Location = new System.Drawing.Point(275, 114);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_eliminar.Size = new System.Drawing.Size(63, 20);
            this.lbl_eliminar.TabIndex = 39;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_modificar
            // 
            this.lbl_modificar.AutoSize = true;
            this.lbl_modificar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_modificar.Location = new System.Drawing.Point(352, 114);
            this.lbl_modificar.Name = "lbl_modificar";
            this.lbl_modificar.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lbl_modificar.Size = new System.Drawing.Size(80, 20);
            this.lbl_modificar.TabIndex = 40;
            this.lbl_modificar.Text = "Modificar";
            // 
            // dgv_producto
            // 
            this.dgv_producto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_producto.Location = new System.Drawing.Point(463, 369);
            this.dgv_producto.Name = "dgv_producto";
            this.dgv_producto.Size = new System.Drawing.Size(397, 150);
            this.dgv_producto.TabIndex = 20;
            this.dgv_producto.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_producto_CellContentClick);
            // 
            // btn_buscar
            // 
            this.btn_buscar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_buscar.BackgroundImage")));
            this.btn_buscar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_buscar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_buscar.Location = new System.Drawing.Point(531, 46);
            this.btn_buscar.Name = "btn_buscar";
            this.btn_buscar.Size = new System.Drawing.Size(65, 65);
            this.btn_buscar.TabIndex = 17;
            this.btn_buscar.UseVisualStyleBackColor = true;
            this.btn_buscar.Click += new System.EventHandler(this.Btn_buscar_Click);
            // 
            // lbl_pedido
            // 
            this.lbl_pedido.AutoSize = true;
            this.lbl_pedido.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedido.Location = new System.Drawing.Point(516, 114);
            this.lbl_pedido.Name = "lbl_pedido";
            this.lbl_pedido.Size = new System.Drawing.Size(114, 20);
            this.lbl_pedido.TabIndex = 46;
            this.lbl_pedido.Text = "Buscar Pedido";
            this.lbl_pedido.Click += new System.EventHandler(this.label1_Click_2);
            // 
            // lbl_buscar_producto
            // 
            this.lbl_buscar_producto.AutoSize = true;
            this.lbl_buscar_producto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscar_producto.Location = new System.Drawing.Point(464, 341);
            this.lbl_buscar_producto.Name = "lbl_buscar_producto";
            this.lbl_buscar_producto.Size = new System.Drawing.Size(166, 20);
            this.lbl_buscar_producto.TabIndex = 47;
            this.lbl_buscar_producto.Text = "Listado de Productos:";
            // 
            // lbl_pedidos
            // 
            this.lbl_pedidos.AutoSize = true;
            this.lbl_pedidos.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedidos.Location = new System.Drawing.Point(31, 341);
            this.lbl_pedidos.Name = "lbl_pedidos";
            this.lbl_pedidos.Size = new System.Drawing.Size(150, 20);
            this.lbl_pedidos.TabIndex = 50;
            this.lbl_pedidos.Text = "Listado de Pedidos:";
            // 
            // btn_cliente
            // 
            this.btn_cliente.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_cliente.BackgroundImage")));
            this.btn_cliente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_cliente.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_cliente.Location = new System.Drawing.Point(343, 157);
            this.btn_cliente.Name = "btn_cliente";
            this.btn_cliente.Size = new System.Drawing.Size(27, 30);
            this.btn_cliente.TabIndex = 1;
            this.btn_cliente.UseVisualStyleBackColor = true;
            this.btn_cliente.Click += new System.EventHandler(this.Btn_cliente_Click);
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_nuevo.Location = new System.Drawing.Point(114, 114);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(59, 20);
            this.lbl_nuevo.TabIndex = 95;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // btn_nuevo
            // 
            this.btn_nuevo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_nuevo.BackgroundImage")));
            this.btn_nuevo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_nuevo.Location = new System.Drawing.Point(108, 46);
            this.btn_nuevo.Name = "btn_nuevo";
            this.btn_nuevo.Size = new System.Drawing.Size(65, 65);
            this.btn_nuevo.TabIndex = 12;
            this.btn_nuevo.UseVisualStyleBackColor = true;
            this.btn_nuevo.Click += new System.EventHandler(this.btn_nuevo_Click);
            // 
            // txt_cant
            // 
            this.txt_cant.Location = new System.Drawing.Point(518, 209);
            this.txt_cant.Name = "txt_cant";
            this.txt_cant.Size = new System.Drawing.Size(150, 20);
            this.txt_cant.TabIndex = 5;
            // 
            // txt_producto
            // 
            this.txt_producto.Location = new System.Drawing.Point(188, 209);
            this.txt_producto.Name = "txt_producto";
            this.txt_producto.Size = new System.Drawing.Size(150, 20);
            this.txt_producto.TabIndex = 3;
            this.txt_producto.TextChanged += new System.EventHandler(this.txt_producto_TextChanged);
            // 
            // txt_producto2
            // 
            this.txt_producto2.Location = new System.Drawing.Point(188, 249);
            this.txt_producto2.Name = "txt_producto2";
            this.txt_producto2.Size = new System.Drawing.Size(150, 20);
            this.txt_producto2.TabIndex = 6;
            // 
            // btn_producto
            // 
            this.btn_producto.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_producto.BackgroundImage")));
            this.btn_producto.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_producto.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_producto.Location = new System.Drawing.Point(343, 199);
            this.btn_producto.Name = "btn_producto";
            this.btn_producto.Size = new System.Drawing.Size(27, 30);
            this.btn_producto.TabIndex = 4;
            this.btn_producto.UseVisualStyleBackColor = true;
            this.btn_producto.Click += new System.EventHandler(this.btn_producto_Click);
            // 
            // btn_producto2
            // 
            this.btn_producto2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_producto2.BackgroundImage")));
            this.btn_producto2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_producto2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_producto2.Location = new System.Drawing.Point(343, 242);
            this.btn_producto2.Name = "btn_producto2";
            this.btn_producto2.Size = new System.Drawing.Size(27, 30);
            this.btn_producto2.TabIndex = 7;
            this.btn_producto2.UseVisualStyleBackColor = true;
            this.btn_producto2.Click += new System.EventHandler(this.btn_producto2_Click);
            // 
            // lbl_cantidad2
            // 
            this.lbl_cantidad2.AutoSize = true;
            this.lbl_cantidad2.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cantidad2.Location = new System.Drawing.Point(395, 249);
            this.lbl_cantidad2.Name = "lbl_cantidad2";
            this.lbl_cantidad2.Size = new System.Drawing.Size(78, 20);
            this.lbl_cantidad2.TabIndex = 107;
            this.lbl_cantidad2.Text = "Cantidad";
            this.lbl_cantidad2.Click += new System.EventHandler(this.label1_Click_3);
            // 
            // txt_cantidad2
            // 
            this.txt_cantidad2.Location = new System.Drawing.Point(518, 252);
            this.txt_cantidad2.Name = "txt_cantidad2";
            this.txt_cantidad2.Size = new System.Drawing.Size(150, 20);
            this.txt_cantidad2.TabIndex = 8;
            // 
            // lbl_producto3
            // 
            this.lbl_producto3.AutoSize = true;
            this.lbl_producto3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_producto3.Location = new System.Drawing.Point(27, 292);
            this.lbl_producto3.Name = "lbl_producto3";
            this.lbl_producto3.Size = new System.Drawing.Size(89, 20);
            this.lbl_producto3.TabIndex = 109;
            this.lbl_producto3.Text = "Producto 3";
            // 
            // txt_producto3
            // 
            this.txt_producto3.Location = new System.Drawing.Point(188, 294);
            this.txt_producto3.Name = "txt_producto3";
            this.txt_producto3.Size = new System.Drawing.Size(150, 20);
            this.txt_producto3.TabIndex = 9;
            // 
            // btn_producto3
            // 
            this.btn_producto3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_producto3.BackgroundImage")));
            this.btn_producto3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_producto3.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_producto3.Location = new System.Drawing.Point(344, 284);
            this.btn_producto3.Name = "btn_producto3";
            this.btn_producto3.Size = new System.Drawing.Size(27, 30);
            this.btn_producto3.TabIndex = 10;
            this.btn_producto3.UseVisualStyleBackColor = true;
            this.btn_producto3.Click += new System.EventHandler(this.btn_producto3_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(395, 294);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 20);
            this.label1.TabIndex = 112;
            this.label1.Text = "Cantidad";
            // 
            // txt_cantidad3
            // 
            this.txt_cantidad3.Location = new System.Drawing.Point(518, 294);
            this.txt_cantidad3.Name = "txt_cantidad3";
            this.txt_cantidad3.Size = new System.Drawing.Size(150, 20);
            this.txt_cantidad3.TabIndex = 11;
            // 
            // lbl_refrescar
            // 
            this.lbl_refrescar.AutoSize = true;
            this.lbl_refrescar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_refrescar.Location = new System.Drawing.Point(636, 113);
            this.lbl_refrescar.Name = "lbl_refrescar";
            this.lbl_refrescar.Size = new System.Drawing.Size(79, 20);
            this.lbl_refrescar.TabIndex = 113;
            this.lbl_refrescar.Text = "Refrescar";
            // 
            // btn_refrescar
            // 
            this.btn_refrescar.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btn_refrescar.BackgroundImage")));
            this.btn_refrescar.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_refrescar.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_refrescar.Location = new System.Drawing.Point(640, 45);
            this.btn_refrescar.Name = "btn_refrescar";
            this.btn_refrescar.Size = new System.Drawing.Size(65, 65);
            this.btn_refrescar.TabIndex = 18;
            this.btn_refrescar.UseVisualStyleBackColor = true;
            this.btn_refrescar.Click += new System.EventHandler(this.button1_Click);
            // 
            // Ayuda
            // 
            this.Ayuda.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Ayuda.BackgroundImage")));
            this.Ayuda.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Ayuda.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Ayuda.Location = new System.Drawing.Point(811, 11);
            this.Ayuda.Name = "Ayuda";
            this.Ayuda.Size = new System.Drawing.Size(65, 65);
            this.Ayuda.TabIndex = 114;
            this.Ayuda.UseVisualStyleBackColor = true;
            this.Ayuda.Click += new System.EventHandler(this.Ayuda_Click);
            // 
            // Form_registro_pedido
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(888, 532);
            this.Controls.Add(this.Ayuda);
            this.Controls.Add(this.btn_refrescar);
            this.Controls.Add(this.lbl_refrescar);
            this.Controls.Add(this.txt_cantidad3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_producto3);
            this.Controls.Add(this.txt_producto3);
            this.Controls.Add(this.lbl_producto3);
            this.Controls.Add(this.txt_cantidad2);
            this.Controls.Add(this.lbl_cantidad2);
            this.Controls.Add(this.btn_producto2);
            this.Controls.Add(this.btn_producto);
            this.Controls.Add(this.txt_producto2);
            this.Controls.Add(this.txt_producto);
            this.Controls.Add(this.txt_cant);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.btn_nuevo);
            this.Controls.Add(this.btn_cliente);
            this.Controls.Add(this.lbl_pedidos);
            this.Controls.Add(this.lbl_buscar_producto);
            this.Controls.Add(this.lbl_pedido);
            this.Controls.Add(this.btn_buscar);
            this.Controls.Add(this.dgv_producto);
            this.Controls.Add(this.lbl_modificar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.btn_eliminar);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.btn_modificarpedido);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.btn_guardarpedido);
            this.Controls.Add(this.lbl_cliente);
            this.Controls.Add(this.btn_cancelarpedido);
            this.Controls.Add(this.txt_fecha);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.txt_cliente);
            this.Controls.Add(this.lbl_cantidad);
            this.Controls.Add(this.lbl_producto2);
            this.Controls.Add(this.lbl_nombre);
            this.Controls.Add(this.dgv_pedidocliente);
            this.Controls.Add(this.lbl_pedido_cliente);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form_registro_pedido";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "REGISTRO PEDIDO";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidocliente)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_producto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_pedido_cliente;
        private System.Windows.Forms.Button btn_modificarpedido;
        private System.Windows.Forms.DataGridView dgv_pedidocliente;
        private System.Windows.Forms.Button btn_cancelarpedido;
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.Label lbl_producto2;
        private System.Windows.Forms.Label lbl_cantidad;
        private System.Windows.Forms.TextBox txt_cliente;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.TextBox txt_fecha;
        private System.Windows.Forms.Label lbl_cliente;
        private System.Windows.Forms.Button btn_guardarpedido;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.Button btn_eliminar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_modificar;
        private System.Windows.Forms.DataGridView dgv_producto;
        private System.Windows.Forms.Button btn_buscar;
        private System.Windows.Forms.Label lbl_pedido;
        private System.Windows.Forms.Label lbl_buscar_producto;
        private System.Windows.Forms.Label lbl_pedidos;
        private System.Windows.Forms.Button btn_cliente;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.Button btn_nuevo;
        private System.Windows.Forms.TextBox txt_cant;
        private System.Windows.Forms.TextBox txt_producto;
        private System.Windows.Forms.TextBox txt_producto2;
        private System.Windows.Forms.Button btn_producto;
        private System.Windows.Forms.Button btn_producto2;
        private System.Windows.Forms.Label lbl_cantidad2;
        private System.Windows.Forms.TextBox txt_cantidad2;
        private System.Windows.Forms.Label lbl_producto3;
        private System.Windows.Forms.TextBox txt_producto3;
        private System.Windows.Forms.Button btn_producto3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_cantidad3;
        private System.Windows.Forms.Label lbl_refrescar;
        private System.Windows.Forms.Button btn_refrescar;
        private System.Windows.Forms.Button Ayuda;
    }
}

