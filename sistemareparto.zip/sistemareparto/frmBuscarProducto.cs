﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmBuscarProducto : Form
    {
        public frmBuscarProducto()
        {
            InitializeComponent();
        }

        private void frmBuscarProducto_Load(object sender, EventArgs e)
        {

        }

        private void btn_buscar_Click(object sender, EventArgs e)
        {
            dgv_prod.DataSource = clsProductoOp.Buscar(txt_nombre.Text);


        }


        public clsProducto ProdSelec { get; set; }
        private void btn_aceptar_Click(object sender, EventArgs e)
        {
            if (dgv_prod.SelectedRows.Count == 1)
            {
                int id = Convert.ToInt16(dgv_prod.CurrentRow.Cells[0].Value);
                //string id = dataGridView1.Row.Cells[0].Value;
                //string id1 = dataGridView1.CurrentRow.Cells[0].Value.ToString;
                ProdSelec = clsProductoOp.ObtenerProd(id);

                this.Close();
            }
            else
                MessageBox.Show("debe de seleccionar una fila");

        }
    }
}
