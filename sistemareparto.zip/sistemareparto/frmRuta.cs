﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistemareparto
{
    public partial class frmRuta : Form
    {
        public frmRuta()
        {
            InitializeComponent();
        }


        public clsRuta RutAct { get; set; }
        private void btn_buscar_Click(object sender, EventArgs e)
        {
            frmBuscarRuta buscrut = new frmBuscarRuta();
            buscrut.ShowDialog();


            if (buscrut.RutaSelec != null)
            {

                RutAct = buscrut.RutaSelec;
                txt_zona.Text = buscrut.RutaSelec.szona;
                txt_desc.Text = buscrut.RutaSelec.sdecripcion;


            }
            //mostradatos();
        }

        private void frmRuta_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            clsBdComun.ObtenerConexion();
            MessageBox.Show("Conectado");
        }

        private void btn_guardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_zona.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {

                    clsRuta pRuta = new clsRuta();

                    pRuta.szona = txt_zona.Text.Trim();
                    pRuta.sdecripcion = txt_desc.Text.Trim();



                    int iresultado = clsRutaOp.Agregar(pRuta);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Usuario Guardado Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo guardar el usuario", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void txt_zona_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_modificar_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txt_zona.Text))

                    MessageBox.Show("Hay Uno o mas Campos obligatorio vacíos", "Campos Vacios!!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                else
                {

                    clsRuta pRuta = new clsRuta();

                    pRuta.szona = txt_zona.Text.Trim();
                    pRuta.sdecripcion = txt_desc.Text.Trim();



                    int iresultado = clsRutaOp.Actualizar(pRuta);
                    if (iresultado > 0)
                    {
                        MessageBox.Show("Ruta actualizada Con Exito!!", "Guardado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Limpiar();
                        //Deshabilitar();
                    }
                    else
                    {
                        MessageBox.Show("No se pudo actualizar la ruta", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    }
                }


                // mostradatos();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void btn_eliminar_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Esta Seguro que desea eliminar la ruta Actual", "Estas Seguro??", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                if (clsRutaOp.Eliminar(RutAct.icod) > 0)
                {
                    MessageBox.Show("Ruta Eliminado Correctamente!", "Ruta Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Limpiar();
                    //Deshabilitar();
                }
                else
                {
                    MessageBox.Show("No se pudo eliminar la ruta", "Ruta No Eliminado", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }
            }
            else
                MessageBox.Show("Se cancelo la eliminacion", "Eliminacion Cancelada", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

        }
    }
}
