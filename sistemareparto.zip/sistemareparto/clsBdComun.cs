﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace sistemareparto
{
   public class clsBdComun //Clase publica que genera la conexión a la base de datos
    {
        public static MySqlConnection ObtenerConexion()
        {
            MySqlConnection conectar = new MySqlConnection("server=127.0.0.1; database=bdsistemadereparto; Uid=root; pwd=;");

            conectar.Open();
            return conectar;
        }
    }
}
