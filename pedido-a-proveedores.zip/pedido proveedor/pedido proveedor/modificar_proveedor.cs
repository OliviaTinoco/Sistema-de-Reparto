﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pedido_proveedor
{
    public partial class frm_modificarProveedor : Form
    {
        public frm_modificarProveedor()
        {
            InitializeComponent();
        }

        private void pic_nuevo_Click(object sender, EventArgs e)
        {
            frm_pedidoProveedor pedpro = new frm_pedidoProveedor();
            pedpro.ShowDialog();
        }

        private void pic_buscar_Click(object sender, EventArgs e)
        {
            frm_bucarPedidoP buscped = new frm_bucarPedidoP();
            buscped.ShowDialog();
        }
    }
}
