﻿namespace pedido_proveedor
{
    partial class frm_bucarPedidoP
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbo_proveedor = new System.Windows.Forms.ComboBox();
            this.lbl_proveedor = new System.Windows.Forms.Label();
            this.ltp_fecha = new System.Windows.Forms.DateTimePicker();
            this.dgv_busquedaPedidos = new System.Windows.Forms.DataGridView();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_buscarPedidoProveedor = new System.Windows.Forms.Label();
            this.pic_buscar = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_busquedaPedidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_buscar)).BeginInit();
            this.SuspendLayout();
            // 
            // cbo_proveedor
            // 
            this.cbo_proveedor.FormattingEnabled = true;
            this.cbo_proveedor.Location = new System.Drawing.Point(209, 105);
            this.cbo_proveedor.Name = "cbo_proveedor";
            this.cbo_proveedor.Size = new System.Drawing.Size(150, 21);
            this.cbo_proveedor.TabIndex = 83;
            // 
            // lbl_proveedor
            // 
            this.lbl_proveedor.AutoSize = true;
            this.lbl_proveedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proveedor.Location = new System.Drawing.Point(109, 105);
            this.lbl_proveedor.Name = "lbl_proveedor";
            this.lbl_proveedor.Size = new System.Drawing.Size(90, 21);
            this.lbl_proveedor.TabIndex = 82;
            this.lbl_proveedor.Text = "Proveedor";
            // 
            // ltp_fecha
            // 
            this.ltp_fecha.Location = new System.Drawing.Point(209, 155);
            this.ltp_fecha.Name = "ltp_fecha";
            this.ltp_fecha.Size = new System.Drawing.Size(150, 20);
            this.ltp_fecha.TabIndex = 81;
            // 
            // dgv_busquedaPedidos
            // 
            this.dgv_busquedaPedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_busquedaPedidos.Location = new System.Drawing.Point(19, 211);
            this.dgv_busquedaPedidos.Name = "dgv_busquedaPedidos";
            this.dgv_busquedaPedidos.Size = new System.Drawing.Size(535, 160);
            this.dgv_busquedaPedidos.TabIndex = 80;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(109, 154);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(59, 21);
            this.lbl_fecha.TabIndex = 79;
            this.lbl_fecha.Text = "Fecha";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Location = new System.Drawing.Point(412, 171);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(40, 13);
            this.lbl_buscar.TabIndex = 78;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_buscarPedidoProveedor
            // 
            this.lbl_buscarPedidoProveedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_buscarPedidoProveedor.AutoSize = true;
            this.lbl_buscarPedidoProveedor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_buscarPedidoProveedor.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_buscarPedidoProveedor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_buscarPedidoProveedor.Location = new System.Drawing.Point(107, 35);
            this.lbl_buscarPedidoProveedor.Name = "lbl_buscarPedidoProveedor";
            this.lbl_buscarPedidoProveedor.Size = new System.Drawing.Size(393, 32);
            this.lbl_buscarPedidoProveedor.TabIndex = 76;
            this.lbl_buscarPedidoProveedor.Text = "BUSCAR PEDIDO PROVEEDOR";
            this.lbl_buscarPedidoProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pic_buscar
            // 
            this.pic_buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_buscar.Image = global::pedido_proveedor.Properties.Resources.BUSCAR;
            this.pic_buscar.Location = new System.Drawing.Point(401, 103);
            this.pic_buscar.Name = "pic_buscar";
            this.pic_buscar.Size = new System.Drawing.Size(65, 65);
            this.pic_buscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_buscar.TabIndex = 77;
            this.pic_buscar.TabStop = false;
            // 
            // frm_bucarPedidoP
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(573, 419);
            this.Controls.Add(this.cbo_proveedor);
            this.Controls.Add(this.lbl_proveedor);
            this.Controls.Add(this.ltp_fecha);
            this.Controls.Add(this.dgv_busquedaPedidos);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.pic_buscar);
            this.Controls.Add(this.lbl_buscarPedidoProveedor);
            this.Name = "frm_bucarPedidoP";
            this.Text = "bucar_pedido_prov";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_busquedaPedidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_buscar)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_proveedor;
        private System.Windows.Forms.Label lbl_proveedor;
        private System.Windows.Forms.DateTimePicker ltp_fecha;
        private System.Windows.Forms.DataGridView dgv_busquedaPedidos;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.PictureBox pic_buscar;
        private System.Windows.Forms.Label lbl_buscarPedidoProveedor;
    }
}