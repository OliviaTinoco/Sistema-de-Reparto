﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pedido_proveedor
{
    public partial class frm_pedidoProveedor : Form
    {
        public frm_pedidoProveedor()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void pic_actualizar_Click(object sender, EventArgs e)
        {
            frm_modificarProveedor modpro = new frm_modificarProveedor();
            modpro.ShowDialog(); 

        }

        private void pic_buscar_Click(object sender, EventArgs e)
        {
            frm_bucarPedidoP buscped = new frm_bucarPedidoP();
            buscped.ShowDialog();
        }
    }
}
