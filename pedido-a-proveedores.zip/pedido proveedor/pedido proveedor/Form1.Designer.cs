﻿namespace pedido_proveedor
{
    partial class frm_pedidoProveedor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_agregarLista = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_tpago = new System.Windows.Forms.TextBox();
            this.ltp_fecha = new System.Windows.Forms.DateTimePicker();
            this.cbo_producto = new System.Windows.Forms.ComboBox();
            this.cbo_cantidad = new System.Windows.Forms.ComboBox();
            this.btn_agregar = new System.Windows.Forms.Button();
            this.cbo_proveedor = new System.Windows.Forms.ComboBox();
            this.dtg_listaProducto = new System.Windows.Forms.DataGridView();
            this.lbl_cancelar = new System.Windows.Forms.Label();
            this.lbl_buscar = new System.Windows.Forms.Label();
            this.lbl_eliminar = new System.Windows.Forms.Label();
            this.lbl_Modificar = new System.Windows.Forms.Label();
            this.lbl_guardar = new System.Windows.Forms.Label();
            this.lbl_nuevo = new System.Windows.Forms.Label();
            this.dgv_pedidos = new System.Windows.Forms.DataGridView();
            this.lbl_fecha = new System.Windows.Forms.Label();
            this.lbl_cantidad = new System.Windows.Forms.Label();
            this.lbl_producto = new System.Windows.Forms.Label();
            this.lbl_proveedor = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_pedidoProveedor = new System.Windows.Forms.Label();
            this.pic_cancelar = new System.Windows.Forms.PictureBox();
            this.pic_buscar = new System.Windows.Forms.PictureBox();
            this.pic_eliminar = new System.Windows.Forms.PictureBox();
            this.pic_actualizar = new System.Windows.Forms.PictureBox();
            this.pic_guardar = new System.Windows.Forms.PictureBox();
            this.pic_nuevo = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dtg_listaProducto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cancelar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_buscar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_eliminar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_actualizar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_guardar)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_nuevo)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_agregarLista
            // 
            this.btn_agregarLista.Location = new System.Drawing.Point(534, 464);
            this.btn_agregarLista.Name = "btn_agregarLista";
            this.btn_agregarLista.Size = new System.Drawing.Size(157, 23);
            this.btn_agregarLista.TabIndex = 90;
            this.btn_agregarLista.Text = "Agregar Lista Productos";
            this.btn_agregarLista.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(75, 226);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(114, 21);
            this.label1.TabIndex = 88;
            this.label1.Text = "Tipo de pago";
            // 
            // txt_tpago
            // 
            this.txt_tpago.Location = new System.Drawing.Point(199, 227);
            this.txt_tpago.Name = "txt_tpago";
            this.txt_tpago.Size = new System.Drawing.Size(150, 20);
            this.txt_tpago.TabIndex = 87;
            // 
            // ltp_fecha
            // 
            this.ltp_fecha.Location = new System.Drawing.Point(199, 273);
            this.ltp_fecha.Name = "ltp_fecha";
            this.ltp_fecha.Size = new System.Drawing.Size(150, 20);
            this.ltp_fecha.TabIndex = 86;
            // 
            // cbo_producto
            // 
            this.cbo_producto.FormattingEnabled = true;
            this.cbo_producto.Location = new System.Drawing.Point(534, 213);
            this.cbo_producto.Name = "cbo_producto";
            this.cbo_producto.Size = new System.Drawing.Size(126, 21);
            this.cbo_producto.TabIndex = 85;
            // 
            // cbo_cantidad
            // 
            this.cbo_cantidad.FormattingEnabled = true;
            this.cbo_cantidad.Location = new System.Drawing.Point(618, 166);
            this.cbo_cantidad.Name = "cbo_cantidad";
            this.cbo_cantidad.Size = new System.Drawing.Size(42, 21);
            this.cbo_cantidad.TabIndex = 84;
            // 
            // btn_agregar
            // 
            this.btn_agregar.Location = new System.Drawing.Point(558, 270);
            this.btn_agregar.Name = "btn_agregar";
            this.btn_agregar.Size = new System.Drawing.Size(102, 23);
            this.btn_agregar.TabIndex = 83;
            this.btn_agregar.Text = "Agregar Producto";
            this.btn_agregar.UseVisualStyleBackColor = true;
            // 
            // cbo_proveedor
            // 
            this.cbo_proveedor.FormattingEnabled = true;
            this.cbo_proveedor.Location = new System.Drawing.Point(199, 169);
            this.cbo_proveedor.Name = "cbo_proveedor";
            this.cbo_proveedor.Size = new System.Drawing.Size(150, 21);
            this.cbo_proveedor.TabIndex = 82;
            // 
            // dtg_listaProducto
            // 
            this.dtg_listaProducto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtg_listaProducto.Location = new System.Drawing.Point(462, 311);
            this.dtg_listaProducto.Name = "dtg_listaProducto";
            this.dtg_listaProducto.Size = new System.Drawing.Size(260, 136);
            this.dtg_listaProducto.TabIndex = 81;
            // 
            // lbl_cancelar
            // 
            this.lbl_cancelar.AutoSize = true;
            this.lbl_cancelar.Location = new System.Drawing.Point(606, 126);
            this.lbl_cancelar.Name = "lbl_cancelar";
            this.lbl_cancelar.Size = new System.Drawing.Size(49, 13);
            this.lbl_cancelar.TabIndex = 80;
            this.lbl_cancelar.Text = "Cancelar";
            // 
            // lbl_buscar
            // 
            this.lbl_buscar.AutoSize = true;
            this.lbl_buscar.Location = new System.Drawing.Point(514, 125);
            this.lbl_buscar.Name = "lbl_buscar";
            this.lbl_buscar.Size = new System.Drawing.Size(40, 13);
            this.lbl_buscar.TabIndex = 79;
            this.lbl_buscar.Text = "Buscar";
            // 
            // lbl_eliminar
            // 
            this.lbl_eliminar.AutoSize = true;
            this.lbl_eliminar.Location = new System.Drawing.Point(423, 125);
            this.lbl_eliminar.Name = "lbl_eliminar";
            this.lbl_eliminar.Size = new System.Drawing.Size(43, 13);
            this.lbl_eliminar.TabIndex = 78;
            this.lbl_eliminar.Text = "Eliminar";
            // 
            // lbl_Modificar
            // 
            this.lbl_Modificar.AutoSize = true;
            this.lbl_Modificar.Location = new System.Drawing.Point(338, 125);
            this.lbl_Modificar.Name = "lbl_Modificar";
            this.lbl_Modificar.Size = new System.Drawing.Size(50, 13);
            this.lbl_Modificar.TabIndex = 77;
            this.lbl_Modificar.Text = "Modificar";
            // 
            // lbl_guardar
            // 
            this.lbl_guardar.AutoSize = true;
            this.lbl_guardar.Location = new System.Drawing.Point(247, 125);
            this.lbl_guardar.Name = "lbl_guardar";
            this.lbl_guardar.Size = new System.Drawing.Size(45, 13);
            this.lbl_guardar.TabIndex = 76;
            this.lbl_guardar.Text = "Guardar";
            // 
            // lbl_nuevo
            // 
            this.lbl_nuevo.AutoSize = true;
            this.lbl_nuevo.Location = new System.Drawing.Point(152, 125);
            this.lbl_nuevo.Name = "lbl_nuevo";
            this.lbl_nuevo.Size = new System.Drawing.Size(39, 13);
            this.lbl_nuevo.TabIndex = 75;
            this.lbl_nuevo.Text = "Nuevo";
            // 
            // dgv_pedidos
            // 
            this.dgv_pedidos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pedidos.Location = new System.Drawing.Point(87, 311);
            this.dgv_pedidos.Name = "dgv_pedidos";
            this.dgv_pedidos.Size = new System.Drawing.Size(280, 160);
            this.dgv_pedidos.TabIndex = 69;
            // 
            // lbl_fecha
            // 
            this.lbl_fecha.AutoSize = true;
            this.lbl_fecha.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fecha.Location = new System.Drawing.Point(83, 272);
            this.lbl_fecha.Name = "lbl_fecha";
            this.lbl_fecha.Size = new System.Drawing.Size(59, 21);
            this.lbl_fecha.TabIndex = 68;
            this.lbl_fecha.Text = "Fecha";
            // 
            // lbl_cantidad
            // 
            this.lbl_cantidad.AutoSize = true;
            this.lbl_cantidad.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_cantidad.Location = new System.Drawing.Point(440, 166);
            this.lbl_cantidad.Name = "lbl_cantidad";
            this.lbl_cantidad.Size = new System.Drawing.Size(87, 21);
            this.lbl_cantidad.TabIndex = 67;
            this.lbl_cantidad.Text = "Cantidad";
            // 
            // lbl_producto
            // 
            this.lbl_producto.AutoSize = true;
            this.lbl_producto.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_producto.Location = new System.Drawing.Point(440, 213);
            this.lbl_producto.Name = "lbl_producto";
            this.lbl_producto.Size = new System.Drawing.Size(82, 21);
            this.lbl_producto.TabIndex = 66;
            this.lbl_producto.Text = "Producto";
            // 
            // lbl_proveedor
            // 
            this.lbl_proveedor.AutoSize = true;
            this.lbl_proveedor.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_proveedor.Location = new System.Drawing.Point(83, 169);
            this.lbl_proveedor.Name = "lbl_proveedor";
            this.lbl_proveedor.Size = new System.Drawing.Size(90, 21);
            this.lbl_proveedor.TabIndex = 65;
            this.lbl_proveedor.Text = "Proveedor";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(116, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 13);
            this.label2.TabIndex = 64;
            // 
            // lbl_pedidoProveedor
            // 
            this.lbl_pedidoProveedor.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lbl_pedidoProveedor.AutoSize = true;
            this.lbl_pedidoProveedor.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.lbl_pedidoProveedor.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_pedidoProveedor.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pedidoProveedor.Location = new System.Drawing.Point(181, 22);
            this.lbl_pedidoProveedor.Name = "lbl_pedidoProveedor";
            this.lbl_pedidoProveedor.Size = new System.Drawing.Size(280, 32);
            this.lbl_pedidoProveedor.TabIndex = 63;
            this.lbl_pedidoProveedor.Text = "PEDIDO PROVEEDOR";
            this.lbl_pedidoProveedor.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // pic_cancelar
            // 
            this.pic_cancelar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_cancelar.Image = global::pedido_proveedor.Properties.Resources.CANCELAR;
            this.pic_cancelar.Location = new System.Drawing.Point(595, 57);
            this.pic_cancelar.Name = "pic_cancelar";
            this.pic_cancelar.Size = new System.Drawing.Size(65, 65);
            this.pic_cancelar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_cancelar.TabIndex = 89;
            this.pic_cancelar.TabStop = false;
            // 
            // pic_buscar
            // 
            this.pic_buscar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_buscar.Image = global::pedido_proveedor.Properties.Resources.BUSCAR;
            this.pic_buscar.Location = new System.Drawing.Point(504, 57);
            this.pic_buscar.Name = "pic_buscar";
            this.pic_buscar.Size = new System.Drawing.Size(65, 65);
            this.pic_buscar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_buscar.TabIndex = 74;
            this.pic_buscar.TabStop = false;
            this.pic_buscar.Click += new System.EventHandler(this.pic_buscar_Click);
            // 
            // pic_eliminar
            // 
            this.pic_eliminar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_eliminar.Image = global::pedido_proveedor.Properties.Resources.ELIMINAR;
            this.pic_eliminar.Location = new System.Drawing.Point(416, 58);
            this.pic_eliminar.Name = "pic_eliminar";
            this.pic_eliminar.Size = new System.Drawing.Size(65, 65);
            this.pic_eliminar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_eliminar.TabIndex = 73;
            this.pic_eliminar.TabStop = false;
            // 
            // pic_actualizar
            // 
            this.pic_actualizar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_actualizar.Image = global::pedido_proveedor.Properties.Resources.ACTUALIZAR;
            this.pic_actualizar.Location = new System.Drawing.Point(327, 57);
            this.pic_actualizar.Name = "pic_actualizar";
            this.pic_actualizar.Size = new System.Drawing.Size(65, 65);
            this.pic_actualizar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_actualizar.TabIndex = 72;
            this.pic_actualizar.TabStop = false;
            this.pic_actualizar.Click += new System.EventHandler(this.pic_actualizar_Click);
            // 
            // pic_guardar
            // 
            this.pic_guardar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_guardar.Image = global::pedido_proveedor.Properties.Resources.GUARDAR;
            this.pic_guardar.Location = new System.Drawing.Point(234, 57);
            this.pic_guardar.Name = "pic_guardar";
            this.pic_guardar.Size = new System.Drawing.Size(65, 65);
            this.pic_guardar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_guardar.TabIndex = 71;
            this.pic_guardar.TabStop = false;
            // 
            // pic_nuevo
            // 
            this.pic_nuevo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pic_nuevo.Image = global::pedido_proveedor.Properties.Resources.NUEVO;
            this.pic_nuevo.Location = new System.Drawing.Point(140, 57);
            this.pic_nuevo.Name = "pic_nuevo";
            this.pic_nuevo.Size = new System.Drawing.Size(65, 65);
            this.pic_nuevo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pic_nuevo.TabIndex = 70;
            this.pic_nuevo.TabStop = false;
            // 
            // frm_pedidoProveedor
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.ClientSize = new System.Drawing.Size(804, 509);
            this.Controls.Add(this.btn_agregarLista);
            this.Controls.Add(this.pic_cancelar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txt_tpago);
            this.Controls.Add(this.ltp_fecha);
            this.Controls.Add(this.cbo_producto);
            this.Controls.Add(this.cbo_cantidad);
            this.Controls.Add(this.btn_agregar);
            this.Controls.Add(this.cbo_proveedor);
            this.Controls.Add(this.dtg_listaProducto);
            this.Controls.Add(this.lbl_cancelar);
            this.Controls.Add(this.lbl_buscar);
            this.Controls.Add(this.lbl_eliminar);
            this.Controls.Add(this.lbl_Modificar);
            this.Controls.Add(this.lbl_guardar);
            this.Controls.Add(this.lbl_nuevo);
            this.Controls.Add(this.pic_buscar);
            this.Controls.Add(this.pic_eliminar);
            this.Controls.Add(this.pic_actualizar);
            this.Controls.Add(this.pic_guardar);
            this.Controls.Add(this.pic_nuevo);
            this.Controls.Add(this.dgv_pedidos);
            this.Controls.Add(this.lbl_fecha);
            this.Controls.Add(this.lbl_cantidad);
            this.Controls.Add(this.lbl_producto);
            this.Controls.Add(this.lbl_proveedor);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_pedidoProveedor);
            this.Name = "frm_pedidoProveedor";
            this.Text = "Pedir pedido";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtg_listaProducto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pedidos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_cancelar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_buscar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_eliminar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_actualizar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_guardar)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_nuevo)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_agregarLista;
        private System.Windows.Forms.PictureBox pic_cancelar;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_tpago;
        private System.Windows.Forms.DateTimePicker ltp_fecha;
        private System.Windows.Forms.ComboBox cbo_producto;
        private System.Windows.Forms.ComboBox cbo_cantidad;
        private System.Windows.Forms.Button btn_agregar;
        private System.Windows.Forms.ComboBox cbo_proveedor;
        private System.Windows.Forms.DataGridView dtg_listaProducto;
        private System.Windows.Forms.Label lbl_cancelar;
        private System.Windows.Forms.Label lbl_buscar;
        private System.Windows.Forms.Label lbl_eliminar;
        private System.Windows.Forms.Label lbl_Modificar;
        private System.Windows.Forms.Label lbl_guardar;
        private System.Windows.Forms.Label lbl_nuevo;
        private System.Windows.Forms.PictureBox pic_buscar;
        private System.Windows.Forms.PictureBox pic_eliminar;
        private System.Windows.Forms.PictureBox pic_actualizar;
        private System.Windows.Forms.PictureBox pic_guardar;
        private System.Windows.Forms.PictureBox pic_nuevo;
        private System.Windows.Forms.DataGridView dgv_pedidos;
        private System.Windows.Forms.Label lbl_fecha;
        private System.Windows.Forms.Label lbl_cantidad;
        private System.Windows.Forms.Label lbl_producto;
        private System.Windows.Forms.Label lbl_proveedor;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_pedidoProveedor;
    }
}

